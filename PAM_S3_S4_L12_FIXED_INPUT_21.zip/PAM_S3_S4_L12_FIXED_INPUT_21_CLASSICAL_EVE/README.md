# PAM simples — S3 e S4 — NV L(1,2) — input fixo (2,1)

Este pacote calcula a randomness de Bob contra Eve com **informação lateral clássica** no cenário prepare-and-measure simples, com dimensão comunicada `d=2`.

## Witnesses

Usamos índices zero-based:

\[
S_3=E_{00}+E_{01}+E_{10}-E_{11}-E_{20}\le 3,
\qquad S_3^Q=1+2\sqrt2,
\]

\[
S_4=E_{00}+E_{01}+E_{10}-E_{11}-E_{20}+E_{21}-E_{30}-E_{31}\le 4,
\qquad S_4^Q=4\sqrt2.
\]

O input de geração é sempre

\[
(x^*,y^*)=(2,1).
\]

## Duas curvas para cada witness

1. **Fixed witness**: somente o valor observado de `S3` ou `S4` é imposto. A curva é construída por funções suporte contra Eve clássica.
2. **Fixed distribution**: fixa-se o comportamento completo na linha

\[
p_v(b|x,y)=v\,p_{\rm opt}(b|x,y)+(1-v)\frac12.
\]

A entropia reportada é

\[
H_{\min}(B|\Lambda_{\rm cl},x=2,y=1)\ge -\log_2 P_{\rm guess}^{\rm UB}.
\]

## Hierarquia

O nível é realmente `L(1,2)`:

- grau das amplitudes: `q=1`;
- palavras de medida:

```text
I, B0, B1, B0B1, B1B0
```

- primeiro estado fixado em `|0>` por gauge;
- nenhuma aleatoriedade de endpoint é inserida manualmente;
- as grades param antes do endpoint quântico.

Tamanhos das matrizes por ramo:

- S3: `90 x 90`;
- S4: `130 x 130`.

Na curva de distribuição fixa há dois ramos subnormalizados, um para cada palpite de Eve `g=0,1`.

## Execução

No Windows, execute:

```text
00_RODAR_TUDO.bat
```

Também há arquivos separados para cada etapa.

Pelo terminal:

```bash
python pam_s3_s4_l12.py --mode all --witness both
```

Validação estrutural sem resolver SDPs:

```bash
python pam_s3_s4_l12.py --plot-only --mode validate --witness both
```

## Solvers

O programa usa `MOSEK` quando disponível e pode usar `SCS` como fallback.

Dependências:

```bash
pip install numpy scipy pandas matplotlib cvxpy
```

## Saídas principais

```text
PAM_S3_S4_L12_input_2_1_Hmin_overlay.pdf
PAM_S3_S4_L12_input_2_1_Hmin_overlay.png
PAM_S3_S4_L12_input_2_1_Pguess_overlay.pdf
PAM_S3_S4_L12_input_2_1_Pguess_overlay.png
```

Além disso, são salvos CSVs separados para as quatro curvas e os dados das funções suporte.
