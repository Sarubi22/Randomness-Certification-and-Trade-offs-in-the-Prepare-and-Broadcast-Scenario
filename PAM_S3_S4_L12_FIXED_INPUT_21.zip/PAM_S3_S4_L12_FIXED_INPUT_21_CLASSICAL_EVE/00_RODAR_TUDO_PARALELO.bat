@echo off
setlocal
cd /d "%~dp0"
set PAM_SOLVER=AUTO
set PAM_RESUME=1
set PAM_MOSEK_THREADS=1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$jobs=@();" ^
  "$jobs += Start-Process python -ArgumentList 'pam_s3_s4_l12.py --mode witness --witness S3' -PassThru -NoNewWindow;" ^
  "$jobs += Start-Process python -ArgumentList 'pam_s3_s4_l12.py --mode fixed --witness S3' -PassThru -NoNewWindow;" ^
  "$jobs += Start-Process python -ArgumentList 'pam_s3_s4_l12.py --mode witness --witness S4' -PassThru -NoNewWindow;" ^
  "$jobs += Start-Process python -ArgumentList 'pam_s3_s4_l12.py --mode fixed --witness S4' -PassThru -NoNewWindow;" ^
  "$jobs | Wait-Process"
python pam_s3_s4_l12.py --plot-only --mode plot --witness both
pause
