#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PAM simples — S3 e S4 — randomness de Bob contra Eve clássica.

Hierarquia lifted Navascués–Vértesi no nível L(1,2):
  * grau escalar q=1 para amplitudes das preparações;
  * palavras de medição até comprimento t=2;
  * dimensão comunicada d=2;
  * primeiro estado fixado em |0> por gauge.

O input de geração é fixo em (x*,y*)=(2,1).

O programa calcula duas certificações para cada witness:
  1) fixed witness / witness-only: somente o valor observado de S3 ou S4;
  2) fixed distribution: comportamento completo na linha
         p_v(b|x,y)=v p_opt(b|x,y)+(1-v)/2.

Eve possui informação lateral clássica. Para Bob binário, os ramos são g=0,1.
Nenhum endpoint analítico é inserido. As grades terminam em v<1 e S<S_Q.

Convenções de índice (zero-based)
---------------------------------
S3 = E00 + E01 + E10 - E11 - E20 <= 3,
S4 = E00 + E01 + E10 - E11 - E20 + E21 - E30 - E31 <= 4,
E_xy = p(0|x,y)-p(1|x,y).
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
import scipy.sparse as sp

PLOT_ONLY = "--plot-only" in sys.argv
if PLOT_ONLY:
    cp = None
    PSD = None
else:
    import cvxpy as cp
    from cvxpy.constraints.psd import PSD


# =============================================================================
# 1. Definições físicas
# =============================================================================

D = 2
N_Y = 2
Q_SCALAR = 1
LEVEL = "L12"
GENERATION_INPUT = (2, 1)

SQRT2 = float(np.sqrt(2.0))

WITNESSES = {
    "S3": {
        "n_x": 3,
        "classical": 3.0,
        "quantum": float(1.0 + 2.0 * SQRT2),
        "terms": [
            (+1.0, 0, 0),
            (+1.0, 0, 1),
            (+1.0, 1, 0),
            (-1.0, 1, 1),
            (-1.0, 2, 0),
        ],
        "label": r"$S_3$",
    },
    "S4": {
        "n_x": 4,
        "classical": 4.0,
        "quantum": float(4.0 * SQRT2),
        "terms": [
            (+1.0, 0, 0),
            (+1.0, 0, 1),
            (+1.0, 1, 0),
            (-1.0, 1, 1),
            (-1.0, 2, 0),
            (+1.0, 2, 1),
            (-1.0, 3, 0),
            (-1.0, 3, 1),
        ],
        "label": r"$S_4$",
    },
}


def honest_optimal_correlators(name: str) -> np.ndarray:
    """Correladores E_xy de uma realização qubit ótima exata."""
    if name == "S3":
        states = np.array([
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
            [-1.0 / SQRT2, 0.0, -1.0 / SQRT2],
        ])
        measurements = np.array([
            [1.0 / SQRT2, 0.0, 1.0 / SQRT2],
            [1.0 / SQRT2, 0.0, -1.0 / SQRT2],
        ])
    elif name == "S4":
        states = np.array([
            [1.0 / SQRT2, 0.0, 1.0 / SQRT2],
            [1.0 / SQRT2, 0.0, -1.0 / SQRT2],
            [-1.0 / SQRT2, 0.0, 1.0 / SQRT2],
            [-1.0 / SQRT2, 0.0, -1.0 / SQRT2],
        ])
        measurements = np.array([
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
        ])
    else:
        raise KeyError(name)
    return states @ measurements.T


for _name, _data in WITNESSES.items():
    _data["E_opt"] = honest_optimal_correlators(_name)
    _data["P_opt"] = np.stack(
        [0.5 * (1.0 + _data["E_opt"]), 0.5 * (1.0 - _data["E_opt"])],
        axis=-1,
    )
    _w = sum(c * _data["E_opt"][x, y] for c, x, y in _data["terms"])
    if abs(_w - _data["quantum"]) > 1e-12:
        raise RuntimeError(f"Realização ótima de {_name} inconsistente: {_w}")


# =============================================================================
# 2. Configuração numérica
# =============================================================================

SOLVER_REQUESTED = os.getenv("PAM_SOLVER", "AUTO").strip().upper()
ALLOW_SCS_FALLBACK = os.getenv("PAM_ALLOW_SCS_FALLBACK", "1") == "1"
MOSEK_EPS = float(os.getenv("PAM_MOSEK_EPS", "1e-9"))
MOSEK_THREADS = int(os.getenv("PAM_MOSEK_THREADS", "1"))
SCS_EPS = float(os.getenv("PAM_SCS_EPS", "2e-6"))
SCS_MAX_ITERS = int(os.getenv("PAM_SCS_MAX_ITERS", "1000000"))
SCS_USE_INDIRECT = os.getenv("PAM_SCS_USE_INDIRECT", "1") == "1"
VERBOSE_SOLVER = os.getenv("PAM_VERBOSE", "0") == "1"

SUPPORT_ABS_PADDING = float(os.getenv("PAM_SUPPORT_ABS_PADDING", "1e-8"))
SUPPORT_REL_PADDING = float(os.getenv("PAM_SUPPORT_REL_PADDING", "1e-10"))
OBJECTIVE_ABS_PADDING = float(os.getenv("PAM_OBJECTIVE_ABS_PADDING", "2e-8"))
OBJECTIVE_REL_PADDING = float(os.getenv("PAM_OBJECTIVE_REL_PADDING", "1e-10"))
FIX_TOL = float(os.getenv("PAM_FIXED_DISTRIBUTION_TOL", "1e-8"))
RESUME = os.getenv("PAM_RESUME", "1") == "1"

TAU_MAX = float(os.getenv("PAM_TAU_MAX", "2000"))
TAU_REFINE_ROUNDS = int(os.getenv("PAM_TAU_REFINE_ROUNDS", "6"))
TAU_MAX_NEW_PER_ROUND = int(os.getenv("PAM_TAU_MAX_NEW_PER_ROUND", "128"))
CURVE_POINTS = int(os.getenv("PAM_CURVE_POINTS", "2401"))
ENDPOINT_POINTS = int(os.getenv("PAM_ENDPOINT_POINTS", "900"))
ENDPOINT_REL_GAP_MIN = float(os.getenv("PAM_ENDPOINT_REL_GAP_MIN", "1e-6"))
ENDPOINT_REL_GAP_MAX = float(os.getenv("PAM_ENDPOINT_REL_GAP_MAX", "1e-2"))
FIXED_LINEAR_POINTS = int(os.getenv("PAM_FIXED_LINEAR_POINTS", "61"))
FIXED_ENDPOINT_POINTS = int(os.getenv("PAM_FIXED_ENDPOINT_POINTS", "45"))

OUTPUT_DIR = Path(os.getenv("PAM_OUTPUT_DIR", "resultados_PAM_S3_S4_L12_input_2_1"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# 3. Álgebra lifted L(1,2)
# =============================================================================

Exp = Tuple[int, ...]
Scalar = Tuple[Exp, Exp]
Word = Tuple[int, ...]
MomentKey = Tuple[Scalar, int, int, Word]
Row = Tuple[int, Scalar, Word]
ID_WORD: Word = tuple()


@dataclass(frozen=True)
class Model:
    name: str
    n_x: int
    n_alpha: int
    classical: float
    quantum: float
    terms: tuple
    e_opt: np.ndarray
    p_opt: np.ndarray


def get_model(name: str) -> Model:
    data = WITNESSES[name]
    return Model(
        name=name,
        n_x=int(data["n_x"]),
        n_alpha=int(data["n_x"] * D),
        classical=float(data["classical"]),
        quantum=float(data["quantum"]),
        terms=tuple(data["terms"]),
        e_opt=np.asarray(data["E_opt"], dtype=float),
        p_opt=np.asarray(data["P_opt"], dtype=float),
    )


class ScalarAlgebra:
    """Monômios comutativos nas amplitudes, com gauge psi_0=|0>."""

    def __init__(self, model: Model):
        self.model = model
        self.ref_one = 0  # alpha_00=1
        self.ref_zero = 1 # alpha_01=0

    def var_id(self, x: int, i: int) -> int:
        return x * D + i

    def zero_exp(self) -> Exp:
        return tuple(0 for _ in range(self.model.n_alpha))

    def unit_exp(self, k: int) -> Exp:
        out = [0] * self.model.n_alpha
        out[k] = 1
        return tuple(out)

    @staticmethod
    def add_exp(a: Exp, b: Exp) -> Exp:
        return tuple(x + y for x, y in zip(a, b))

    def one(self) -> Scalar:
        z = self.zero_exp()
        return z, z

    def a(self, k: int) -> Scalar:
        return self.unit_exp(k), self.zero_exp()

    def astar(self, k: int) -> Scalar:
        return self.zero_exp(), self.unit_exp(k)

    @staticmethod
    def adj(s: Scalar) -> Scalar:
        return s[1], s[0]

    @staticmethod
    def degree(s: Scalar) -> int:
        return sum(s[0]) + sum(s[1])

    def simplify(self, s: Optional[Scalar]) -> Optional[Scalar]:
        if s is None:
            return None
        a = list(s[0])
        astar = list(s[1])
        if a[self.ref_zero] > 0 or astar[self.ref_zero] > 0:
            return None
        a[self.ref_one] = 0
        astar[self.ref_one] = 0
        return tuple(a), tuple(astar)

    def mul(self, s1: Optional[Scalar], s2: Optional[Scalar]) -> Optional[Scalar]:
        if s1 is None or s2 is None:
            return None
        return self.simplify((self.add_exp(s1[0], s2[0]), self.add_exp(s1[1], s2[1])))

    def generate_A(self, max_degree: int) -> List[Scalar]:
        if max_degree < 0:
            return []
        variables: List[Scalar] = []
        for x in range(self.model.n_x):
            for i in range(D):
                k = self.var_id(x, i)
                variables.extend([self.a(k), self.astar(k)])
        out = {self.one()}

        def rec(start: int, remaining: int, cur: Optional[Scalar]) -> None:
            if cur is None:
                return
            out.add(cur)
            if remaining == 0:
                return
            for r in range(start, len(variables)):
                rec(r, remaining - 1, self.mul(cur, variables[r]))

        rec(0, max_degree, self.one())
        return sorted(out, key=lambda s: (self.degree(s), s))

    def astar_a(self, x: int, i: int, j: int) -> Optional[Scalar]:
        return self.mul(self.astar(self.var_id(x, i)), self.a(self.var_id(x, j)))


# Medições binárias B_y^2=I. L(1,2) mantém I,B0,B1,B0B1,B1B0.
def reduce_word(word: Sequence[int]) -> Word:
    stack: List[int] = []
    for letter in word:
        letter = int(letter)
        if stack and stack[-1] == letter:
            stack.pop()
        else:
            stack.append(letter)
    return tuple(stack)


def mul_word(w1: Word, w2: Word) -> Word:
    return reduce_word(w1 + w2)


def adj_word(w: Word) -> Word:
    return reduce_word(tuple(reversed(w)))


def B_word(y: int) -> Word:
    return (int(y),)


def generate_S_L12() -> List[Word]:
    out = {ID_WORD}
    for length in range(3):
        for seq in product(range(N_Y), repeat=length):
            out.add(reduce_word(seq))
    return sorted(out, key=lambda w: (len(w), w))


class MomentIndexer:
    def __init__(self, alg: ScalarAlgebra):
        self.alg = alg
        self.key_to_pos: Dict[MomentKey, Tuple[int, Optional[int], bool]] = {}
        self.pos_to_key: List[Tuple[MomentKey, str]] = []
        self.frozen = False

    def star_key(self, key: MomentKey) -> MomentKey:
        scalar, i, j, word = key
        ss = self.alg.simplify(self.alg.adj(scalar))
        if ss is None:
            raise RuntimeError("Adjunto nulo inesperado.")
        return ss, j, i, adj_word(word)

    def canonicalize(self, scalar: Scalar, i: int, j: int, word: Word):
        scalar = self.alg.simplify(scalar)
        if scalar is None:
            return None, False, False
        raw = scalar, int(i), int(j), reduce_word(word)
        star = self.star_key(raw)
        if raw <= star:
            return raw, False, raw == star
        return star, True, False

    def handle(self, scalar: Optional[Scalar], i: int, j: int, word: Word):
        scalar = self.alg.simplify(scalar)
        if scalar is None:
            return None
        key, conjugated, selfadjoint = self.canonicalize(scalar, i, j, word)
        if key is None:
            return None
        if key not in self.key_to_pos:
            if self.frozen:
                raise RuntimeError(f"Momento novo após freeze: {key}")
            re_pos = len(self.pos_to_key)
            self.pos_to_key.append((key, "re"))
            if selfadjoint:
                self.key_to_pos[key] = re_pos, None, True
            else:
                im_pos = len(self.pos_to_key)
                self.pos_to_key.append((key, "im"))
                self.key_to_pos[key] = re_pos, im_pos, False
        re_pos, im_pos, is_real = self.key_to_pos[key]
        return re_pos, im_pos, is_real, conjugated

    def expr(self, yvar, scalar: Optional[Scalar], i: int, j: int, word: Word):
        h = self.handle(scalar, i, j, word)
        if h is None:
            return 0.0
        re_pos, im_pos, is_real, conjugated = h
        if is_real:
            return yvar[re_pos]
        return yvar[re_pos] - 1j * yvar[im_pos] if conjugated else yvar[re_pos] + 1j * yvar[im_pos]


def build_rows(A: Sequence[Scalar], S: Sequence[Word]) -> List[Row]:
    return [(i, scalar, word) for i in range(D) for scalar in A for word in S]


def build_moment_matrix(rows: Sequence[Row], idx: MomentIndexer, name: str):
    n = len(rows)
    data: List[complex] = []
    row_ind: List[int] = []
    col_ind: List[int] = []

    for a, (i, mu, u) in enumerate(rows):
        for b, (j, nu, v) in enumerate(rows):
            scalar = idx.alg.mul(idx.alg.adj(mu), nu)
            if scalar is None:
                continue
            word = mul_word(adj_word(u), v)
            h = idx.handle(scalar, i, j, word)
            if h is None:
                continue
            re_pos, im_pos, is_real, conjugated = h
            flat = a * n + b
            row_ind.append(flat)
            col_ind.append(re_pos)
            data.append(1.0 + 0.0j)
            if not is_real:
                row_ind.append(flat)
                col_ind.append(im_pos)
                data.append(-1.0j if conjugated else 1.0j)

    matrix_map = sp.coo_matrix(
        (np.asarray(data, dtype=complex), (row_ind, col_ind)),
        shape=(n * n, len(idx.pos_to_key)),
    ).tocsr()
    idx.frozen = True

    yvar = cp.Variable(len(idx.pos_to_key), name=f"moments_{name}")
    mvec = matrix_map @ yvar
    matrix = cp.reshape(mvec, (n, n), order="C")
    matrix = 0.5 * (matrix + matrix.H)
    return matrix, yvar


def add_frame_constraints(constraints, idx, yvar, weight=1.0) -> None:
    one = idx.alg.one()
    for i in range(D):
        for j in range(D):
            constraints.append(idx.expr(yvar, one, i, j, ID_WORD) == (weight if i == j else 0.0))


def add_weighted_frame_constraints(constraints, idx, yvar) -> None:
    scalar_only = sorted(
        {key[0] for key, _part in idx.pos_to_key if key[3] == ID_WORD},
        key=str,
    )
    for scalar in scalar_only:
        ref = idx.expr(yvar, scalar, 0, 0, ID_WORD)
        constraints.append(idx.expr(yvar, scalar, 0, 1, ID_WORD) == 0.0)
        constraints.append(idx.expr(yvar, scalar, 1, 0, ID_WORD) == 0.0)
        constraints.append(idx.expr(yvar, scalar, 1, 1, ID_WORD) == ref)


def add_preparation_constraints(constraints, idx, yvar, A_qminus, words) -> None:
    visible_words = sorted(
        {mul_word(adj_word(u), v) for u in words for v in words},
        key=lambda w: (len(w), w),
    )
    alg = idx.alg
    for x in range(1, alg.model.n_x):  # x=0 já foi fixado em |0>
        norm_terms = [
            alg.mul(alg.astar(alg.var_id(x, k)), alg.a(alg.var_id(x, k)))
            for k in range(D)
        ]
        for mu in A_qminus:
            for nu in A_qminus:
                scalar_base = alg.mul(alg.adj(mu), nu)
                for i in range(D):
                    for j in range(D):
                        for word in visible_words:
                            lhs = 0.0
                            for term in norm_terms:
                                lhs += idx.expr(yvar, alg.mul(scalar_base, term), i, j, word)
                            lhs -= idx.expr(yvar, scalar_base, i, j, word)
                            constraints.append(lhs == 0.0)


def expectation(idx: MomentIndexer, yvar, x: int, word: Word):
    out = 0.0
    for i in range(D):
        for j in range(D):
            out += idx.expr(yvar, idx.alg.astar_a(x, i, j), i, j, word)
    return cp.real(out)


def E_xy(idx, yvar, x: int, y: int):
    return expectation(idx, yvar, x, B_word(y))


def probability(idx, yvar, b: int, x: int, y: int, weight=1.0):
    sign = 1.0 if int(b) == 0 else -1.0
    return 0.5 * (weight + sign * E_xy(idx, yvar, x, y))


def witness_expr(model: Model, idx, yvar):
    return cp.real(sum(c * E_xy(idx, yvar, x, y) for c, x, y in model.terms))


def add_probability_positivity(constraints, model, idx, yvar, weight=1.0) -> None:
    for x in range(model.n_x):
        for y in range(N_Y):
            constraints.append(cp.hstack([
                probability(idx, yvar, 0, x, y, weight),
                probability(idx, yvar, 1, x, y, weight),
            ]) >= 0.0)


# =============================================================================
# 4. Solver
# =============================================================================


def choose_solver() -> str:
    installed = set(cp.installed_solvers())
    if SOLVER_REQUESTED == "MOSEK":
        if "MOSEK" not in installed:
            raise RuntimeError(f"MOSEK não instalado. Disponíveis: {sorted(installed)}")
        return "MOSEK"
    if SOLVER_REQUESTED == "SCS":
        if "SCS" not in installed:
            raise RuntimeError(f"SCS não instalado. Disponíveis: {sorted(installed)}")
        return "SCS"
    if "MOSEK" in installed:
        return "MOSEK"
    if "SCS" in installed:
        return "SCS"
    raise RuntimeError(f"Nenhum solver SDP suportado. Disponíveis: {sorted(installed)}")


def solve_problem(problem):
    solver = choose_solver()
    if solver == "MOSEK":
        try:
            value = problem.solve(
                solver=cp.MOSEK,
                warm_start=True,
                verbose=VERBOSE_SOLVER,
                mosek_params={
                    "MSK_DPAR_INTPNT_CO_TOL_PFEAS": MOSEK_EPS,
                    "MSK_DPAR_INTPNT_CO_TOL_DFEAS": MOSEK_EPS,
                    "MSK_DPAR_INTPNT_CO_TOL_REL_GAP": MOSEK_EPS,
                    "MSK_IPAR_INTPNT_SOLVE_FORM": "MSK_SOLVE_DUAL",
                    "MSK_IPAR_NUM_THREADS": MOSEK_THREADS,
                },
            )
            return value, solver
        except Exception as exc:
            if SOLVER_REQUESTED != "AUTO" or not ALLOW_SCS_FALLBACK or "SCS" not in cp.installed_solvers():
                raise
            print(f"AVISO: MOSEK falhou ({exc}); usando SCS.", flush=True)
            solver = "SCS"

    value = problem.solve(
        solver=cp.SCS,
        eps=SCS_EPS,
        max_iters=SCS_MAX_ITERS,
        use_indirect=SCS_USE_INDIRECT,
        warm_start=True,
        verbose=VERBOSE_SOLVER,
    )
    return value, solver


def solver_upper(raw: float, abs_padding: float, rel_padding: float) -> float:
    return raw + abs_padding + rel_padding * max(1.0, abs(raw))


# =============================================================================
# 5. Fixed witness: funções suporte
# =============================================================================


class SupportTemplate:
    def __init__(self, model: Model, guess: int):
        self.model = model
        self.guess = int(guess)
        self.alg = ScalarAlgebra(model)
        A = self.alg.generate_A(Q_SCALAR)
        Aminus = self.alg.generate_A(Q_SCALAR - 1)
        words = generate_S_L12()
        self.words = words
        self.idx = MomentIndexer(self.alg)
        self.rows = build_rows(A, words)
        self.M, self.yvar = build_moment_matrix(self.rows, self.idx, f"support_{model.name}_g{guess}")
        self.constraints = [PSD(self.M)]
        add_frame_constraints(self.constraints, self.idx, self.yvar, 1.0)
        add_preparation_constraints(self.constraints, self.idx, self.yvar, Aminus, words)
        add_weighted_frame_constraints(self.constraints, self.idx, self.yvar)
        add_probability_positivity(self.constraints, model, self.idx, self.yvar, 1.0)

        self.W = witness_expr(model, self.idx, self.yvar)
        xg, yg = GENERATION_INPUT
        self.P = probability(self.idx, self.yvar, guess, xg, yg, 1.0)
        self.tau = cp.Parameter(nonneg=True, value=0.0, name=f"tau_{model.name}_g{guess}")
        self.objective = cp.real(self.P + self.tau * (self.W - model.quantum))
        self.problem = cp.Problem(cp.Maximize(self.objective), self.constraints)
        if not self.problem.is_dcp():
            raise RuntimeError("SDP de função suporte não é DCP.")

    def solve(self, tau: float) -> dict:
        self.tau.value = float(tau)
        start = time.time()
        value, solver = solve_problem(self.problem)
        elapsed = time.time() - start
        status = str(self.problem.status)
        base = {
            "witness": self.model.name,
            "guess": self.guess,
            "tau": float(tau),
            "status": status,
            "solver": solver,
            "time_s": elapsed,
            "matrix_size": len(self.rows),
            "real_variables": len(self.idx.pos_to_key),
            "A_size": len(self.alg.generate_A(Q_SCALAR)),
            "S_size": len(self.words),
            "level": "L(1,2)",
            "generation_x": GENERATION_INPUT[0],
            "generation_y": GENERATION_INPUT[1],
        }
        if status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE} or value is None:
            return {**base, "support_raw": np.nan, "support_upper": np.nan, "p_at_support": np.nan, "w_at_support": np.nan}
        raw = float(np.real(value))
        upper = solver_upper(raw, SUPPORT_ABS_PADDING, SUPPORT_REL_PADDING)
        return {
            **base,
            "support_raw": raw,
            "support_upper": upper,
            "p_at_support": float(np.real(self.P.value)),
            "w_at_support": float(np.real(self.W.value)),
        }


def initial_tau_grid() -> np.ndarray:
    linear = np.linspace(0.0, 2.0, 25)
    log = np.geomspace(2.2, TAU_MAX, 64) if TAU_MAX > 2.2 else np.array([])
    return np.unique(np.concatenate([linear, log, [0.0, 0.5, 1.0, 2.0]]))


def witness_grid(model: Model) -> np.ndarray:
    global_grid = np.linspace(model.classical, model.quantum, max(2, CURVE_POINTS), endpoint=False)
    rel = np.geomspace(ENDPOINT_REL_GAP_MIN, ENDPOINT_REL_GAP_MAX, max(2, ENDPOINT_POINTS))
    endpoint = model.quantum - rel * (model.quantum - model.classical)
    return np.unique(np.concatenate([global_grid, endpoint, [model.classical]]))


def support_csv(name: str) -> Path:
    return OUTPUT_DIR / f"support_{name}_L12_input_2_1.csv"


def witness_curve_csv(name: str) -> Path:
    return OUTPUT_DIR / f"curve_fixed_witness_{name}_L12_input_2_1.csv"


def load_support(name: str) -> pd.DataFrame:
    path = support_csv(name)
    if path.exists():
        return pd.read_csv(path)
    return pd.DataFrame()


def save_frame(path: Path, frame: pd.DataFrame) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(tmp, index=False)
    tmp.replace(path)


def solve_missing_support(model: Model, taus: Iterable[float]) -> pd.DataFrame:
    old = load_support(model.name)
    rows = old.to_dict("records") if not old.empty else []
    solved = {(int(r["guess"]), round(float(r["tau"]), 14)) for r in rows if np.isfinite(r.get("support_upper", np.nan))}
    templates = {g: SupportTemplate(model, g) for g in (0, 1)}
    for tau in sorted(set(float(t) for t in taus)):
        for g in (0, 1):
            key = (g, round(tau, 14))
            if RESUME and key in solved:
                continue
            print(f"[{model.name} witness] tau={tau:.12g}, guess={g}", flush=True)
            result = templates[g].solve(tau)
            rows.append(result)
            save_frame(support_csv(model.name), pd.DataFrame(rows).sort_values(["tau", "guess"]))
            gc.collect()
    return pd.DataFrame(rows).sort_values(["tau", "guess"])


def support_envelope(model: Model, frame: pd.DataFrame, w_values: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    good = frame[np.isfinite(frame["support_upper"])].copy()
    pivot = good.pivot_table(index="tau", columns="guess", values="support_upper", aggfunc="max").dropna()
    taus = pivot.index.to_numpy(dtype=float)
    fmax = np.max(pivot[[0, 1]].to_numpy(dtype=float), axis=1)
    values = fmax[:, None] + taus[:, None] * (model.quantum - w_values[None, :])
    active = np.argmin(values, axis=0)
    pguess = np.min(values, axis=0)
    pguess = np.clip(pguess, 0.5, 1.0)
    return pguess, taus[active]


def adaptive_support(model: Model) -> pd.DataFrame:
    frame = solve_missing_support(model, initial_tau_grid())
    probe_w = witness_grid(model)[::max(1, len(witness_grid(model)) // 700)]
    for round_index in range(TAU_REFINE_ROUNDS):
        pguess, active_taus = support_envelope(model, frame, probe_w)
        del pguess
        available = np.sort(frame[np.isfinite(frame["support_upper"])]["tau"].unique())
        candidates = set()
        active_indices = {int(np.argmin(np.abs(available - t))) for t in np.unique(active_taus)}
        for idx in active_indices:
            for a, b in ((idx - 1, idx), (idx, idx + 1)):
                if a < 0 or b >= len(available):
                    continue
                left, right = float(available[a]), float(available[b])
                if right - left <= 1e-10 * max(1.0, right):
                    continue
                midpoint = 0.5 * (left + right) if left <= 0 else math.sqrt(left * right)
                candidates.add(midpoint)
        existing = {round(float(t), 14) for t in available}
        new = [t for t in sorted(candidates) if round(float(t), 14) not in existing]
        if not new:
            break
        if len(new) > TAU_MAX_NEW_PER_ROUND:
            pick = np.linspace(0, len(new) - 1, TAU_MAX_NEW_PER_ROUND).astype(int)
            new = [new[i] for i in pick]
        print(f"[{model.name}] refinamento tau rodada {round_index+1}: {len(new)} pontos", flush=True)
        frame = solve_missing_support(model, new)
    return frame


def build_witness_curve(model: Model, frame: pd.DataFrame) -> pd.DataFrame:
    w = witness_grid(model)
    pguess, active_tau = support_envelope(model, frame, w)
    hmin = -np.log2(pguess)
    nu = (w - model.classical) / (model.quantum - model.classical)
    visibility = w / model.quantum
    out = pd.DataFrame({
        "witness_name": model.name,
        "witness_value": w,
        "normalized_violation": nu,
        "visibility": visibility,
        "p_guess_upper": pguess,
        "hmin_lower": hmin,
        "active_tau": active_tau,
        "generation_x": GENERATION_INPUT[0],
        "generation_y": GENERATION_INPUT[1],
        "level": "L(1,2)",
        "curve_type": "fixed_witness",
    })
    save_frame(witness_curve_csv(model.name), out)
    return out


# =============================================================================
# 6. Fixed distribution: dois ramos subnormalizados
# =============================================================================


class Branch:
    def __init__(self, model: Model, guess: int):
        self.model = model
        self.guess = int(guess)
        self.alg = ScalarAlgebra(model)
        A = self.alg.generate_A(Q_SCALAR)
        Aminus = self.alg.generate_A(Q_SCALAR - 1)
        words = generate_S_L12()
        self.words = words
        self.idx = MomentIndexer(self.alg)
        self.rows = build_rows(A, words)
        self.M, self.yvar = build_moment_matrix(self.rows, self.idx, f"branch_{model.name}_g{guess}")
        self.weight = cp.Variable(nonneg=True, name=f"weight_{model.name}_g{guess}")
        self.constraints = [PSD(self.M), self.weight >= 0.0]
        add_frame_constraints(self.constraints, self.idx, self.yvar, self.weight)
        add_preparation_constraints(self.constraints, self.idx, self.yvar, Aminus, words)
        add_weighted_frame_constraints(self.constraints, self.idx, self.yvar)
        add_probability_positivity(self.constraints, model, self.idx, self.yvar, self.weight)

    def E(self, x: int, y: int):
        return E_xy(self.idx, self.yvar, x, y)

    def P(self, b: int, x: int, y: int):
        return probability(self.idx, self.yvar, b, x, y, self.weight)


def add_fixed(constraints, expr, target) -> None:
    if FIX_TOL <= 0:
        constraints.append(expr == target)
    else:
        constraints.append(expr <= target + FIX_TOL)
        constraints.append(expr >= target - FIX_TOL)


class FixedDistributionTemplate:
    def __init__(self, model: Model):
        self.model = model
        self.visibility = cp.Parameter(nonneg=True, value=model.classical/model.quantum, name=f"visibility_{model.name}")
        self.branches = [Branch(model, 0), Branch(model, 1)]
        constraints = []
        for branch in self.branches:
            constraints.extend(branch.constraints)
        constraints.append(cp.sum(cp.hstack([b.weight for b in self.branches])) == 1.0)
        for x in range(model.n_x):
            for y in range(N_Y):
                total_e = cp.sum(cp.hstack([b.E(x, y) for b in self.branches]))
                add_fixed(constraints, total_e, self.visibility * model.e_opt[x, y])
        xg, yg = GENERATION_INPUT
        self.objective = cp.real(sum(b.P(b.guess, xg, yg) for b in self.branches))
        self.problem = cp.Problem(cp.Maximize(self.objective), constraints)
        if not self.problem.is_dcp():
            raise RuntimeError("SDP de distribuição fixa não é DCP.")
        self.matrix_size = len(self.branches[0].rows)
        self.real_variables = sum(len(b.idx.pos_to_key) for b in self.branches) + 2

    def solve(self, visibility: float) -> dict:
        self.visibility.value = float(visibility)
        start = time.time()
        value, solver = solve_problem(self.problem)
        elapsed = time.time() - start
        status = str(self.problem.status)
        base = {
            "witness_name": self.model.name,
            "visibility": float(visibility),
            "witness_value": float(visibility) * self.model.quantum,
            "normalized_violation": (float(visibility) * self.model.quantum - self.model.classical) / (self.model.quantum - self.model.classical),
            "status": status,
            "solver": solver,
            "time_s": elapsed,
            "matrix_size_each_branch": self.matrix_size,
            "real_variables_total": self.real_variables,
            "generation_x": GENERATION_INPUT[0],
            "generation_y": GENERATION_INPUT[1],
            "level": "L(1,2)",
            "curve_type": "fixed_distribution",
        }
        if status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE} or value is None:
            return {**base, "p_guess_raw": np.nan, "p_guess_upper": np.nan, "hmin_lower": np.nan, "weight_0": np.nan, "weight_1": np.nan}
        raw = float(np.real(value))
        upper = min(1.0, max(0.5, solver_upper(raw, OBJECTIVE_ABS_PADDING, OBJECTIVE_REL_PADDING)))
        return {
            **base,
            "p_guess_raw": raw,
            "p_guess_upper": upper,
            "hmin_lower": -math.log2(upper),
            "weight_0": float(self.branches[0].weight.value),
            "weight_1": float(self.branches[1].weight.value),
        }


def visibility_grid(model: Model) -> np.ndarray:
    vc = model.classical / model.quantum
    vmax = 1.0 - ENDPOINT_REL_GAP_MIN
    linear = np.linspace(vc, vmax, max(2, FIXED_LINEAR_POINTS))
    gaps = np.geomspace(ENDPOINT_REL_GAP_MIN, min(ENDPOINT_REL_GAP_MAX, 1.0-vc), max(2, FIXED_ENDPOINT_POINTS))
    endpoint = 1.0 - gaps
    return np.unique(np.concatenate([linear, endpoint, [vc]]))


def fixed_curve_csv(name: str) -> Path:
    return OUTPUT_DIR / f"curve_fixed_distribution_{name}_L12_input_2_1.csv"


def run_fixed_distribution(model: Model) -> pd.DataFrame:
    path = fixed_curve_csv(model.name)
    old = pd.read_csv(path) if RESUME and path.exists() else pd.DataFrame()
    rows = old.to_dict("records") if not old.empty else []
    solved = {round(float(r["visibility"]), 14) for r in rows if np.isfinite(r.get("p_guess_upper", np.nan))}
    template = FixedDistributionTemplate(model)
    for v in visibility_grid(model):
        if RESUME and round(float(v), 14) in solved:
            continue
        print(f"[{model.name} fixed distribution] v={v:.12g}", flush=True)
        result = template.solve(float(v))
        rows.append(result)
        save_frame(path, pd.DataFrame(rows).sort_values("visibility"))
        gc.collect()
    return pd.DataFrame(rows).sort_values("visibility")


# =============================================================================
# 7. Plot e metadados
# =============================================================================


def plot_results() -> None:
    curves = {}
    for name in ("S3", "S4"):
        wp = witness_curve_csv(name)
        fp = fixed_curve_csv(name)
        if not wp.exists() or not fp.exists():
            raise FileNotFoundError(f"Faltam curvas de {name}: execute os cálculos antes do plot.")
        curves[(name, "witness")] = pd.read_csv(wp)
        curves[(name, "distribution")] = pd.read_csv(fp)

    fig, ax = plt.subplots(figsize=(9.4, 6.2))
    styles = {
        ("S3", "witness"): dict(label=r"$S_3$, fixed witness", linestyle="-", linewidth=2.0),
        ("S3", "distribution"): dict(label=r"$S_3$, fixed distribution", linestyle="--", linewidth=2.0),
        ("S4", "witness"): dict(label=r"$S_4$, fixed witness", linestyle="-.", linewidth=2.0),
        ("S4", "distribution"): dict(label=r"$S_4$, fixed distribution", linestyle=":", linewidth=2.4),
    }
    for key, frame in curves.items():
        frame = frame[np.isfinite(frame["hmin_lower"])].sort_values("normalized_violation")
        ax.plot(frame["normalized_violation"], frame["hmin_lower"], **styles[key])

    # A linha está no limiar ν=0; aparece na legenda sem inserir endpoint.
    ax.axvline(0.0, color="0.35", linestyle=(0, (1, 2)), linewidth=1.2, label="Classical threshold")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(bottom=0.0)
    ax.set_xlabel(r"Normalized violation $\nu=(S-S_{\rm C})/(S_{\rm Q}-S_{\rm C})$")
    ax.set_ylabel(r"$H_{\min}(B|\Lambda_{\rm cl},x=2,y=1)$ [bits]")
    ax.set_title(r"PAM fixed-input randomness for $S_3$ and $S_4$ at NV $L(1,2)$")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="best", frameon=True)

    # Dois eixos superiores de visibilidade, como no overlay PAB/CHSH.
    ticks = np.linspace(0.0, 1.0, 5)
    for offset, name, label in ((1.02, "S4", r"$S_4$ visibility $v_{S_4}$"), (1.14, "S3", r"$S_3$ visibility $v_{S_3}$")):
        model = get_model(name)
        top = ax.twiny()
        top.set_xlim(ax.get_xlim())
        top.spines["top"].set_position(("axes", offset))
        top.set_xticks(ticks)
        vis = model.classical/model.quantum + ticks * (1.0 - model.classical/model.quantum)
        top.set_xticklabels([f"{v:.4f}" for v in vis])
        top.set_xlabel(label, labelpad=4)
        top.tick_params(axis="x", labelsize=9)

    fig.subplots_adjust(top=0.78)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "PAM_S3_S4_L12_input_2_1_Hmin_overlay.pdf", bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "PAM_S3_S4_L12_input_2_1_Hmin_overlay.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9.4, 5.8))
    for key, frame in curves.items():
        frame = frame[np.isfinite(frame["p_guess_upper"])].sort_values("normalized_violation")
        ax.plot(frame["normalized_violation"], frame["p_guess_upper"], **styles[key])
    ax.axvline(0.0, color="0.35", linestyle=(0, (1, 2)), linewidth=1.2, label="Classical threshold")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.5, 1.01)
    ax.set_xlabel(r"Normalized violation $\nu=(S-S_{\rm C})/(S_{\rm Q}-S_{\rm C})$")
    ax.set_ylabel(r"$P_{\rm guess}^{\rm UB}(B|\Lambda_{\rm cl},x=2,y=1)$")
    ax.set_title(r"PAM guessing probability for $S_3$ and $S_4$ at NV $L(1,2)$")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="best", frameon=True)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "PAM_S3_S4_L12_input_2_1_Pguess_overlay.pdf", bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "PAM_S3_S4_L12_input_2_1_Pguess_overlay.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def save_metadata() -> None:
    meta = {
        "scenario": "simple prepare-and-measure",
        "dimension": D,
        "level": "L(1,2)",
        "scalar_degree": Q_SCALAR,
        "measurement_words": [list(w) for w in generate_S_L12()],
        "generation_input": list(GENERATION_INPUT),
        "eve": "classical side information",
        "endpoint_policy": "no analytic endpoint inserted; grids stop below the quantum endpoint",
        "fixed_distribution": "p_v(b|x,y)=v p_opt(b|x,y)+(1-v)/2",
        "witnesses": {
            name: {
                "classical": data["classical"],
                "quantum": data["quantum"],
                "terms_zero_based": data["terms"],
                "critical_visibility": data["classical"] / data["quantum"],
                "E_opt": np.asarray(data["E_opt"]).tolist(),
                "P_opt": np.asarray(data["P_opt"]).tolist(),
            }
            for name, data in WITNESSES.items()
        },
    }
    with open(OUTPUT_DIR / "metadata.json", "w", encoding="utf-8") as handle:
        json.dump(meta, handle, ensure_ascii=False, indent=2)


# =============================================================================
# 8. CLI
# =============================================================================


def validate_structure(name: str) -> None:
    model = get_model(name)
    alg = ScalarAlgebra(model)
    A = alg.generate_A(1)
    S = generate_S_L12()
    print(f"Witness: {name}")
    print(f"n_x={model.n_x}, A1={len(A)}, S2={len(S)}, matrix={D*len(A)*len(S)}")
    print("S2 words:", S)
    print("E_opt:\n", model.e_opt)
    print("P_opt input (2,1):", model.p_opt[2, 1])
    print("Classical:", model.classical, "Quantum:", model.quantum)


def run_witness(name: str) -> None:
    model = get_model(name)
    frame = adaptive_support(model)
    build_witness_curve(model, frame)


def run_fixed(name: str) -> None:
    run_fixed_distribution(get_model(name))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--witness", choices=["S3", "S4", "both"], default="both")
    parser.add_argument("--mode", choices=["witness", "fixed", "both", "plot", "all", "validate"], default="all")
    parser.add_argument("--plot-only", action="store_true")
    args = parser.parse_args()

    save_metadata()
    names = ("S3", "S4") if args.witness == "both" else (args.witness,)

    if args.mode == "validate":
        for name in names:
            validate_structure(name)
        return
    if args.mode in {"witness", "both", "all"}:
        for name in names:
            run_witness(name)
    if args.mode in {"fixed", "both", "all"}:
        for name in names:
            run_fixed(name)
    if args.mode in {"plot", "all"}:
        plot_results()


if __name__ == "__main__":
    main()
