@echo off
setlocal
cd /d "%~dp0"
set PAM_SOLVER=AUTO
set PAM_RESUME=1
python pam_s3_s4_l12.py --mode witness --witness S4
pause
