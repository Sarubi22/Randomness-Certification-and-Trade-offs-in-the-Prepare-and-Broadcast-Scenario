# Formulação matemática

## PAM simples

\[
p(b|x,y)=\operatorname{tr}[\rho_x M_{b|y}],
\qquad \rho_x\in\mathcal D(\mathbb C^2).
\]

Para outputs binários,

\[
B_y=M_{0|y}-M_{1|y},
\qquad
p(b|x,y)=\frac12\left[1+(-1)^bE_{xy}\right],
\]

com

\[
E_{xy}=\langle B_y\rangle_x.
\]

## Eve clássica

Para o input fixo \(s^*=(2,1)\),

\[
P_{\rm guess}(B|\Lambda_{\rm cl},s^*)
=
\max_{\{q_\lambda,p_\lambda\}}
\sum_\lambda q_\lambda\max_b p_\lambda(b|s^*).
\]

## Fixed witness

Para cada palpite \(g\in\{0,1\}\) e \(\tau\ge0\), calcula-se

\[
\bar F_g(\tau)=
\max_{L\in\mathcal Q_{2}^{L(1,2)}}
\left[p_L(g|s^*)+\tau(S[L]-S_Q)\right].
\]

Então

\[
P_{\rm guess}^{\rm UB}(s^*;s)
=
\inf_{\tau\ge0}
\left[
\max_g\bar F_g(\tau)+\tau(S_Q-s)
\right].
\]

## Fixed distribution

Introduzem-se dois funcionais subnormalizados \(L_0,L_1\), com pesos \(r_0,r_1\), e resolve-se

\[
\max_{L_0,L_1}
\left[p_{L_0}(0|2,1)+p_{L_1}(1|2,1)\right]
\]

sujeito a

\[
r_0+r_1=1,
\]

\[
E_{xy}[L_0]+E_{xy}[L_1]=vE_{xy}^{\rm opt}
\quad\forall x,y,
\]

além das restrições NV \(L(1,2)\) em cada ramo.

## Distribuições ótimas usadas

### S3

Uma realização ótima é

\[
\vec r_0=(1,0,0),\quad
\vec r_1=(0,0,1),\quad
\vec r_2=-\frac{(1,0,1)}{\sqrt2},
\]

\[
\vec q_0=\frac{(1,0,1)}{\sqrt2},\quad
\vec q_1=\frac{(1,0,-1)}{\sqrt2}.
\]

No input \((2,1)\), \(E_{21}=0\).

### S4

Uma realização ótima é

\[
\vec r_0=\frac{(1,0,1)}{\sqrt2},\quad
\vec r_1=\frac{(1,0,-1)}{\sqrt2},
\]

\[
\vec r_2=\frac{(-1,0,1)}{\sqrt2},\quad
\vec r_3=\frac{(-1,0,-1)}{\sqrt2},
\]

\[
\vec q_0=(1,0,0),\qquad \vec q_1=(0,0,1).
\]

No input \((2,1)\), \(E_{21}=1/\sqrt2\).
