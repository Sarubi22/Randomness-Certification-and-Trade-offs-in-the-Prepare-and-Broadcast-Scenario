@echo off
setlocal
cd /d "%~dp0"
python pam_s3_s4_l12.py --plot-only --mode plot --witness both
pause
