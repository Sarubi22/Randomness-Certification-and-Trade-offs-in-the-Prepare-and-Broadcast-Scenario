#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CC2 — certificação de randomness conjunta BC para três representantes das órbitas de inputs.

Características desta versão
-----------------------------
* Apenas a faceta CC2.
* Apenas três inputs: (0,0,0) em O_A, (1,0,0) em O_B e (2,0,0) em O_C.
* Eixo horizontal dos gráficos: valor bruto W_CC2, desde W_C=6 até
  W_Q=8+2*sqrt(2), sem normalização no gráfico.
* Curva visual densa (milhares de pontos) reconstruída a partir das funções
  suporte; isso não exige uma SDP nova para cada ponto gráfico.
* Função suporte centralizada:

      Fbar_g(tau) = max [ p(g|s*) + tau (W-W_Q) ],
      G(w) <= inf_tau [ max_g Fbar_g(tau) + tau (W_Q-w) ].

  A centralização evita cancelamento numérico perto do endpoint.
* Uma matriz de momentos PSD por solve e duas classes de palpites por tau
  (00~11 e 01~10), salvo quando PAB_DISABLE_SYMMETRY=1.
* Solver AUTO: prefere MOSEK quando disponível e usa SCS como fallback.
* Endpoint analítico H_min=2 inserido apenas na órbita provada da CC2:
  {(0,0,1),(0,1,0),(1,0,0),(1,1,1)}.

A relaxação usada é a hierarquia de momentos PAB no nível L(1,2), q=1 por
padrão. Não é usada a extensão L11+BC. Os valores numéricos são bounds da relaxação; para um certificado
numérico formal em alta precisão, deve-se também verificar/reparar o dual.
"""

from __future__ import annotations

import argparse
import csv
import gc
import json
import math
import os
try:
    import resource  # Linux/macOS
except ImportError:
    resource = None  # Windows
import shlex
import subprocess
import sys
import time
from datetime import datetime, timezone
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy.optimize import linprog, minimize

MODE = "joint"  # "joint" ou "marginal"
if MODE not in {"joint", "marginal"}:
    raise RuntimeError(f"MODE inválido: {MODE}")

SUBMIT_MODE = "--submit" in sys.argv
PLOT_ONLY = "--plot-only" in sys.argv or os.getenv("PAB_PLOT_ONLY", "0") == "1"
if SUBMIT_MODE or PLOT_ONLY:
    cp = None
    PSD = None
else:
    import cvxpy as cp
    from cvxpy.constraints.psd import PSD


# =============================================================================
# 1. Configuração
# =============================================================================

D = 2
N_X = 3
N_B = 2
N_C = 2
N_ALPHA = N_X * D

LEVEL = os.getenv("PAB_LEVEL", "L12").upper()
LEVEL = {"L11+BR": "L11+BC", "CUSTOM": "L11+BC", "1:1": "L11", "1:2": "L12"}.get(LEVEL, LEVEL)
if LEVEL not in {"L11", "L11+BC", "L12"}:
    raise ValueError("PAB_LEVEL deve ser L11, L11+BC ou L12.")

Q_SCALAR = int(os.getenv("PAB_Q_SCALAR", "1"))
if Q_SCALAR < 1:
    raise ValueError("PAB_Q_SCALAR deve ser >= 1.")

SOLVER_REQUESTED = os.getenv("PAB_SOLVER", "AUTO").strip().upper()
if SOLVER_REQUESTED not in {"AUTO", "MOSEK", "SCS"}:
    raise ValueError("PAB_SOLVER deve ser AUTO, MOSEK ou SCS.")

MOSEK_EPS = float(os.getenv("PAB_MOSEK_EPS", "1e-9"))
SCS_EPS = float(os.getenv("PAB_SCS_EPS", "2e-6"))
SCS_MAX_ITERS = int(os.getenv("PAB_SCS_MAX_ITERS", "1000000"))
SCS_USE_INDIRECT = os.getenv("PAB_SCS_USE_INDIRECT", "1") == "1"
SCS_NORMALIZE = os.getenv("PAB_SCS_NORMALIZE", "1") == "1"
SCS_SCALE = float(os.getenv("PAB_SCS_SCALE", "0.1"))
SCS_ALPHA = float(os.getenv("PAB_SCS_ALPHA", "1.5"))
SCS_ACCELERATION_LOOKBACK = int(os.getenv("PAB_SCS_ACCELERATION_LOOKBACK", "10"))
VERBOSE_SOLVER = os.getenv("PAB_VERBOSE", "0") == "1"

# Padding da função suporte centralizada. O valor é pequeno porque o objetivo
# fica da ordem de p_guess, e não da ordem de tau*W_Q.
SUPPORT_ABS_PADDING = float(os.getenv("PAB_SUPPORT_ABS_PADDING", "1e-8"))
SUPPORT_REL_PADDING = float(os.getenv("PAB_SUPPORT_REL_PADDING", "1e-10"))
RESIDUAL_MULTIPLIER = float(os.getenv("PAB_RESIDUAL_MULTIPLIER", "10.0"))
ENFORCE_PROBABILITY_POSITIVITY = os.getenv("PAB_ENFORCE_PROB_POS", "1") == "1"
DISABLE_SYMMETRY = os.getenv("PAB_DISABLE_SYMMETRY", "0") == "1"
RESUME = os.getenv("PAB_RESUME", "1") == "1"
SAVE_INPUT_PLOTS = os.getenv("PAB_SAVE_INPUT_PLOTS", "1") == "1"

# Reinicia o processo após um número configurável de novos solves. Isso não
# altera a otimização: cada solve é salvo antes da saída, e o runner retoma
# automaticamente pelo CSV. É útil no Windows para liberar memória nativa
# acumulada pelo CVXPY/MOSEK em execuções longas.
MAX_NEW_SOLVES_PER_PROCESS = int(os.getenv("PAB_MAX_NEW_SOLVES_PER_PROCESS", "0"))
RECYCLE_EXIT_CODE = 75


class ProcessRecycleRequested(RuntimeError):
    pass

RUN_PHYSICAL_LOWER = os.getenv("PAB_RUN_PHYSICAL_LOWER", "0") == "1"
PHYSICAL_RESTARTS = int(os.getenv("PAB_PHYSICAL_RESTARTS", "8"))
PHYSICAL_MAXITER = int(os.getenv("PAB_PHYSICAL_MAXITER", "1200"))
PHYSICAL_SEED = int(os.getenv("PAB_PHYSICAL_SEED", "12345"))

# Grade inicial de tau. Ela é moderada; o refinamento adaptativo acrescenta
# pontos apenas onde alguma das curvas usa o tau como minimizador. Valores
# logarítmicos grandes são necessários perto do endpoint W_Q.
TAU_FOCUS_ENABLED = os.getenv("PAB_TAU_FOCUS", "0") == "1"
TAU_FOCUS_MIN = float(os.getenv("PAB_TAU_FOCUS_MIN", "0.0"))
TAU_FOCUS_MAX = float(os.getenv("PAB_TAU_FOCUS_MAX", "2.0"))
TAU_FOCUS_STEP = float(os.getenv("PAB_TAU_FOCUS_STEP", "0.1"))
TAU_REFINE_ROUNDS = int(os.getenv("PAB_TAU_REFINE_ROUNDS", "7"))
TAU_REFINE_ABS_TOL = float(os.getenv("PAB_TAU_REFINE_ABS_TOL", "1e-4"))
TAU_REFINE_REL_TOL = float(os.getenv("PAB_TAU_REFINE_REL_TOL", "5e-5"))
TAU_BOUND_IMPROVEMENT_TOL = float(os.getenv("PAB_TAU_BOUND_IMPROVEMENT_TOL", "1e-8"))
TAU_MAX_NEW_PER_ROUND = int(os.getenv("PAB_TAU_MAX_NEW_PER_ROUND", "256"))
TAU_MAX_DEFAULT = float(os.getenv("PAB_TAU_MAX", "2000"))


def _inclusive_grid(start: float, stop: float, step: float) -> List[float]:
    if step <= 0:
        raise ValueError("PAB_TAU_FOCUS_STEP deve ser positivo.")
    if stop < start:
        raise ValueError("PAB_TAU_FOCUS_MAX deve ser >= PAB_TAU_FOCUS_MIN.")
    n = int(math.floor((stop - start) / step + 1e-12))
    values = [start + k * step for k in range(n + 1)]
    if not values or values[-1] < stop - 1e-12:
        values.append(stop)
    return values


def default_tau_grid() -> np.ndarray:
    linear = np.linspace(0.0, 2.0, 21)
    if TAU_MAX_DEFAULT <= 2.0:
        return np.unique(linear[linear <= TAU_MAX_DEFAULT])
    logarithmic = np.geomspace(2.2, TAU_MAX_DEFAULT, 56)
    return np.unique(np.concatenate([linear, logarithmic]))


tau_text = os.getenv("PAB_TAUS", "").strip()
if tau_text:
    _tau_user = {float(v) for v in tau_text.split(",") if v.strip()}
else:
    _tau_user = set(default_tau_grid().tolist())
if TAU_FOCUS_ENABLED:
    _tau_user.update(_inclusive_grid(TAU_FOCUS_MIN, TAU_FOCUS_MAX, TAU_FOCUS_STEP))
_tau_user.update({0.0, 0.5, 1.0, 2.0})
TAU_INITIAL = np.array(sorted(_tau_user), dtype=float)
if np.any(TAU_INITIAL < 0):
    raise ValueError("Todos os valores de tau devem ser não negativos.")

W_PLOT_POINTS_GLOBAL = int(os.getenv("PAB_W_PLOT_POINTS_GLOBAL", "1801"))
W_PLOT_POINTS_ENDPOINT = int(os.getenv("PAB_W_PLOT_POINTS_ENDPOINT", "1200"))
W_ENDPOINT_REL_GAP_MIN = float(os.getenv("PAB_ENDPOINT_REL_GAP_MIN", "1e-8"))
W_ENDPOINT_REL_GAP_MAX = float(os.getenv("PAB_ENDPOINT_REL_GAP_MAX", "1e-2"))

# Limiar de certificação. O valor é obtido diretamente do envelope de suporte,
# e não pelo primeiro ponto positivo de uma grade visual. H_min>0 equivale a
# G_UB<1. A tolerância abaixo é usada apenas para classificar/relatar o limiar.
CERT_G_TOL = float(os.getenv("PAB_CERT_G_TOL", "1e-10"))
CERT_H_TOL = float(os.getenv("PAB_CERT_H_TOL", "1e-10"))

MODE_TAG = "joint_BC" if MODE == "joint" else "marginal_B"
DEFAULT_OUTPUT = f"resultados_CC2_3_orbitas_{MODE_TAG}_support"
OUTPUT_DIR = Path(os.getenv("PAB_OUTPUT_DIR", DEFAULT_OUTPUT))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR = OUTPUT_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# SLURM: um único cone é muito menor que a antiga formulação multirramos.
DEFAULT_SLURM_MEM = "256G" if MODE == "joint" else "192G"
SLURM_MEM = os.getenv("PAB_SLURM_MEM", DEFAULT_SLURM_MEM)
SLURM_CPUS = int(os.getenv("PAB_SLURM_CPUS", "16"))
SLURM_TIME = os.getenv("PAB_SLURM_TIME", "2-00:00:00")
SLURM_CONCURRENCY = int(os.getenv("PAB_SLURM_ARRAY_CONCURRENCY", "1"))


# =============================================================================
# 2. Testemunhas
# =============================================================================

WITNESSES = {
    "CC2": {
        "label": r"W_{CC}^{(2)}",
        "classical": 6.0,
        "quantum_reference": float(8 + 2 * np.sqrt(2)),
        "terms": [
            (+2.0, 0, 0, 0), (+2.0, 0, 1, 1),
            (+2.0, 1, 0, 1), (-2.0, 1, 1, 0),
            (-1.0, 2, 0, 0), (-1.0, 2, 0, 1),
            (+1.0, 2, 1, 0), (-1.0, 2, 1, 1),
        ],
    },
}
FACETS = ("CC2",)

# Um representante de cada órbita da ação de simetria da witness CC2.
# O_B contém o input (1,0,0) usado no teorema de dois bits.
ORBIT_REPRESENTATIVES = {
    "OA": (0, 0, 0),
    "OB": (1, 0, 0),
    "OC": (2, 0, 0),
}
REPRESENTATIVE_INPUTS = tuple(ORBIT_REPRESENTATIVES.values())


def orbit_name(generation_input) -> str:
    target = tuple(int(v) for v in generation_input)
    for name, representative in ORBIT_REPRESENTATIVES.items():
        if target == representative:
            return name
    return ""


def orbit_plot_label(generation_input) -> str:
    name = orbit_name(generation_input)
    tag = ",".join(str(int(v)) for v in generation_input)
    return rf"$\mathcal{{O}}_{{{name[-1]}}}$: $({tag})$" if name else rf"$({tag})$"



def witness_grid(facet: str) -> np.ndarray:
    """Grade densa em W bruto, com concentração logarítmica perto de W_Q."""
    data = WITNESSES[facet]
    wc = float(data["classical"])
    wq = float(data["quantum_reference"])
    n_global = max(2, W_PLOT_POINTS_GLOBAL)
    n_endpoint = max(2, W_PLOT_POINTS_ENDPOINT)
    global_grid = np.linspace(wc, wq, n_global)
    min_gap = max(1e-14, W_ENDPOINT_REL_GAP_MIN)
    max_gap = min(1.0, max(min_gap, W_ENDPOINT_REL_GAP_MAX))
    rel_gaps = np.geomspace(min_gap, max_gap, n_endpoint)
    endpoint_grid = wq - rel_gaps * (wq - wc)
    return np.unique(np.concatenate([global_grid, endpoint_grid, [wc, wq]]))



# =============================================================================
# 3. Álgebra escalar com gauge completo
# =============================================================================

Exp = Tuple[int, ...]
Scalar = Tuple[Exp, Exp]
Word = Tuple[Tuple[int, ...], Tuple[int, ...]]
MomentKey = Tuple[Scalar, int, int, Word]
Row = Tuple[int, Scalar, Word]
ID_WORD: Word = (tuple(), tuple())

REF_X = 0
REF_ONE = 0   # alpha_{0,0}=1
REF_ZERO = 1  # alpha_{0,1}=0


def var_id(x: int, i: int) -> int:
    return x * D + i


def zero_exp() -> Exp:
    return tuple(0 for _ in range(N_ALPHA))


def unit_exp(k: int) -> Exp:
    out = [0] * N_ALPHA
    out[k] = 1
    return tuple(out)


def add_exp(a: Exp, b: Exp) -> Exp:
    return tuple(x + y for x, y in zip(a, b))


def zero_scalar() -> Scalar:
    z = zero_exp()
    return z, z


def scalar_a(k: int) -> Scalar:
    return unit_exp(k), zero_exp()


def scalar_astar(k: int) -> Scalar:
    return zero_exp(), unit_exp(k)


def adj_scalar(s: Scalar) -> Scalar:
    return s[1], s[0]


def scalar_degree(s: Scalar) -> int:
    return sum(s[0]) + sum(s[1])


def simplify_scalar(s: Optional[Scalar]) -> Optional[Scalar]:
    """Aplica alpha_{0,0}=1 e alpha_{0,1}=0 exatamente."""
    if s is None:
        return None
    a = list(s[0])
    astar = list(s[1])
    if a[REF_ZERO] > 0 or astar[REF_ZERO] > 0:
        return None
    a[REF_ONE] = 0
    astar[REF_ONE] = 0
    return tuple(a), tuple(astar)


def mul_scalar(s1: Optional[Scalar], s2: Optional[Scalar]) -> Optional[Scalar]:
    if s1 is None or s2 is None:
        return None
    return simplify_scalar((add_exp(s1[0], s2[0]), add_exp(s1[1], s2[1])))


def generate_A(max_degree: int) -> List[Scalar]:
    if max_degree < 0:
        return []
    variables: List[Scalar] = []
    for x in range(N_X):
        for i in range(D):
            k = var_id(x, i)
            variables.extend([scalar_a(k), scalar_astar(k)])
    out = {zero_scalar()}

    def rec(start: int, remaining: int, cur: Optional[Scalar]) -> None:
        if cur is None:
            return
        out.add(cur)
        if remaining == 0:
            return
        for r in range(start, len(variables)):
            rec(r, remaining - 1, mul_scalar(cur, variables[r]))

    rec(0, max_degree, zero_scalar())
    return sorted(out, key=lambda s: (scalar_degree(s), s))


def scalar_astar_a(x: int, bra_i: int, ket_j: int) -> Optional[Scalar]:
    return mul_scalar(scalar_astar(var_id(x, bra_i)), scalar_a(var_id(x, ket_j)))


# =============================================================================
# 4. Palavras de medição
# =============================================================================


def reduce_involutions(seq: Sequence[int]) -> Tuple[int, ...]:
    stack: List[int] = []
    for letter in seq:
        letter = int(letter)
        if stack and stack[-1] == letter:
            stack.pop()
        else:
            stack.append(letter)
    return tuple(stack)


def reduce_word(w: Word) -> Word:
    # Separar as subpalavras já impõe [B_y,C_z]=0.
    return reduce_involutions(w[0]), reduce_involutions(w[1])


def mul_word(w1: Word, w2: Word) -> Word:
    return reduce_word((w1[0] + w2[0], w1[1] + w2[1]))


def adj_word(w: Word) -> Word:
    return reduce_word((tuple(reversed(w[0])), tuple(reversed(w[1]))))


def word_length(w: Word) -> int:
    return len(w[0]) + len(w[1])


def B_word(y: int) -> Word:
    return (int(y),), tuple()


def C_word(z: int) -> Word:
    return tuple(), (int(z),)


def BC_word(y: int, z: int) -> Word:
    return (int(y),), (int(z),)


def generate_S(level: str) -> List[Word]:
    if level == "L11":
        out = {ID_WORD}
        out.update(B_word(y) for y in range(N_B))
        out.update(C_word(z) for z in range(N_C))
    elif level == "L11+BC":
        out = {ID_WORD}
        out.update(B_word(y) for y in range(N_B))
        out.update(C_word(z) for z in range(N_C))
        out.update(BC_word(y, z) for y in range(N_B) for z in range(N_C))
    elif level == "L12":
        out = {ID_WORD}
        for b_len in range(3):
            for c_len in range(3 - b_len):
                for bs in product(range(N_B), repeat=b_len):
                    for cs in product(range(N_C), repeat=c_len):
                        out.add(reduce_word((bs, cs)))
    else:
        raise ValueError(level)
    return sorted(out, key=lambda w: (word_length(w), w))


# =============================================================================
# 5. Indexador real/esparso de momentos
# =============================================================================


class MomentIndexer:
    def __init__(self):
        self.key_to_pos: Dict[MomentKey, Tuple[int, Optional[int], bool]] = {}
        self.pos_to_key: List[Tuple[MomentKey, str]] = []
        self.frozen = False

    @staticmethod
    def star_key(key: MomentKey) -> MomentKey:
        scalar, i, j, word = key
        ss = simplify_scalar(adj_scalar(scalar))
        if ss is None:
            raise RuntimeError("Adjunto inesperadamente nulo.")
        return ss, j, i, adj_word(word)

    @classmethod
    def canonicalize(cls, scalar: Scalar, i: int, j: int, word: Word):
        scalar = simplify_scalar(scalar)
        if scalar is None:
            return None, False, False
        raw = scalar, int(i), int(j), reduce_word(word)
        star = cls.star_key(raw)
        if raw <= star:
            return raw, False, raw == star
        return star, True, False

    def handle(self, scalar: Optional[Scalar], i: int, j: int, word: Word):
        scalar = simplify_scalar(scalar)
        if scalar is None:
            return None
        key, conjugated, selfadjoint = self.canonicalize(scalar, i, j, word)
        if key is None:
            return None
        if key not in self.key_to_pos:
            if self.frozen:
                raise RuntimeError(f"Momento novo após freeze: {key}")
            re_pos = len(self.pos_to_key)
            self.pos_to_key.append((key, "re"))
            if selfadjoint:
                self.key_to_pos[key] = re_pos, None, True
            else:
                im_pos = len(self.pos_to_key)
                self.pos_to_key.append((key, "im"))
                self.key_to_pos[key] = re_pos, im_pos, False
        re_pos, im_pos, is_real = self.key_to_pos[key]
        return re_pos, im_pos, is_real, conjugated

    def expr(self, yvar, scalar: Optional[Scalar], i: int, j: int, word: Word):
        h = self.handle(scalar, i, j, word)
        if h is None:
            return 0.0
        re_pos, im_pos, is_real, conjugated = h
        if is_real:
            return yvar[re_pos]
        return yvar[re_pos] - 1j * yvar[im_pos] if conjugated else yvar[re_pos] + 1j * yvar[im_pos]


def build_rows(A: Sequence[Scalar], S: Sequence[Word]) -> List[Row]:
    return [(i, scalar, word) for i in range(D) for scalar in A for word in S]


def build_moment_matrix(rows: Sequence[Row], idx: MomentIndexer):
    n = len(rows)
    data: List[complex] = []
    row_ind: List[int] = []
    col_ind: List[int] = []

    for a, (i, mu, u) in enumerate(rows):
        for b, (j, nu, v) in enumerate(rows):
            scalar = mul_scalar(adj_scalar(mu), nu)
            if scalar is None:
                continue
            word = mul_word(adj_word(u), v)
            h = idx.handle(scalar, i, j, word)
            if h is None:
                continue
            re_pos, im_pos, is_real, conjugated = h
            flat = a * n + b
            row_ind.append(flat)
            col_ind.append(re_pos)
            data.append(1.0 + 0.0j)
            if not is_real:
                row_ind.append(flat)
                col_ind.append(im_pos)
                data.append(-1.0j if conjugated else 1.0j)

    A_sparse = sp.coo_matrix(
        (np.asarray(data, dtype=complex), (row_ind, col_ind)),
        shape=(n * n, len(idx.pos_to_key)),
    ).tocsr()
    idx.frozen = True

    yvar = cp.Variable(len(idx.pos_to_key), name="real_moments")
    M_vec = A_sparse @ yvar
    M = cp.reshape(M_vec, (n, n), order="C")
    M = 0.5 * (M + M.H)
    return M, yvar


# =============================================================================
# 6. Constraints e probabilidades
# =============================================================================


def add_frame_constraints(constraints: list, idx: MomentIndexer, yvar) -> None:
    one = zero_scalar()
    for i in range(D):
        for j in range(D):
            constraints.append(idx.expr(yvar, one, i, j, ID_WORD) == (1.0 if i == j else 0.0))


def add_weighted_frame_constraints(constraints: list, idx: MomentIndexer, yvar) -> None:
    scalar_only = sorted(
        {key[0] for key, _part in idx.pos_to_key if key[3] == ID_WORD},
        key=str,
    )
    for scalar in scalar_only:
        ref = idx.expr(yvar, scalar, 0, 0, ID_WORD)
        constraints.append(idx.expr(yvar, scalar, 0, 1, ID_WORD) == 0.0)
        constraints.append(idx.expr(yvar, scalar, 1, 0, ID_WORD) == 0.0)
        constraints.append(idx.expr(yvar, scalar, 1, 1, ID_WORD) == ref)


def add_preparation_constraints(
    constraints: list,
    idx: MomentIndexer,
    yvar,
    A_qminus: Sequence[Scalar],
    S: Sequence[Word],
) -> None:
    visible_words = sorted(
        {mul_word(adj_word(u), v) for u in S for v in S},
        key=lambda w: (word_length(w), w),
    )
    for x in range(N_X):
        if x == REF_X:
            continue
        norm_terms = [
            mul_scalar(scalar_astar(var_id(x, k)), scalar_a(var_id(x, k)))
            for k in range(D)
        ]
        for mu in A_qminus:
            for nu in A_qminus:
                scalar_base = mul_scalar(adj_scalar(mu), nu)
                for i in range(D):
                    for j in range(D):
                        for word in visible_words:
                            lhs = 0.0
                            for term in norm_terms:
                                lhs += idx.expr(yvar, mul_scalar(scalar_base, term), i, j, word)
                            lhs -= idx.expr(yvar, scalar_base, i, j, word)
                            constraints.append(lhs == 0.0)


def expectation(idx: MomentIndexer, yvar, x: int, word: Word):
    out = 0.0
    for i in range(D):
        for j in range(D):
            out += idx.expr(yvar, scalar_astar_a(x, i, j), i, j, word)
    return cp.real(out)


def E_B(idx, yvar, x: int, y: int):
    return expectation(idx, yvar, x, B_word(y))


def E_C(idx, yvar, x: int, z: int):
    return expectation(idx, yvar, x, C_word(z))


def E_BC(idx, yvar, x: int, y: int, z: int):
    return expectation(idx, yvar, x, BC_word(y, z))


def prob_BC(idx, yvar, b: int, c: int, x: int, y: int, z: int):
    sb = 1.0 if b == 0 else -1.0
    sc = 1.0 if c == 0 else -1.0
    return 0.25 * (1.0 + sb * E_B(idx, yvar, x, y) + sc * E_C(idx, yvar, x, z) + sb * sc * E_BC(idx, yvar, x, y, z))


def prob_B(idx, yvar, b: int, x: int, y: int):
    sb = 1.0 if b == 0 else -1.0
    return 0.5 * (1.0 + sb * E_B(idx, yvar, x, y))


def witness_expression(idx, yvar, terms):
    return sum(coeff * E_BC(idx, yvar, x, y, z) for coeff, x, y, z in terms)


def add_probability_positivity(constraints: list, idx, yvar) -> None:
    for x in range(N_X):
        for y in range(N_B):
            for z in range(N_C):
                probs = [prob_BC(idx, yvar, b, c, x, y, z) for b in (0, 1) for c in (0, 1)]
                constraints.append(cp.hstack(probs) >= 0.0)
                # sum(probs)==1 é uma identidade algébrica e é omitida.


# =============================================================================
# 7. Template SDP de função suporte
# =============================================================================


def guess_representatives():
    if MODE == "joint":
        return ((0, 0), (0, 1), (1, 0), (1, 1)) if DISABLE_SYMMETRY else ((0, 0), (0, 1))
    return (0, 1) if DISABLE_SYMMETRY else (0,)


def guess_label(guess) -> str:
    if MODE == "joint":
        return f"g{guess[0]}{guess[1]}"
    return f"g{int(guess)}"


def symmetry_class(guess) -> str:
    if MODE == "joint":
        return "even" if guess[0] == guess[1] else "odd"
    return "bob"


def choose_solver() -> str:
    if cp is None:
        raise RuntimeError("CVXPY não foi importado.")
    installed = set(cp.installed_solvers())
    if SOLVER_REQUESTED == "MOSEK":
        if "MOSEK" not in installed:
            raise RuntimeError(f"MOSEK solicitado, mas não instalado. Disponíveis: {sorted(installed)}")
        return "MOSEK"
    if SOLVER_REQUESTED == "SCS":
        if "SCS" not in installed:
            raise RuntimeError(f"SCS solicitado, mas não instalado. Disponíveis: {sorted(installed)}")
        return "SCS"
    if "MOSEK" in installed:
        return "MOSEK"
    if "SCS" in installed:
        return "SCS"
    raise RuntimeError(f"Nenhum solver SDP suportado foi encontrado. Disponíveis: {sorted(installed)}")


def solve_cvxpy_problem(problem):
    solver = choose_solver()
    if solver == "MOSEK":
        try:
            value = problem.solve(
                solver=cp.MOSEK,
                warm_start=True,
                verbose=VERBOSE_SOLVER,
                mosek_params={
                    "MSK_DPAR_INTPNT_CO_TOL_PFEAS": MOSEK_EPS,
                    "MSK_DPAR_INTPNT_CO_TOL_DFEAS": MOSEK_EPS,
                    "MSK_DPAR_INTPNT_CO_TOL_REL_GAP": MOSEK_EPS,
                    "MSK_IPAR_INTPNT_SOLVE_FORM": "MSK_SOLVE_DUAL",
                },
            )
            return value, solver
        except Exception as exc:
            if SOLVER_REQUESTED != "AUTO" or "SCS" not in cp.installed_solvers():
                raise
            print(f"AVISO: MOSEK falhou ({exc}). Tentando SCS.", flush=True)
            solver = "SCS"

    value = problem.solve(
        solver=cp.SCS,
        eps=SCS_EPS,
        max_iters=SCS_MAX_ITERS,
        use_indirect=SCS_USE_INDIRECT,
        normalize=SCS_NORMALIZE,
        scale=SCS_SCALE,
        alpha=SCS_ALPHA,
        acceleration_lookback=SCS_ACCELERATION_LOOKBACK,
        warm_start=True,
        verbose=VERBOSE_SOLVER,
    )
    return value, solver


class SupportTemplate:
    def __init__(self, facet: str, generation_input, guess):
        if cp is None:
            raise RuntimeError("CVXPY não foi importado neste modo.")
        self.facet = facet
        self.data = WITNESSES[facet]
        self.generation_input = generation_input
        self.guess = guess

        A_q = generate_A(Q_SCALAR)
        A_qminus = generate_A(Q_SCALAR - 1)
        S = generate_S(LEVEL)
        self.A_size = len(A_q)
        self.S_size = len(S)

        self.idx = MomentIndexer()
        self.rows = build_rows(A_q, S)
        self.M, self.yvar = build_moment_matrix(self.rows, self.idx)

        self.constraints = [PSD(self.M)]
        add_frame_constraints(self.constraints, self.idx, self.yvar)
        add_preparation_constraints(self.constraints, self.idx, self.yvar, A_qminus, S)
        add_weighted_frame_constraints(self.constraints, self.idx, self.yvar)
        if ENFORCE_PROBABILITY_POSITIVITY:
            add_probability_positivity(self.constraints, self.idx, self.yvar)

        self.W = witness_expression(self.idx, self.yvar, self.data["terms"])
        if MODE == "joint":
            x, y, z = generation_input
            b, c = guess
            self.P = prob_BC(self.idx, self.yvar, b, c, x, y, z)
        else:
            x, y = generation_input
            self.P = prob_B(self.idx, self.yvar, int(guess), x, y)

        self.W_reference = float(self.data["quantum_reference"])
        self.tau = cp.Parameter(nonneg=True, value=0.0, name=f"tau_{facet}_{guess_label(guess)}")
        self.centered_objective = cp.real(
            self.P + self.tau * (self.W - self.W_reference)
        )
        self.problem = cp.Problem(cp.Maximize(self.centered_objective), self.constraints)
        if not self.problem.is_dcp():
            raise RuntimeError("Problema de função suporte não é DCP.")

    def solve(self, tau: float) -> dict:
        self.tau.value = float(tau)
        t0 = time.time()
        value, solver_used = solve_cvxpy_problem(self.problem)
        elapsed = time.time() - t0
        status = self.problem.status
        if status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE} or value is None:
            return {
                "facet": self.facet,
                "guess": guess_label(self.guess),
                "symmetry_class": symmetry_class(self.guess),
                "tau": float(tau),
                "status": str(status),
                "solver_used": solver_used,
                "support_raw": np.nan,
                "support_upper": np.nan,
                "time_s": elapsed,
            }

        raw = float(np.real(value))
        p_raw = float(np.real(self.P.value))
        w_raw = float(np.real(self.W.value))
        diag = scs_diagnostics(self.problem.solver_stats) if solver_used == "SCS" else {
            "res_pri": np.nan, "res_dual": np.nan, "gap": np.nan,
            "pobj": np.nan, "dobj": np.nan, "iter": np.nan,
        }

        # Para SCS, quando disponível, -dobj é usado como candidato dual.
        # Para MOSEK usamos o valor ótimo retornado e uma margem explícita.
        dual_upper = np.nan
        if solver_used == "SCS" and np.isfinite(diag.get("dobj", np.nan)):
            dual_upper = -float(diag["dobj"])
        base_upper = raw if not np.isfinite(dual_upper) else max(raw, dual_upper)
        residual_scale = max(
            abs(float(diag.get("res_pri", 0.0))) if np.isfinite(diag.get("res_pri", np.nan)) else 0.0,
            abs(float(diag.get("res_dual", 0.0))) if np.isfinite(diag.get("res_dual", np.nan)) else 0.0,
            abs(float(diag.get("gap", 0.0))) if np.isfinite(diag.get("gap", np.nan)) else 0.0,
        )
        margin = (
            SUPPORT_ABS_PADDING
            + SUPPORT_REL_PADDING * max(1.0, abs(base_upper))
            + RESIDUAL_MULTIPLIER * residual_scale
        )
        support_upper = base_upper + margin

        return {
            "facet": self.facet,
            "guess": guess_label(self.guess),
            "symmetry_class": symmetry_class(self.guess),
            "tau": float(tau),
            "status": str(status),
            "solver_used": solver_used,
            "support_raw": raw,
            "support_dual_upper": dual_upper,
            "support_margin": margin,
            "support_upper": support_upper,
            "p_guess_at_support": p_raw,
            "witness_at_support": w_raw,
            "time_s": elapsed,
            "matrix_size": len(self.rows),
            "real_variables": len(self.idx.pos_to_key),
            "n_constraints": len(self.problem.constraints),
            "A_size": self.A_size,
            "S_size": self.S_size,
            "level": LEVEL,
            "q_scalar": Q_SCALAR,
            "probability_positivity": ENFORCE_PROBABILITY_POSITIVITY,
            "peak_rss_gb": peak_rss_gb(),
            **diag,
        }


# =============================================================================
# 8. Diagnósticos SCS e utilidades
# =============================================================================


def scs_diagnostics(stats) -> dict:
    out = {"res_pri": np.nan, "res_dual": np.nan, "gap": np.nan, "pobj": np.nan, "dobj": np.nan, "iter": np.nan}
    extra = getattr(stats, "extra_stats", None)
    info = None
    if isinstance(extra, dict):
        info = extra.get("info", extra)
    if isinstance(info, dict):
        for key in out:
            value = info.get(key, info.get({"res_pri": "res_pri", "res_dual": "res_dual"}.get(key, key), np.nan))
            try:
                out[key] = float(value)
            except (TypeError, ValueError):
                pass
    if not np.isfinite(out["iter"]):
        try:
            out["iter"] = float(getattr(stats, "num_iters", np.nan))
        except (TypeError, ValueError):
            pass
    return out


def peak_rss_gb() -> float:
    """Retorna o pico de RAM em GB quando disponível.

    Em Linux/macOS usa o módulo ``resource``. No Windows nativo, onde esse
    módulo não existe, tenta usar ``psutil``; se ele também não estiver
    instalado, retorna NaN. Esse valor é apenas diagnóstico e não altera a SDP.
    """
    try:
        if resource is not None:
            value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # Linux: KiB; macOS: bytes.
            return (
                float(value) / (1024.0 ** 2)
                if sys.platform != "darwin"
                else float(value) / (1024.0 ** 3)
            )

        try:
            import psutil
        except ImportError:
            return np.nan

        process = psutil.Process(os.getpid())
        return float(process.memory_info().rss) / (1024.0 ** 3)
    except Exception:
        return np.nan


def level_tag() -> str:
    return LEVEL.replace("+", "p") + f"_q{Q_SCALAR}"


def input_tag(generation_input) -> str:
    return "_".join(str(int(v)) for v in generation_input)


def task_support_csv(facet: str, generation_input) -> Path:
    return OUTPUT_DIR / f"support_{MODE_TAG}_{facet}_input_{input_tag(generation_input)}_{level_tag()}.csv"


def task_curve_csv(facet: str, generation_input) -> Path:
    return OUTPUT_DIR / f"curve_{MODE_TAG}_{facet}_input_{input_tag(generation_input)}_{level_tag()}.csv"


def task_physical_csv(facet: str, generation_input) -> Path:
    return OUTPUT_DIR / f"physical_{MODE_TAG}_{facet}_input_{input_tag(generation_input)}_{level_tag()}.csv"


def safe_save_csv(path: Path, rows_or_frame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(rows_or_frame, pd.DataFrame):
        frame = rows_or_frame
    else:
        frame = pd.DataFrame(list(rows_or_frame))
    tmp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(tmp, index=False)
    tmp.replace(path)


def load_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def tau_key(tau: float) -> str:
    return f"{float(tau):.14g}"


def midpoint(a: float, b: float) -> float:
    if a < 0 or b < 0:
        raise ValueError("tau negativo")
    if a == b:
        return a
    if a > 0 and b > 0 and b / a > 3:
        return float(math.sqrt(a * b))
    return 0.5 * (a + b)


# =============================================================================
# 9. Reconstrução G(w) pela função suporte
# =============================================================================


def support_envelope(support_df: pd.DataFrame) -> pd.DataFrame:
    good = support_df[
        support_df["support_upper"].notna()
        & np.isfinite(support_df["support_upper"])
        & support_df["tau"].notna()
    ].copy()
    if good.empty:
        return good
    # máximo sobre as classes de palpite para cada tau
    idx = good.groupby("tau")["support_upper"].idxmax()
    env = good.loc[idx].sort_values("tau").reset_index(drop=True)
    env = env.rename(columns={"guess": "active_guess", "symmetry_class": "active_symmetry_class"})
    return env


def reconstruct_curve(facet: str, generation_input, support_df: pd.DataFrame) -> pd.DataFrame:
    env = support_envelope(support_df)
    if env.empty:
        return pd.DataFrame()
    taus = env["tau"].to_numpy(dtype=float)
    supports = env["support_upper"].to_numpy(dtype=float)
    active_guess = env["active_guess"].astype(str).to_numpy()
    rows = []
    data = WITNESSES[facet]
    wc = data["classical"]
    wq = data["quantum_reference"]
    for w in witness_grid(facet):
        lines = supports + taus * (wq - float(w))
        k = int(np.nanargmin(lines))
        raw_upper = float(lines[k])
        # tau=0 fornece o bound trivial G<=1; clamp superior é exato.
        g_upper = min(1.0, raw_upper)
        valid = bool(np.isfinite(g_upper) and g_upper > 0)
        h_lower = -math.log2(g_upper) if valid else np.nan
        row = {
            "facet": facet,
            "mode": MODE,
            "input_tag": input_tag(generation_input),
            "w_lower": float(w),
            "w_classical": wc,
            "w_quantum_reference": wq,
            "violation_normalized": float((w - wc) / (wq - wc)) if wq != wc else np.nan,
            "p_guess_upper_raw_support": raw_upper,
            "p_guess_upper": g_upper,
            "h_min_lower": h_lower,
            "tau_star": float(taus[k]),
            "tau_at_boundary": bool(k == 0 or k == len(taus) - 1),
            "tau_left_gap": float(taus[k] - taus[k - 1]) if k > 0 else np.nan,
            "tau_right_gap": float(taus[k + 1] - taus[k]) if k + 1 < len(taus) else np.nan,
            "tau_in_focus_window": bool(TAU_FOCUS_MIN <= taus[k] <= TAU_FOCUS_MAX),
            "active_guess": active_guess[k],
            "support_at_tau_star": float(supports[k]),
            "n_tau": int(len(taus)),
            "valid": valid,
        }
        for j, value in enumerate(generation_input):
            row[("x_star", "y_star", "z_star")[j]] = int(value)
        # Endpoint analítico provado para a órbita de paridade ímpar.
        parity_odd_orbit = {(0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 1, 1)}
        if tuple(generation_input) in parity_odd_orbit and abs(float(w) - wq) <= 1e-12:
            row["p_guess_upper_raw_support"] = 0.25
            row["p_guess_upper"] = 0.25
            row["h_min_lower"] = 2.0
            row["active_guess"] = "analytic_endpoint"
            row["endpoint_source"] = "analytic_theorem"
        else:
            row["endpoint_source"] = "support_SDP"
        rows.append(row)
    frame = pd.DataFrame(rows).sort_values("w_lower").reset_index(drop=True)
    # G deve ser não crescente em w. O cumulative minimum usa bounds de pontos
    # anteriores e continua conservador para pontos posteriores.
    frame["p_guess_upper_monotone"] = np.minimum.accumulate(frame["p_guess_upper"].to_numpy(dtype=float))
    frame["h_min_lower_monotone"] = -np.log2(np.clip(frame["p_guess_upper_monotone"], 1e-300, 1.0))
    return frame


def certification_threshold_from_support(
    facet: str, generation_input, support_df: pd.DataFrame
) -> Dict[str, float]:
    """Limiar contínuo de certificação induzido pelo envelope de suporte.

    Para cada tau>0, a reta do upper bound é

        G_tau(w) = support(tau) + tau * (W_Q-w).

    A entropia passa a ser positiva quando min_tau G_tau(w) < 1. Portanto,
    cada reta cruza G=1 em

        w_tau = W_Q - (1-support(tau))/tau,

    e o primeiro valor certificado pelo envelope discreto de taus é o menor
    desses cruzamentos. Isso evita depender da resolução da grade usada apenas
    para desenhar a curva. O resultado continua conservador porque usa os
    upper bounds SDP já acolchoados.
    """
    env = support_envelope(support_df)
    data = WITNESSES[facet]
    wc = float(data["classical"])
    wq = float(data["quantum_reference"])
    if env.empty:
        return {
            "facet": facet, "input_tag": input_tag(generation_input),
            "w_cert_support": np.nan, "normalized_violation_cert": np.nan,
            "visibility_cert_white_noise": np.nan, "tau_cert": np.nan,
            "support_at_tau_cert": np.nan, "active_guess_at_cert": "",
        }

    candidates = []
    for row in env.itertuples(index=False):
        tau = float(row.tau)
        support = float(row.support_upper)
        if not np.isfinite(tau) or not np.isfinite(support) or tau <= 0:
            continue
        w_cross = wq - (1.0 - support) / tau
        # Restringe ao intervalo físico exibido. Se o cruzamento vier abaixo de
        # W_C, o certificado já é positivo no início da região de violação.
        w_cross = min(wq, max(wc, float(w_cross)))
        candidates.append((w_cross, tau, support, str(row.active_guess)))

    if not candidates:
        return {
            "facet": facet, "input_tag": input_tag(generation_input),
            "w_cert_support": np.nan, "normalized_violation_cert": np.nan,
            "visibility_cert_white_noise": np.nan, "tau_cert": np.nan,
            "support_at_tau_cert": np.nan, "active_guess_at_cert": "",
        }

    w_cert, tau_cert, support_cert, guess_cert = min(candidates, key=lambda x: x[0])
    nu_cert = (w_cert - wc) / (wq - wc) if wq != wc else np.nan
    # Para a família p_v = v p_opt + (1-v) p_white, a CC2 tem valor zero
    # no ruído branco, então W(v)=v W_Q.
    visibility = w_cert / wq if wq != 0 else np.nan
    return {
        "facet": facet,
        "input_tag": input_tag(generation_input),
        "x_star": int(generation_input[0]),
        "y_star": int(generation_input[1]),
        "z_star": int(generation_input[2]),
        "w_classical": wc,
        "w_quantum_reference": wq,
        "w_cert_support": float(w_cert),
        "normalized_violation_cert": float(nu_cert),
        "visibility_cert_white_noise": float(visibility),
        "tau_cert": float(tau_cert),
        "support_at_tau_cert": float(support_cert),
        "active_guess_at_cert": guess_cert,
        "criterion": "continuous support-envelope crossing G_UB=1",
        "level": LEVEL,
        "q_scalar": Q_SCALAR,
    }


def sampled_first_positive_threshold(curve: pd.DataFrame) -> Dict[str, float]:
    """Diagnóstico da grade: primeiro ponto salvo com H_min>tolerância."""
    if curve.empty:
        return {"sampled_first_positive_w": np.nan,
                "sampled_first_positive_nu": np.nan,
                "sampled_first_positive_hmin": np.nan}
    pos = curve[curve["h_min_lower_monotone"] > CERT_H_TOL]
    if pos.empty:
        return {"sampled_first_positive_w": np.nan,
                "sampled_first_positive_nu": np.nan,
                "sampled_first_positive_hmin": np.nan}
    row = pos.sort_values("w_lower").iloc[0]
    return {
        "sampled_first_positive_w": float(row["w_lower"]),
        "sampled_first_positive_nu": float(row["violation_normalized"]),
        "sampled_first_positive_hmin": float(row["h_min_lower_monotone"]),
    }


def _tau_spacing_tolerance(tau: float) -> float:
    return max(TAU_REFINE_ABS_TOL, TAU_REFINE_REL_TOL * max(1.0, abs(float(tau))))


def refinement_taus(facet: str, support_df: pd.DataFrame) -> List[float]:
    """Refina os intervalos adjacentes aos minimizadores ativos.

    Para cada valor de W da curva, localiza o tau da grade que minimiza
    F(tau)-tau*W e subdivide seus intervalos vizinhos enquanto a largura for
    maior que a tolerância configurada. Se o mínimo cair na borda direita,
    a grade é expandida. Todos os novos pontos são SDPs efetivamente resolvidas;
    portanto, a reconstrução continua sendo um upper bound conservador.
    """
    env = support_envelope(support_df)
    if len(env) < 2:
        return []
    taus = env["tau"].to_numpy(dtype=float)
    supports = env["support_upper"].to_numpy(dtype=float)
    additions = set()

    wq = float(WITNESSES[facet]["quantum_reference"])
    for w in witness_grid(facet):
        # O endpoint exato não deve forçar uma expansão artificial de tau.
        # Para a órbita O_B ele é inserido analiticamente; para as demais,
        # a faixa configurada PAB_TAU_MAX já determina a resolução numérica.
        if abs(float(w) - wq) <= 1e-12:
            continue
        k = int(np.nanargmin(supports + taus * (wq - float(w))))
        tau_star = float(taus[k])
        tol = _tau_spacing_tolerance(tau_star)

        for left, right in ((k - 1, k), (k, k + 1)):
            if 0 <= left < len(taus) and 0 <= right < len(taus):
                gap = float(taus[right] - taus[left])
                if gap > tol:
                    m = midpoint(float(taus[left]), float(taus[right]))
                    if all(abs(m - t) > 1e-12 * max(1.0, abs(t)) for t in taus):
                        additions.add(m)

        # Um mínimo na maior tau disponível pode indicar faixa insuficiente.
        if k == len(taus) - 1 and tau_star < TAU_MAX_DEFAULT:
            right = min(
                TAU_MAX_DEFAULT,
                max(2.0 * tau_star, tau_star + max(1.0, 0.5 * tau_star)),
            )
            if right > tau_star + _tau_spacing_tolerance(tau_star) and all(
                abs(right - t) > 1e-12 * max(1.0, abs(t)) for t in taus
            ):
                additions.add(right)

    ordered = sorted(additions)
    if TAU_MAX_NEW_PER_ROUND > 0 and len(ordered) > TAU_MAX_NEW_PER_ROUND:
        # Prioriza os pontos próximos à janela focal e, depois, os menores tau.
        center = 0.5 * (TAU_FOCUS_MIN + TAU_FOCUS_MAX)
        ordered = sorted(
            ordered,
            key=lambda t: (
                0 if TAU_FOCUS_MIN <= t <= TAU_FOCUS_MAX else 1,
                abs(t - center),
                t,
            ),
        )[:TAU_MAX_NEW_PER_ROUND]
        ordered.sort()
    return ordered


def max_curve_tightening(before: pd.DataFrame, after: pd.DataFrame) -> float:
    """Maior redução do upper bound de G causada por novos valores de tau."""
    if before.empty or after.empty:
        return np.inf
    left = before[["w_lower", "p_guess_upper"]].rename(
        columns={"p_guess_upper": "g_before"}
    )
    right = after[["w_lower", "p_guess_upper"]].rename(
        columns={"p_guess_upper": "g_after"}
    )
    merged = left.merge(right, on="w_lower", how="inner")
    if merged.empty:
        return np.inf
    gains = merged["g_before"].to_numpy(float) - merged["g_after"].to_numpy(float)
    return float(max(0.0, np.nanmax(gains)))


# =============================================================================
# 10. Lower bound físico opcional
# =============================================================================

SIGMA_X = np.array([[0, 1], [1, 0]], dtype=complex)
SIGMA_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
SIGMA_Z = np.array([[1, 0], [0, -1]], dtype=complex)
ID2 = np.eye(2, dtype=complex)


def complex_from_real(vec: np.ndarray, shape: Tuple[int, ...]) -> np.ndarray:
    n = int(np.prod(shape))
    return vec[:n].reshape(shape) + 1j * vec[n:2 * n].reshape(shape)


def qr_isometry(A: np.ndarray, ncols: int = 2) -> np.ndarray:
    Q, R = np.linalg.qr(A)
    Q = Q[:, :ncols]
    diag = np.diag(R[:ncols, :ncols])
    phases = np.ones_like(diag)
    mask = np.abs(diag) > 1e-12
    phases[mask] = diag[mask] / np.abs(diag[mask])
    return Q * phases.conj()[None, :]


def bloch_observable(theta: float, phi: float) -> np.ndarray:
    nx = np.sin(theta) * np.cos(phi)
    ny = np.sin(theta) * np.sin(phi)
    nz = np.cos(theta)
    return nx * SIGMA_X + ny * SIGMA_Y + nz * SIGMA_Z


def unpack_physical(theta: np.ndarray):
    rawU = complex_from_real(theta[:16], (4, 2))
    U = qr_isometry(rawU, 2)
    pos = 16
    Bobs = []
    for _ in range(N_B):
        Bobs.append(bloch_observable(theta[pos], theta[pos + 1]))
        pos += 2
    Charlies = []
    for _ in range(N_C):
        Charlies.append(bloch_observable(theta[pos], theta[pos + 1]))
        pos += 2
    return U, Bobs, Charlies


def support_coefficients(facet: str, generation_input, guess, tau: float):
    coeff_B = np.zeros((N_X, N_B), dtype=float)
    coeff_C = np.zeros((N_X, N_C), dtype=float)
    coeff_BC = np.zeros((N_X, N_B, N_C), dtype=float)
    if MODE == "joint":
        x, y, z = generation_input
        b, c = guess
        sb = 1.0 if b == 0 else -1.0
        sc = 1.0 if c == 0 else -1.0
        const = 0.25
        coeff_B[x, y] += 0.25 * sb
        coeff_C[x, z] += 0.25 * sc
        coeff_BC[x, y, z] += 0.25 * sb * sc
    else:
        x, y = generation_input
        b = int(guess)
        sb = 1.0 if b == 0 else -1.0
        const = 0.5
        coeff_B[x, y] += 0.5 * sb
    for coeff, x, y, z in WITNESSES[facet]["terms"]:
        coeff_BC[x, y, z] += float(tau) * coeff
    const -= float(tau) * float(WITNESSES[facet]["quantum_reference"])
    return const, coeff_B, coeff_C, coeff_BC


def effective_operator(U, Bobs, Charlies, coeff_B, coeff_C, coeff_BC, x: int):
    O = np.zeros((4, 4), dtype=complex)
    for y in range(N_B):
        O += coeff_B[x, y] * np.kron(Bobs[y], ID2)
    for z in range(N_C):
        O += coeff_C[x, z] * np.kron(ID2, Charlies[z])
    for y in range(N_B):
        for z in range(N_C):
            O += coeff_BC[x, y, z] * np.kron(Bobs[y], Charlies[z])
    K = U.conj().T @ O @ U
    return 0.5 * (K + K.conj().T)


def physical_support_value(theta, facet, generation_input, guess, tau):
    U, Bobs, Charlies = unpack_physical(theta)
    const, coeff_B, coeff_C, coeff_BC = support_coefficients(facet, generation_input, guess, tau)
    value = const
    for x in range(N_X):
        value += np.max(np.linalg.eigvalsh(effective_operator(U, Bobs, Charlies, coeff_B, coeff_C, coeff_BC, x)))
    return float(np.real(value))


def reconstruct_physical(theta, facet, generation_input, guess, tau):
    U, Bobs, Charlies = unpack_physical(theta)
    const, coeff_B, coeff_C, coeff_BC = support_coefficients(facet, generation_input, guess, tau)
    psis = []
    for x in range(N_X):
        vals, vecs = np.linalg.eigh(effective_operator(U, Bobs, Charlies, coeff_B, coeff_C, coeff_BC, x))
        psis.append(vecs[:, int(np.argmax(vals))])

    EB = np.zeros((N_X, N_B))
    EC = np.zeros((N_X, N_C))
    EBC = np.zeros((N_X, N_B, N_C))
    for x in range(N_X):
        phi = U @ psis[x]
        for y in range(N_B):
            EB[x, y] = float(np.real(np.vdot(phi, np.kron(Bobs[y], ID2) @ phi)))
        for z in range(N_C):
            EC[x, z] = float(np.real(np.vdot(phi, np.kron(ID2, Charlies[z]) @ phi)))
        for y in range(N_B):
            for z in range(N_C):
                EBC[x, y, z] = float(np.real(np.vdot(phi, np.kron(Bobs[y], Charlies[z]) @ phi)))

    W = sum(coeff * EBC[x, y, z] for coeff, x, y, z in WITNESSES[facet]["terms"])
    if MODE == "joint":
        x, y, z = generation_input
        b, c = guess
        sb = 1.0 if b == 0 else -1.0
        sc = 1.0 if c == 0 else -1.0
        P = 0.25 * (1 + sb * EB[x, y] + sc * EC[x, z] + sb * sc * EBC[x, y, z])
    else:
        x, y = generation_input
        b = int(guess)
        sb = 1.0 if b == 0 else -1.0
        P = 0.5 * (1 + sb * EB[x, y])
    return float(P), float(W), float(P + tau * (W - WITNESSES[facet]["quantum_reference"]))


def optimize_physical_support(facet, generation_input, guess, tau, previous: Optional[np.ndarray], seed: int):
    rng = np.random.default_rng(seed)
    starts: List[np.ndarray] = []
    if previous is not None:
        starts.extend([previous.copy(), previous + 0.03 * rng.normal(size=24), previous + 0.10 * rng.normal(size=24)])
    starts.append(0.3 * rng.normal(size=24))
    for _ in range(PHYSICAL_RESTARTS):
        starts.append(rng.normal(size=24))
    scale = 1.0 + abs(float(tau)) * max(1.0, abs(WITNESSES[facet]["quantum_reference"]))

    def objective(th):
        return -physical_support_value(th, facet, generation_input, guess, tau) / scale

    best_theta = None
    best_val = -np.inf
    best_status = "none"
    for start in starts:
        res = minimize(
            objective,
            start,
            method="L-BFGS-B",
            options={"maxiter": PHYSICAL_MAXITER, "ftol": 1e-11, "gtol": 1e-8},
        )
        val = physical_support_value(res.x, facet, generation_input, guess, tau)
        if val > best_val:
            best_val = val
            best_theta = res.x.copy()
            best_status = str(res.message)
    P, W, support = reconstruct_physical(best_theta, facet, generation_input, guess, tau)
    return best_theta, {
        "facet": facet,
        "guess": guess_label(guess),
        "symmetry_class": symmetry_class(guess),
        "tau": float(tau),
        "support_lower": support,
        "p_guess_physical": P,
        "witness_physical": W,
        "optimizer_status": best_status,
    }


def physical_convex_hull_curve(facet: str, generation_input, physical_df: pd.DataFrame) -> pd.DataFrame:
    if physical_df.empty:
        return pd.DataFrame()
    good = physical_df[
        np.isfinite(physical_df["p_guess_physical"])
        & np.isfinite(physical_df["witness_physical"])
    ].copy()
    if good.empty:
        return pd.DataFrame()
    p = good["p_guess_physical"].to_numpy(dtype=float)
    W = good["witness_physical"].to_numpy(dtype=float)
    n = len(good)
    rows = []
    for w in witness_grid(facet):
        res = linprog(
            c=-p,
            A_ub=np.array([-W]),
            b_ub=np.array([-float(w)]),
            A_eq=np.ones((1, n)),
            b_eq=np.array([1.0]),
            bounds=[(0.0, None)] * n,
            method="highs",
        )
        g_lower = float(-res.fun) if res.success else np.nan
        row = {
            "facet": facet,
            "input_tag": input_tag(generation_input),
            "w_lower": float(w),
            "p_guess_achievable_lower": g_lower,
            "h_min_physical_upper": -math.log2(g_lower) if np.isfinite(g_lower) and g_lower > 0 else np.nan,
            "lp_status": str(res.message),
        }
        rows.append(row)
    return pd.DataFrame(rows)


# =============================================================================
# 11. Execução de uma tarefa
# =============================================================================


def run_support_task(facet: str, generation_input) -> None:
    new_solves_this_process = 0
    print("=" * 88)
    print(f"MODE={MODE} facet={facet} input={generation_input} level={LEVEL} q={Q_SCALAR}")
    print(f"guesses={guess_representatives()} symmetry_disabled={DISABLE_SYMMETRY}")
    print(f"tau_initial_count={len(TAU_INITIAL)} tau_min={float(TAU_INITIAL.min()):.12g} tau_max={float(TAU_INITIAL.max()):.12g}")
    print("=" * 88)

    support_path = task_support_csv(facet, generation_input)
    support_df = load_csv(support_path) if RESUME else pd.DataFrame()
    existing = set()
    if not support_df.empty:
        existing = {(str(r.guess), tau_key(float(r.tau))) for r in support_df.itertuples()}

    templates = {guess_label(g): SupportTemplate(facet, generation_input, g) for g in guess_representatives()}

    def solve_missing(taus: Iterable[float]) -> None:
        nonlocal support_df, existing, new_solves_this_process
        rows = support_df.to_dict("records") if not support_df.empty else []
        for tau in sorted({float(t) for t in taus}):
            for guess in guess_representatives():
                glabel = guess_label(guess)
                key = glabel, tau_key(tau)
                if key in existing:
                    continue
                print(f"  solve guess={glabel} tau={tau:.12g}", flush=True)
                # tau=0 is the exact trivial support bound max P_guess = 1.
                # Do not send this degenerate objective to the SDP solver: on
                # some Windows/MOSEK installations it may terminate the Python
                # process before any checkpoint is written.
                if abs(tau) <= 1e-15:
                    row = {
                        "facet": facet,
                        "guess": glabel,
                        "symmetry_class": symmetry_class(guess),
                        "tau": 0.0,
                        "status": "analytic_trivial_tau0",
                        "solver_used": "analytic",
                        "support_raw": 1.0,
                        "support_dual_upper": 1.0,
                        "support_margin": 0.0,
                        "support_upper": 1.0,
                        "p_guess_at_support": 1.0,
                        "witness_at_support": np.nan,
                        "time_s": 0.0,
                        "matrix_size": templates[glabel].S_size * templates[glabel].A_size,
                        "real_variables": len(templates[glabel].idx.pos_to_key),
                        "n_constraints": len(templates[glabel].problem.constraints),
                        "A_size": templates[glabel].A_size,
                        "S_size": templates[glabel].S_size,
                        "level": LEVEL,
                        "q_scalar": Q_SCALAR,
                        "probability_positivity": ENFORCE_PROBABILITY_POSITIVITY,
                        "peak_rss_gb": peak_rss_gb(),
                    }
                else:
                    row = templates[glabel].solve(tau)
                for j, value in enumerate(generation_input):
                    row[("x_star", "y_star", "z_star")[j]] = int(value)
                row["mode"] = MODE
                rows.append(row)
                existing.add(key)
                support_df = pd.DataFrame(rows)
                safe_save_csv(support_path, support_df)
                new_solves_this_process += 1
                print(
                    f"    status={row['status']} support_upper={row.get('support_upper', np.nan):.10g} "
                    f"W={row.get('witness_at_support', np.nan):.10g} P={row.get('p_guess_at_support', np.nan):.10g}",
                    flush=True,
                )
                if (
                    MAX_NEW_SOLVES_PER_PROCESS > 0
                    and new_solves_this_process >= MAX_NEW_SOLVES_PER_PROCESS
                ):
                    print(
                        f"CHECKPOINT: {new_solves_this_process} novos solves foram salvos. "
                        "Reiniciando o processo para liberar RAM nativa...",
                        flush=True,
                    )
                    raise ProcessRecycleRequested

    solve_missing(TAU_INITIAL)
    curve_before = reconstruct_curve(facet, generation_input, support_df)
    for round_idx in range(TAU_REFINE_ROUNDS):
        additions = refinement_taus(facet, support_df)
        if not additions:
            print("Grade de tau localmente refinada até a tolerância configurada.")
            break
        print(
            f"Refinamento tau {round_idx + 1}/{TAU_REFINE_ROUNDS}: "
            f"{len(additions)} novo(s) ponto(s); faixa "
            f"[{min(additions):.8g}, {max(additions):.8g}]",
            flush=True,
        )
        solve_missing(additions)
        curve_after = reconstruct_curve(facet, generation_input, support_df)
        tightening = max_curve_tightening(curve_before, curve_after)
        print(
            f"  maior aperto do upper bound de G nesta rodada: {tightening:.3e}",
            flush=True,
        )
        curve_before = curve_after
        if tightening <= TAU_BOUND_IMPROVEMENT_TOL:
            # Ainda preserva o rigor: apenas encerra quando os novos suportes
            # praticamente não alteram o bound na grade de W solicitada.
            print(
                "  critério de convergência da grade de tau atingido; "
                "encerrando o refinamento adaptativo.",
                flush=True,
            )
            break

    curve = reconstruct_curve(facet, generation_input, support_df)

    if RUN_PHYSICAL_LOWER:
        physical_path = task_physical_csv(facet, generation_input)
        physical_df = load_csv(physical_path) if RESUME else pd.DataFrame()
        phys_existing = set()
        if not physical_df.empty:
            phys_existing = {(str(r.guess), tau_key(float(r.tau))) for r in physical_df.itertuples()}
        phys_rows = physical_df.to_dict("records") if not physical_df.empty else []
        previous: Dict[str, Optional[np.ndarray]] = {guess_label(g): None for g in guess_representatives()}
        taus = sorted(set(support_df["tau"].dropna().astype(float)))
        for tau_idx, tau in enumerate(taus):
            for guess_idx, guess in enumerate(guess_representatives()):
                glabel = guess_label(guess)
                key = glabel, tau_key(tau)
                if key in phys_existing:
                    continue
                print(f"  physical guess={glabel} tau={tau:.12g}")
                theta, row = optimize_physical_support(
                    facet,
                    generation_input,
                    guess,
                    tau,
                    previous[glabel],
                    PHYSICAL_SEED + 100000 * tau_idx + 1000 * guess_idx,
                )
                previous[glabel] = theta
                for j, value in enumerate(generation_input):
                    row[("x_star", "y_star", "z_star")[j]] = int(value)
                row["mode"] = MODE
                phys_rows.append(row)
                phys_existing.add(key)
                physical_df = pd.DataFrame(phys_rows)
                safe_save_csv(physical_path, physical_df)
        lower_curve = physical_convex_hull_curve(facet, generation_input, physical_df)
        if not lower_curve.empty:
            curve = curve.merge(lower_curve, on=["facet", "input_tag", "w_lower"], how="left")

    safe_save_csv(task_curve_csv(facet, generation_input), curve)

    threshold = certification_threshold_from_support(facet, generation_input, support_df)
    threshold.update(sampled_first_positive_threshold(curve))
    threshold_path = OUTPUT_DIR / (
        f"threshold_{MODE_TAG}_{facet}_input_{input_tag(generation_input)}_{level_tag()}.csv"
    )
    safe_save_csv(threshold_path, [threshold])
    print(
        "Limiar contínuo pelo envelope: "
        f"W_cert={threshold.get('w_cert_support', np.nan):.12g}, "
        f"nu_cert={threshold.get('normalized_violation_cert', np.nan):.12g}, "
        f"v_cert={threshold.get('visibility_cert_white_noise', np.nan):.12g}"
    )

    if SAVE_INPUT_PLOTS and not curve.empty:
        plot_single_input(facet, generation_input, curve)
    print(f"Salvo: {task_curve_csv(facet, generation_input)}")


# =============================================================================
# 12. Agregação e gráficos
# =============================================================================


def all_inputs():
    if MODE == "joint":
        return REPRESENTATIVE_INPUTS
    # Esta versão foi preparada especificamente para a randomness conjunta BC.
    return tuple((x, y) for x, y, _ in REPRESENTATIVE_INPUTS)


def all_tasks():
    return [(facet, inp) for facet in FACETS for inp in all_inputs()]


def plot_single_input(facet: str, generation_input, curve: pd.DataFrame) -> Path:
    fig, ax = plt.subplots(figsize=(6.4, 4.5))
    ax.plot(curve["w_lower"], curve["h_min_lower_monotone"], marker="o", label="SDP lower bound")
    if "h_min_physical_upper" in curve and curve["h_min_physical_upper"].notna().any():
        ax.plot(curve["w_lower"], curve["h_min_physical_upper"], marker="s", linestyle="--", label="physical upper estimate")
    ax.set_xlabel("Witness value W")
    ylabel = r"$H_{\min}(BC|\Lambda)$ [bits]" if MODE == "joint" else r"$H_{\min}(B|\Lambda)$ [bits]"
    ax.set_ylabel(ylabel)
    ax.set_title(f"{facet}, {orbit_name(generation_input)} representative {generation_input}")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    path = OUTPUT_DIR / f"plot_{MODE_TAG}_{facet}_input_{input_tag(generation_input)}_{level_tag()}.png"
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return path


def collect_curves() -> pd.DataFrame:
    frames = []
    for facet, inp in all_tasks():
        path = task_curve_csv(facet, inp)
        if path.exists():
            frame = load_csv(path)
            if not frame.empty:
                frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def aggregate_best(curves: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    out = {}
    for facet in FACETS:
        sub = curves[curves["facet"] == facet].copy()
        if sub.empty:
            continue
        idx = sub.groupby("w_lower")["p_guess_upper_monotone"].idxmin()
        best = sub.loc[idx].sort_values("w_lower").reset_index(drop=True)
        out[facet] = best
        safe_save_csv(OUTPUT_DIR / f"best_{MODE_TAG}_{facet}_{level_tag()}.csv", best)
    return out



def plot_all_inputs_by_facet(curves: pd.DataFrame) -> None:
    """Figura 5 reduzida: uma curva representativa para cada órbita."""
    ylabel = r"$H_{\min}(BC|\Lambda_{\rm cl})$ [bits]"
    facet = "CC2"
    sub = curves[curves["facet"] == facet].copy()
    if sub.empty:
        return
    wc = float(WITNESSES[facet]["classical"])
    wq = float(WITNESSES[facet]["quantum_reference"])

    ordered = []
    for orbit, representative in ORBIT_REPRESENTATIVES.items():
        tag = input_tag(representative)
        frame = sub[sub["input_tag"] == tag].sort_values("w_lower")
        if not frame.empty:
            ordered.append((orbit, representative, frame))

    # Versão principal, coerente com a definição de violação normalizada no texto.
    fig, ax = plt.subplots(figsize=(5.35, 4.05))
    for orbit, representative, frame in ordered:
        ax.plot(
            frame["violation_normalized"],
            frame["h_min_lower_monotone"],
            linewidth=1.65,
            label=orbit_plot_label(representative),
        )
    ax.axhline(2.0, linewidth=0.75, linestyle="--", alpha=0.55)
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 2.03)
    ax.set_xlabel("Normalized witness violation")
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.20)
    ax.legend(title="Orbit representative", frameon=False, fontsize=8.5)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / f"FIG5_CC2_3_orbit_representatives_normalized_{level_tag()}.png", dpi=360)
    fig.savefig(OUTPUT_DIR / f"FIG5_CC2_3_orbit_representatives_normalized_{level_tag()}.pdf")
    plt.close(fig)

    # Versão auxiliar no valor bruto de W_CC2, preservando a convenção do ZIP original.
    fig, ax = plt.subplots(figsize=(5.35, 4.05))
    for orbit, representative, frame in ordered:
        ax.plot(
            frame["w_lower"],
            frame["h_min_lower_monotone"],
            linewidth=1.65,
            label=orbit_plot_label(representative),
        )
    ax.axhline(2.0, linewidth=0.75, linestyle="--", alpha=0.55)
    ax.axvline(wq, linewidth=0.75, linestyle=":", alpha=0.65)
    ax.set_xlim(wc, wq)
    ax.set_ylim(0.0, 2.03)
    ax.set_xlabel(r"Witness value $W_{\mathrm{CC2}}$")
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.20)
    ax.legend(title="Orbit representative", frameon=False, fontsize=8.5)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / f"FIG5_CC2_3_orbit_representatives_rawW_{level_tag()}.png", dpi=360)
    fig.savefig(OUTPUT_DIR / f"FIG5_CC2_3_orbit_representatives_rawW_{level_tag()}.pdf")
    plt.close(fig)

def save_input_rankings(curves: pd.DataFrame) -> None:
    """Salva rankings por input no máximo e em cada violação normalizada."""
    if curves.empty:
        return

    keys = ["facet", "input_tag"]
    idx_max = curves.groupby(keys)["violation_normalized"].idxmax()
    at_max = curves.loc[idx_max].copy()
    at_max = at_max.sort_values(
        ["h_min_lower_monotone", "p_guess_upper_monotone"],
        ascending=[False, True],
    ).reset_index(drop=True)
    at_max.insert(0, "global_rank_at_own_WQ", np.arange(1, len(at_max) + 1))
    at_max["rank_within_facet"] = (
        at_max.groupby("facet")["h_min_lower_monotone"]
        .rank(method="first", ascending=False)
        .astype(int)
    )
    safe_save_csv(OUTPUT_DIR / f"ranking_at_max_{MODE_TAG}_{level_tag()}.csv", at_max)

    # Ranking em frações comuns da violação: comparação justa entre facetas.
    ranked = curves.copy()
    ranked["fraction_key"] = ranked["violation_normalized"].round(12)
    ranked["rank_within_facet_fraction"] = (
        ranked.groupby(["facet", "fraction_key"])["h_min_lower_monotone"]
        .rank(method="first", ascending=False)
        .astype(int)
    )
    ranked["global_rank_at_fraction"] = (
        ranked.groupby("fraction_key")["h_min_lower_monotone"]
        .rank(method="first", ascending=False)
        .astype(int)
    )
    safe_save_csv(OUTPUT_DIR / f"ranking_all_fractions_{MODE_TAG}_{level_tag()}.csv", ranked)

    best_by_facet_fraction = (
        ranked.sort_values(
            ["facet", "fraction_key", "h_min_lower_monotone", "p_guess_upper_monotone"],
            ascending=[True, True, False, True],
        )
        .groupby(["facet", "fraction_key"], as_index=False)
        .first()
    )
    safe_save_csv(
        OUTPUT_DIR / f"best_input_by_facet_and_fraction_{MODE_TAG}_{level_tag()}.csv",
        best_by_facet_fraction,
    )

    best_global_fraction = (
        ranked.sort_values(
            ["fraction_key", "h_min_lower_monotone", "p_guess_upper_monotone"],
            ascending=[True, False, True],
        )
        .groupby("fraction_key", as_index=False)
        .first()
    )
    safe_save_csv(
        OUTPUT_DIR / f"best_global_by_fraction_{MODE_TAG}_{level_tag()}.csv",
        best_global_fraction,
    )

    # Resumo humano legível.
    lines = []
    lines.append("RANKING NO MÁXIMO QUÂNTICO DE REFERÊNCIA DE CADA FACETA")
    lines.append("=" * 78)
    for _, row in at_max.iterrows():
        lines.append(
            f"{int(row['global_rank_at_own_WQ']):2d}. "
            f"{row['facet']:5s}  input={row['input_tag']:>7s}  "
            f"Hmin_LB={float(row['h_min_lower_monotone']):.9f} bits  "
            f"G_UB={float(row['p_guess_upper_monotone']):.9f}  "
            f"W={float(row['w_lower']):.9f}"
        )
    if not at_max.empty:
        top = at_max.iloc[0]
        lines.append("")
        lines.append("MELHOR COMBINAÇÃO ENCONTRADA")
        lines.append("-" * 78)
        lines.append(
            f"Faceta={top['facet']}; input={top['input_tag']}; "
            f"Hmin_LB={float(top['h_min_lower_monotone']):.9f} bits; "
            f"G_UB={float(top['p_guess_upper_monotone']):.9f}."
        )
    summary_path = OUTPUT_DIR / f"MELHOR_INPUT_{MODE_TAG}_{level_tag()}.txt"
    summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("\n" + "=" * 88)
    print("MELHORES INPUTS NO MÁXIMO QUÂNTICO DE REFERÊNCIA")
    print("=" * 88)
    for facet in sorted(at_max["facet"].unique()):
        row = at_max[at_max["facet"] == facet].sort_values("rank_within_facet").iloc[0]
        print(
            f"{facet}: input={row['input_tag']}, "
            f"Hmin_LB={float(row['h_min_lower_monotone']):.9f} bits, "
            f"G_UB={float(row['p_guess_upper_monotone']):.9f}"
        )
    if not at_max.empty:
        top = at_max.iloc[0]
        print("-" * 88)
        print(
            f"MELHOR GLOBAL: {top['facet']} input={top['input_tag']} | "
            f"Hmin_LB={float(top['h_min_lower_monotone']):.9f} bits"
        )
    print("=" * 88)


def collect_thresholds() -> pd.DataFrame:
    frames = []
    for facet, inp in all_tasks():
        path = OUTPUT_DIR / (
            f"threshold_{MODE_TAG}_{facet}_input_{input_tag(inp)}_{level_tag()}.csv"
        )
        if path.exists():
            frame = load_csv(path)
            if not frame.empty:
                frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def generate_aggregate_outputs() -> None:
    curves = collect_curves()
    if curves.empty:
        raise RuntimeError("Nenhuma curva salva foi encontrada.")
    safe_save_csv(OUTPUT_DIR / f"all_curves_{MODE_TAG}_{level_tag()}.csv", curves)
    curves.to_csv(OUTPUT_DIR / f"all_curves_{MODE_TAG}_{level_tag()}.csv.gz", index=False, compression="gzip")

    thresholds = collect_thresholds()
    if not thresholds.empty:
        thresholds = thresholds.sort_values(
            ["visibility_cert_white_noise", "normalized_violation_cert", "input_tag"]
        ).reset_index(drop=True)
        thresholds.insert(0, "rank_by_visibility", np.arange(1, len(thresholds) + 1))
        safe_save_csv(
            OUTPUT_DIR / f"certification_thresholds_3_orbit_representatives_{MODE_TAG}_{level_tag()}.csv",
            thresholds,
        )
        txt = [
            "CC2 — LIMIARES DOS TRÊS REPRESENTANTES DE ÓRBITA (G_UB=1)",
            "=" * 88,
        ]
        for row in thresholds.itertuples(index=False):
            txt.append(
                f"{int(row.rank_by_visibility):2d}. input={row.input_tag:>7s}  "
                f"v_cert={float(row.visibility_cert_white_noise):.10f}  "
                f"nu_cert={float(row.normalized_violation_cert):.10f}  "
                f"W_cert={float(row.w_cert_support):.10f}  "
                f"tau={float(row.tau_cert):.8g}"
            )
        (OUTPUT_DIR / f"certification_thresholds_3_orbit_representatives_{MODE_TAG}_{level_tag()}.txt").write_text(
            "\n".join(txt) + "\n", encoding="utf-8"
        )

    plot_all_inputs_by_facet(curves)
    save_input_rankings(curves)

    best = aggregate_best(curves)
    if not best:
        raise RuntimeError("Não foi possível agregar as melhores curvas.")

    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    for facet, frame in best.items():
        ax.plot(frame["w_lower"], frame["h_min_lower_monotone"], linewidth=1.5, label="best fixed input")
    ax.set_xlim(WITNESSES["CC2"]["classical"], WITNESSES["CC2"]["quantum_reference"])
    ax.set_xlabel(r"Witness value $W_{\mathrm{CC2}}$")
    ylabel = r"$H_{\min}(BC|\Lambda_{\rm cl})$ [bits]"
    ax.set_ylabel(ylabel)
    ax.set_title("CC2: best fixed generation input")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / f"best_input_CC2_{MODE_TAG}_Hmin_vs_W_{level_tag()}.png", dpi=300)
    fig.savefig(OUTPUT_DIR / f"best_input_CC2_{MODE_TAG}_Hmin_vs_W_{level_tag()}.pdf")
    plt.close(fig)


    summary_rows = []
    for facet, frame in best.items():
        last = frame.sort_values("w_lower").iloc[-1]
        positive = frame[frame["h_min_lower_monotone"] > 1e-8]
        first = positive.sort_values("w_lower").iloc[0] if not positive.empty else None
        summary_rows.append({
            "facet": facet,
            "best_input_at_max_w": last["input_tag"],
            "max_sampled_w": float(last["w_lower"]),
            "h_min_at_max_w": float(last["h_min_lower_monotone"]),
            "p_guess_at_max_w": float(last["p_guess_upper_monotone"]),
            "first_positive_w": float(first["w_lower"]) if first is not None else np.nan,
            "first_positive_input": str(first["input_tag"]) if first is not None else "",
        })
    safe_save_csv(OUTPUT_DIR / f"summary_{MODE_TAG}_{level_tag()}.csv", summary_rows)

    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "mode": MODE,
        "level": LEVEL,
        "q_scalar": Q_SCALAR,
        "solver_requested": SOLVER_REQUESTED,
        "solver_selected_at_runtime": choose_solver() if cp is not None else "plot-only",
        "mosek_eps": MOSEK_EPS,
        "scs_eps": SCS_EPS,
        "scs_max_iters": SCS_MAX_ITERS,
        "support_abs_padding": SUPPORT_ABS_PADDING,
        "support_rel_padding": SUPPORT_REL_PADDING,
        "residual_multiplier": RESIDUAL_MULTIPLIER,
        "symmetry_disabled": DISABLE_SYMMETRY,
        "probability_positivity": ENFORCE_PROBABILITY_POSITIVITY,
        "tau_initial": TAU_INITIAL.tolist(),
        "tau_focus_enabled": TAU_FOCUS_ENABLED,
        "tau_focus_min": TAU_FOCUS_MIN,
        "tau_focus_max": TAU_FOCUS_MAX,
        "tau_focus_step": TAU_FOCUS_STEP,
        "tau_refine_rounds": TAU_REFINE_ROUNDS,
        "tau_refine_abs_tol": TAU_REFINE_ABS_TOL,
        "tau_refine_rel_tol": TAU_REFINE_REL_TOL,
        "tau_bound_improvement_tol": TAU_BOUND_IMPROVEMENT_TOL,
        "tau_max_new_per_round": TAU_MAX_NEW_PER_ROUND,
        "w_plot_points_global": W_PLOT_POINTS_GLOBAL,
        "w_plot_points_endpoint": W_PLOT_POINTS_ENDPOINT,
        "w_endpoint_rel_gap_min": W_ENDPOINT_REL_GAP_MIN,
        "w_endpoint_rel_gap_max": W_ENDPOINT_REL_GAP_MAX,
        "cert_g_tol": CERT_G_TOL,
        "cert_h_tol": CERT_H_TOL,
        "certification_threshold_method": "continuous support-envelope crossing G_UB=1",
        "physical_lower_enabled": RUN_PHYSICAL_LOWER,
        "facets": WITNESSES,
        "orbit_representatives": {k: list(v) for k, v in ORBIT_REPRESENTATIVES.items()},
    }
    with (OUTPUT_DIR / f"metadata_{MODE_TAG}_{level_tag()}.json").open("w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    print(f"Resultados agregados em {OUTPUT_DIR}")


# =============================================================================
# 13. Seleção de tarefas e SLURM
# =============================================================================


def parse_input(text: str):
    values = tuple(int(v.strip()) for v in text.split(","))
    expected = 3 if MODE == "joint" else 2
    if len(values) != expected:
        raise ValueError(f"PAB_INPUT deve ter {expected} inteiros separados por vírgula.")
    domains = (N_X, N_B, N_C) if MODE == "joint" else (N_X, N_B)
    if any(v < 0 or v >= domains[k] for k, v in enumerate(values)):
        raise ValueError(f"Input fora do domínio: {values}")
    return values


def selected_tasks():
    facet_env = os.getenv("PAB_FACET", "").strip().upper()
    input_env = os.getenv("PAB_INPUT", "").strip()
    if facet_env or input_env:
        facets = [facet_env] if facet_env else ["CC2"]
        for facet in facets:
            if facet != "CC2":
                raise ValueError("Esta versão executa apenas a faceta CC2.")
        inputs = [parse_input(input_env)] if input_env else list(all_inputs())
        return [(f, inp) for f in facets for inp in inputs]

    array_id = os.getenv("SLURM_ARRAY_TASK_ID")
    tasks = all_tasks()
    if array_id is not None:
        k = int(array_id)
        if not 0 <= k < len(tasks):
            raise IndexError(f"SLURM_ARRAY_TASK_ID={k} fora de 0..{len(tasks)-1}")
        return [tasks[k]]
    return tasks


def run_sbatch(command: List[str], dry_run: bool) -> str:
    print(" ".join(shlex.quote(x) for x in command))
    if dry_run:
        return "DRYRUN"
    completed = subprocess.run(command, check=True, text=True, capture_output=True)
    output = completed.stdout.strip()
    print(output)
    return output.split(";")[0].strip()


def submit_pipeline(dry_run: bool) -> None:
    if not shutil_which("sbatch") and not dry_run:
        raise RuntimeError("sbatch não encontrado. Use --dry-run para apenas visualizar os comandos.")
    script = str(Path(__file__).resolve())
    python_exe = sys.executable
    n_tasks = len(all_tasks())
    array = f"0-{n_tasks-1}%{max(1, SLURM_CONCURRENCY)}"
    base = [
        "sbatch", "--parsable",
        f"--job-name=PAB_{MODE_TAG}_support",
        f"--array={array}",
        f"--mem={SLURM_MEM}",
        f"--cpus-per-task={SLURM_CPUS}",
        f"--time={SLURM_TIME}",
        f"--output={LOG_DIR}/%A_%a.out",
        f"--error={LOG_DIR}/%A_%a.err",
    ]
    partition = os.getenv("PAB_SLURM_PARTITION", "").strip()
    account = os.getenv("PAB_SLURM_ACCOUNT", "").strip()
    if partition:
        base.append(f"--partition={partition}")
    if account:
        base.append(f"--account={account}")
    wrapped = (
        "unset PAB_FACET PAB_INPUT PAB_PLOT_ONLY; "
        f"export OMP_NUM_THREADS=${{SLURM_CPUS_PER_TASK:-1}}; "
        f"{shlex.quote(python_exe)} {shlex.quote(script)}"
    )
    job_id = run_sbatch(base + ["--wrap", wrapped], dry_run)

    post = [
        "sbatch", "--parsable",
        f"--job-name=PAB_{MODE_TAG}_plot",
        f"--dependency=afterok:{job_id}",
        "--mem=8G", "--cpus-per-task=1", "--time=01:00:00",
        f"--output={LOG_DIR}/post_%j.out",
        f"--error={LOG_DIR}/post_%j.err",
        "--wrap", (
            "unset PAB_FACET PAB_INPUT; "
            f"{shlex.quote(python_exe)} {shlex.quote(script)} --plot-only"
        ),
    ]
    if partition:
        post.insert(-2, f"--partition={partition}")
    if account:
        post.insert(-2, f"--account={account}")
    run_sbatch(post, dry_run)


def shutil_which(name: str) -> Optional[str]:
    from shutil import which
    return which(name)


# =============================================================================
# 14. CLI
# =============================================================================


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--submit", action="store_true", help="Submete array e pós-processamento ao SLURM.")
    parser.add_argument("--dry-run", action="store_true", help="Mostra comandos sbatch sem submeter.")
    parser.add_argument("--plot-only", action="store_true", help="Agrega CSVs e gera gráficos sem resolver SDP.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.submit:
        submit_pipeline(args.dry_run)
        return
    if args.plot_only or PLOT_ONLY:
        generate_aggregate_outputs()
        return
    if cp is None:
        raise RuntimeError("CVXPY não foi importado.")
    selected_solver = choose_solver()
    print(f"Solver selecionado: {selected_solver}")
    tasks = selected_tasks()
    print(f"Executando {len(tasks)} tarefa(s), MODE={MODE}, output={OUTPUT_DIR}")
    try:
        for facet, inp in tasks:
            run_support_task(facet, inp)
            gc.collect()
    except ProcessRecycleRequested:
        raise SystemExit(RECYCLE_EXIT_CODE)
    # Em execução local com mais de uma tarefa, agrega e ranqueia os inputs ao final.
    if len(tasks) > 1:
        generate_aggregate_outputs()


if __name__ == "__main__":
    main()
