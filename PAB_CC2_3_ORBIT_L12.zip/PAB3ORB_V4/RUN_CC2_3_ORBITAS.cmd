@echo off
set "PIP_NO_CACHE_DIR=1"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"
set "PYTHONPYCACHEPREFIX=%TEMP%\PAB_CC2_PYCACHE"
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "MODE=%~1"
if /I not "%MODE%"=="full" if /I not "%MODE%"=="scan" if /I not "%MODE%"=="balanced" if /I not "%MODE%"=="replot" set "MODE=scan"

if /I "%MODE%"=="scan" (
    set "RUN_LABEL=TRIAGEM"
) else (
    rem replot reutiliza a pasta da rodada completa
    set "RUN_LABEL=COMPLETO"
)

set "OUTDIR=%CD%\resultados_%RUN_LABEL%_CC2_3_orbitas"

echo ============================================================
echo PAB CC2 - RANDOMNESS CONJUNTA BC - L(1,2)
echo Tres representantes das orbitas da Fig. 5:
echo   O_A: ^(0,0,0^)   O_B: ^(1,0,0^)   O_C: ^(2,0,0^)
echo Modo: %MODE%
echo Saida: %OUTDIR%
echo ============================================================

if not exist "%CD%\pab_cc2_3_orbitas.py" (
    echo ERRO: pab_cc2_3_orbitas.py nao encontrado.
    pause
    exit /b 1
)

set "PYBASE="
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYBASE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYBASE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYBASE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYBASE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYBASE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYBASE if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PYBASE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
if not defined PYBASE if exist "%USERPROFILE%\anaconda3\python.exe" set "PYBASE=%USERPROFILE%\anaconda3\python.exe"
if not defined PYBASE if exist "%USERPROFILE%\miniconda3\python.exe" set "PYBASE=%USERPROFILE%\miniconda3\python.exe"
if not defined PYBASE if exist "C:\ProgramData\anaconda3\python.exe" set "PYBASE=C:\ProgramData\anaconda3\python.exe"
if not defined PYBASE if exist "C:\ProgramData\miniconda3\python.exe" set "PYBASE=C:\ProgramData\miniconda3\python.exe"
if not defined PYBASE (
    for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYBASE set "PYBASE=%%P"
)
if not defined PYBASE (
    echo ERRO: Python nao encontrado.
    pause
    exit /b 1
)

set "VENV=%LOCALAPPDATA%\PAB_CC2_3ORB_ENV"
set "PY=%VENV%\Scripts\python.exe"
if not exist "%PY%" (
    echo Criando ambiente virtual local...
    "%PYBASE%" -m venv "%VENV%"
    if errorlevel 1 goto :erro
)

if /I not "%MODE%"=="replot" (
    echo Instalando/verificando dependencias principais...
    "%PY%" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel
    if errorlevel 1 goto :erro
    "%PY%" -m pip install --disable-pip-version-check --prefer-binary numpy scipy pandas matplotlib cvxpy scs psutil
    if errorlevel 1 goto :erro
    echo Tentando instalar o modulo MOSEK no ambiente local...
    "%PY%" -m pip install --disable-pip-version-check --prefer-binary mosek
    if errorlevel 1 echo AVISO: MOSEK nao foi instalado.
    "%PY%" -c "import cvxpy as cp; print('CVXPY:',cp.__version__); print('Solvers:',cp.installed_solvers())"
    if errorlevel 1 goto :erro
)

set "PAB_FACET=CC2"
set "PAB_OUTPUT_DIR=%OUTDIR%"
set "PAB_LEVEL=L12"
set "PAB_Q_SCALAR=1"
set "PAB_SOLVER=MOSEK"
set "PAB_RUN_PHYSICAL_LOWER=0"
set "PAB_SAVE_INPUT_PLOTS=1"
set "PAB_VERBOSE=0"
set "PAB_DISABLE_SYMMETRY=0"
set "PAB_ENFORCE_PROB_POS=1"
set "PAB_RESUME=1"
set "PAB_TAU_FOCUS=0"
set "PAB_SCS_USE_INDIRECT=1"
set "PAB_SCS_NORMALIZE=1"
set "PAB_SCS_MAX_ITERS=1000000"
set "PAB_MOSEK_EPS=1e-9"
set "PAB_RESIDUAL_MULTIPLIER=10"
set "PAB_CERT_G_TOL=1e-10"
set "PAB_CERT_H_TOL=1e-10"
set "PAB_MAX_NEW_SOLVES_PER_PROCESS=80"

if /I "%MODE%"=="scan" (
    set "PAB_TAUS=0,0.1,0.2,0.3,0.5,0.75,1,1.25,1.5,2,3,5,8,12,20,35,60,100,200,500"
    set "PAB_TAU_MAX=500"
    set "PAB_TAU_REFINE_ROUNDS=2"
    set "PAB_TAU_MAX_NEW_PER_ROUND=64"
    set "PAB_TAU_REFINE_ABS_TOL=0.002"
    set "PAB_TAU_REFINE_REL_TOL=0.002"
    set "PAB_TAU_BOUND_IMPROVEMENT_TOL=1e-6"
    set "PAB_W_PLOT_POINTS_GLOBAL=801"
    set "PAB_W_PLOT_POINTS_ENDPOINT=400"
    set "PAB_ENDPOINT_REL_GAP_MIN=1e-6"
    set "PAB_ENDPOINT_REL_GAP_MAX=1e-2"
    set "PAB_SUPPORT_ABS_PADDING=2e-6"
    set "PAB_SUPPORT_REL_PADDING=1e-8"
    set "PAB_SCS_EPS=1e-5"
) else if /I "%MODE%"=="balanced" (
    set "PAB_TAUS=0,0.1,0.2,0.3,0.5,0.75,1,1.25,1.5,2,3,5,8,12,20,35,60,100,200,350,500"
    set "PAB_TAU_MAX=500"
    set "PAB_TAU_REFINE_ROUNDS=4"
    set "PAB_TAU_MAX_NEW_PER_ROUND=96"
    set "PAB_TAU_REFINE_ABS_TOL=5e-4"
    set "PAB_TAU_REFINE_REL_TOL=2e-4"
    set "PAB_TAU_BOUND_IMPROVEMENT_TOL=1e-7"
    set "PAB_W_PLOT_POINTS_GLOBAL=1401"
    set "PAB_W_PLOT_POINTS_ENDPOINT=800"
    set "PAB_ENDPOINT_REL_GAP_MIN=1e-6"
    set "PAB_ENDPOINT_REL_GAP_MAX=1e-2"
    set "PAB_SUPPORT_ABS_PADDING=2e-8"
    set "PAB_SUPPORT_REL_PADDING=2e-10"
    set "PAB_SCS_EPS=1e-6"
) else if /I "%MODE%"=="full" (
    set "PAB_TAUS="
    set "PAB_TAU_MAX=2000"
    set "PAB_TAU_REFINE_ROUNDS=7"
    set "PAB_TAU_MAX_NEW_PER_ROUND=256"
    set "PAB_TAU_REFINE_ABS_TOL=1e-4"
    set "PAB_TAU_REFINE_REL_TOL=5e-5"
    set "PAB_TAU_BOUND_IMPROVEMENT_TOL=1e-8"
    set "PAB_W_PLOT_POINTS_GLOBAL=1801"
    set "PAB_W_PLOT_POINTS_ENDPOINT=1200"
    set "PAB_ENDPOINT_REL_GAP_MIN=1e-8"
    set "PAB_ENDPOINT_REL_GAP_MAX=1e-2"
    set "PAB_SUPPORT_ABS_PADDING=1e-8"
    set "PAB_SUPPORT_REL_PADDING=1e-10"
    set "PAB_SCS_EPS=2e-6"
)

if /I "%MODE%"=="replot" goto :agregar

echo.
echo Cada representante sera executado separadamente.
echo O processo sera reciclado a cada 80 novos solves para liberar RAM.
echo O modo RESUME reutiliza automaticamente todos os checkpoints.
echo.

call :rodar_input "0,0,0" O_A
if errorlevel 1 goto :erro
call :rodar_input "1,0,0" O_B
if errorlevel 1 goto :erro
call :rodar_input "2,0,0" O_C
if errorlevel 1 goto :erro

set "CURVE_COUNT=0"
for %%F in ("%OUTDIR%\curve_joint_BC_CC2_input_*_L12_q1.csv") do if exist "%%~fF" set /a CURVE_COUNT+=1
if not "%CURVE_COUNT%"=="3" (
    echo ERRO: foram encontradas apenas %CURVE_COUNT% de 3 curvas esperadas.
    goto :erro
)

:agregar
set "PAB_INPUT="
echo.
echo Gerando a Fig. 5 reduzida e os CSVs agregados...
"%PY%" "%CD%\pab_cc2_3_orbitas.py" --plot-only
if errorlevel 1 goto :erro

echo.
echo ============================================================
echo CONCLUIDO.
echo Figura principal normalizada:
echo %OUTDIR%\FIG5_CC2_3_orbit_representatives_normalized_L12_q1.pdf
echo Figura auxiliar em W bruto:
echo %OUTDIR%\FIG5_CC2_3_orbit_representatives_rawW_L12_q1.pdf
echo Dados:
echo %OUTDIR%\all_curves_joint_BC_L12_q1.csv.gz
echo ============================================================
pause
exit /b 0

:rodar_input
set "PAB_INPUT=%~1"
set "ORBITA=%~2"
:retomar_input
echo ------------------------------------------------------------
echo Executando %ORBITA% com representante ^(%PAB_INPUT%^)
"%PY%" "%CD%\pab_cc2_3_orbitas.py"
set "PY_EXIT=%ERRORLEVEL%"
if "%PY_EXIT%"=="75" (
    echo Processo reciclado com checkpoint salvo. Retomando %ORBITA%...
    goto :retomar_input
)
if not "%PY_EXIT%"=="0" exit /b 1
exit /b 0

:erro
echo.
echo ERRO: a execucao terminou com falha.
echo Os checkpoints e CSVs salvos permanecem na pasta de resultados.
pause
exit /b 1
