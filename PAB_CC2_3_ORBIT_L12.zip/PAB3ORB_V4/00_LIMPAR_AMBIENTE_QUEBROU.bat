@echo off
echo Fechando processos Python que possam estar usando o ambiente...
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1
if exist "%LOCALAPPDATA%\PAB_CC2_3ORB_ENV" (
  echo Removendo ambiente parcial em caminho curto...
  rmdir /S /Q "%LOCALAPPDATA%\PAB_CC2_3ORB_ENV"
)
if exist "%~dp0.pab_cc2_env" (
  echo Removendo ambiente parcial antigo dentro do projeto...
  rmdir /S /Q "%~dp0.pab_cc2_env"
)
echo Limpeza concluida.
pause
