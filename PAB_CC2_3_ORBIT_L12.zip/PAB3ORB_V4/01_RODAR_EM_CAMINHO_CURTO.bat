@echo off
setlocal EnableExtensions
set "SHORTROOT=C:\PAB3ORB"
echo.
echo Copiando o projeto para %SHORTROOT%...
if not exist "%SHORTROOT%" mkdir "%SHORTROOT%"
robocopy "%~dp0" "%SHORTROOT%" /E /PURGE /NFL /NDL /NJH /NJS /NC /NS /XD resultados_* .pab_cc2_env __pycache__ >nul
if errorlevel 8 (
  echo ERRO: nao foi possivel copiar o projeto para C:\PAB3ORB.
  pause
  exit /b 1
)
cd /d "%SHORTROOT%"
call 12_BALANCEADO_CC2_3_ORBITAS.bat
set "RC=%ERRORLEVEL%"
echo.
echo Copiando as pastas de resultados de volta...
for /d %%D in ("%SHORTROOT%\resultados_*") do (
  if exist "%%D" robocopy "%%D" "%~dp0%%~nxD" /E /NFL /NDL /NJH /NJS /NC /NS >nul
)
echo Finalizado com codigo %RC%.
pause
exit /b %RC%
