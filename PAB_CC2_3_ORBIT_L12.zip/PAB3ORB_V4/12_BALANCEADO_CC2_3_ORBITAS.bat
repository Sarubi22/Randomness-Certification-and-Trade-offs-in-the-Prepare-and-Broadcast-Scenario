@echo off
cd /d "%~dp0"
call RUN_CC2_3_ORBITAS.cmd balanced
