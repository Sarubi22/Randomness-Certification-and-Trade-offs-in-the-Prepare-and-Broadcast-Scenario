@echo off
call "%~dp0RUN_CC2_3_ORBITAS.cmd" scan
