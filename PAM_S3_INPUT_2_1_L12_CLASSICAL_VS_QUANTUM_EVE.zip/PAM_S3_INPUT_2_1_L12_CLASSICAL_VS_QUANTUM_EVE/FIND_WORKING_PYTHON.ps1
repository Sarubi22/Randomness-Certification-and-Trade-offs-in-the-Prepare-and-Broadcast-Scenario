﻿param(
    [Parameter(Mandatory=$true)]
    [string]$OutputFile,
    [switch]$Diagnostic
)

$ErrorActionPreference = "SilentlyContinue"
$candidates = New-Object System.Collections.Generic.List[object]
$seen = @{}

function Add-Candidate([string]$Path, [string]$Source) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    try { $full = [System.IO.Path]::GetFullPath($Path) } catch { return }
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { return }
    $key = $full.ToLowerInvariant()
    if ($seen.ContainsKey($key)) { return }
    $seen[$key] = $true
    $candidates.Add([pscustomobject]@{Path=$full; Source=$Source})
}

# 1. Explicit override and local environment created by this package.
Add-Candidate $env:PAM_PYTHON "PAM_PYTHON"
Add-Candidate (Join-Path $PSScriptRoot ".pam_s3_support_env_CORRIGIDO\Scripts\python.exe") "local-v2"

# 2. Active Conda environment.
if ($env:CONDA_PREFIX) {
    Add-Candidate (Join-Path $env:CONDA_PREFIX "python.exe") "CONDA_PREFIX"
}

# 3. Common Conda installations and every environment inside them.
$condaRoots = @(
    (Join-Path $env:USERPROFILE "anaconda3"),
    (Join-Path $env:USERPROFILE "miniconda3"),
    (Join-Path $env:LOCALAPPDATA "anaconda3"),
    (Join-Path $env:LOCALAPPDATA "miniconda3"),
    "C:\ProgramData\anaconda3",
    "C:\ProgramData\miniconda3"
)
foreach ($root in $condaRoots) {
    if (-not $root) { continue }
    $envDir = Join-Path $root "envs"
    if (Test-Path -LiteralPath $envDir -PathType Container) {
        Get-ChildItem -LiteralPath $envDir -Directory | ForEach-Object {
            Add-Candidate (Join-Path $_.FullName "python.exe") ("conda-env:" + $_.Name)
        }
    }
    Add-Candidate (Join-Path $root "python.exe") "conda-base"
}

# 4. Standard CPython installations.
foreach ($ver in @("313","312","311","310","39")) {
    Add-Candidate (Join-Path $env:LOCALAPPDATA ("Programs\Python\Python" + $ver + "\python.exe")) ("CPython-" + $ver)
}

# 5. Paths visible from the current shell.
try {
    (& where.exe python.exe 2>$null) | ForEach-Object { Add-Candidate $_ "PATH" }
} catch {}
try {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        (& py.exe -0p 2>$null) | ForEach-Object {
            if ($_ -match '([A-Za-z]:\\.*python\.exe)') { Add-Candidate $matches[1] "py-launcher" }
        }
    }
} catch {}

$results = New-Object System.Collections.Generic.List[object]
foreach ($candidate in $candidates) {
    $path = $candidate.Path
    $sslOK = $false
    $depsOK = $false
    $version = ""
    $sslText = ""
    $depError = ""

    try {
        $version = (& $path -c "import sys; print(sys.version.split()[0])" 2>&1 | Select-Object -Last 1).ToString()
        & $path -c "import ssl; print(ssl.OPENSSL_VERSION)" *> $null
        $sslOK = ($LASTEXITCODE -eq 0)
    } catch {
        $sslOK = $false
    }

    if ($sslOK) {
        try {
            $depOut = & $path -c "import ssl,numpy,pandas,scipy,matplotlib,cvxpy,mosek; print('DEPENDENCIES_OK')" 2>&1
            $depsOK = ($LASTEXITCODE -eq 0)
            if (-not $depsOK) { $depError = ($depOut | Select-Object -Last 1).ToString() }
        } catch {
            $depsOK = $false
            $depError = $_.Exception.Message
        }
    }

    $results.Add([pscustomobject]@{
        Source=$candidate.Source
        Python=$path
        Version=$version
        SSL=$sslOK
        Dependencies=$depsOK
        Detail=$depError
    })
}

if ($Diagnostic) {
    Write-Host ""
    Write-Host "Python encontrados:" -ForegroundColor Cyan
    if ($results.Count -eq 0) {
        Write-Host "  Nenhum python.exe encontrado." -ForegroundColor Red
    } else {
        $results | Format-Table Source,Version,SSL,Dependencies,Python -AutoSize | Out-Host
    }
}

$ready = $results | Where-Object { $_.Dependencies } | Select-Object -First 1
if ($ready) {
    Set-Content -LiteralPath $OutputFile -Value ("READY|" + $ready.Python) -Encoding ASCII
    exit 0
}

$bootstrap = $results | Where-Object { $_.SSL } | Select-Object -First 1
if ($bootstrap) {
    Set-Content -LiteralPath $OutputFile -Value ("BOOTSTRAP|" + $bootstrap.Python) -Encoding ASCII
    exit 0
}

Set-Content -LiteralPath $OutputFile -Value "NONE|" -Encoding ASCII
exit 0
