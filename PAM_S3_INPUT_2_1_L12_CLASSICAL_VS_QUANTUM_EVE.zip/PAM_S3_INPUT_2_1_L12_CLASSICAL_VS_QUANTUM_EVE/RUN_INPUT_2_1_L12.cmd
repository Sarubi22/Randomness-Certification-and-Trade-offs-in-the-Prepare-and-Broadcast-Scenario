@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "MODE=%~1"
if not defined MODE set "MODE=FULL"
set "SELECT_FILE=%TEMP%\pam_s3_21_l12_%RANDOM%_%RANDOM%.txt"
set "INSTALL_LOG=%~dp0pam_s3_21_l12_install.log"
set "LOCAL_ENV=%~dp0.pam_s3_21_l12_env"
set "PY="
set "PY_STATUS="

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FIND_WORKING_PYTHON.ps1" -OutputFile "%SELECT_FILE%" -Diagnostic
if not exist "%SELECT_FILE%" goto :ambiente_erro
for /f "usebackq tokens=1,* delims=|" %%A in ("%SELECT_FILE%") do (
    set "PY_STATUS=%%A"
    set "PY=%%B"
)
del /q "%SELECT_FILE%" >nul 2>&1

if /I "%PY_STATUS%"=="NONE" goto :ambiente_erro
if /I "%PY_STATUS%"=="BOOTSTRAP" (
    echo Criando ambiente local: %LOCAL_ENV%
    if exist "%LOCAL_ENV%" rmdir /s /q "%LOCAL_ENV%"
    "%PY%" -m venv "%LOCAL_ENV%" > "%INSTALL_LOG%" 2>&1
    if errorlevel 1 goto :ambiente_erro
    set "PY=%LOCAL_ENV%\Scripts\python.exe"
    "%PY%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt" >> "%INSTALL_LOG%" 2>&1
    if errorlevel 1 goto :ambiente_erro
)

"%PY%" -c "import ssl,numpy,pandas,scipy,matplotlib,cvxpy,mosek; print('Ambiente OK:',__import__('sys').executable); print('CVXPY:',cvxpy.__version__); print('Solvers:',cvxpy.installed_solvers())"
if errorlevel 1 goto :ambiente_erro

set "PAM_COMPARE_OUTPUT_DIR=%~dp0resultados_S3_input_2_1_L12"
set "PAM_OUTPUT_DIR=%~dp0resultados_S3_input_2_1_L12\quantum_eve_channel_complement"
set "PAMC_OUTPUT_DIR=%~dp0resultados_S3_input_2_1_L12\classical_side_information"

rem Niveis pedidos: quantum L(1,2)=L12; classico Bob-only L(1,2)=L12+B.
set "PAM_LEVEL=L12"
set "PAMC_LEVEL=L12+B"
set "PAM_SOLVER=MOSEK"
set "PAMC_SOLVER=MOSEK"
set "PAM_MOSEK_THREADS=1"
set "PAMC_MOSEK_THREADS=1"
set "PAM_MOSEK_SOLVE_FORM=MSK_SOLVE_DUAL"
set "PAMC_MOSEK_SOLVE_FORM=AUTO"
set "PAM_MOSEK_TOL=1e-9"
set "PAMC_MOSEK_TOL=1e-8"
set "PAM_RESUME=1"
set "PAMC_RESUME=1"
set "PAM_PLOT_ONLY=0"
set "PAMC_PLOT_ONLY=0"
set "PAM_LAMBDA_HARD_MAX=1000"
set "PAM_DIRECT_NUS=0.95,0.98,0.99,0.995,0.998,0.999,0.9995,0.9998,0.9999,1.0"
set "PAMC_DIRECT_NUS=0.95,0.98,0.99,0.995,0.998,0.999,0.9995,0.9998,0.9999,1.0"
set "PAMC_USE_DIRECT_ANCHORS=1"

if /I "%MODE%"=="FAST" (
    set "PAM_FAST_TEST=1"
    set "PAMC_FAST_TEST=1"
    set "PAM_ADAPTIVE_ROUNDS=0"
    set "PAM_CURVE_POINTS=101"
    set "PAMC_CURVE_POINTS=101"
) else if /I "%MODE%"=="PLOT" (
    set "PAM_PLOT_ONLY=1"
    set "PAMC_PLOT_ONLY=1"
) else (
    set "PAM_FAST_TEST=0"
    set "PAMC_FAST_TEST=0"
    set "PAM_ADAPTIVE_ROUNDS=2"
    set "PAM_ADAPTIVE_MAX_NEW=10"
    set "PAM_LAMBDA_COUNT=31"
    set "PAMC_LAMBDA_COUNT=41"
    set "PAM_CURVE_POINTS=501"
    set "PAMC_CURVE_POINTS=501"
)

if /I "%MODE%"=="PLOT" goto :plot

echo.
echo ============================================================
echo 1/3 - EVE QUANTICA - INPUT (2,1) - NIVEL L(1,2)
echo ============================================================
"%PY%" "%~dp0PAM_S3_quantum_Eve_channel_complement_support.py"
if errorlevel 1 goto :programa_erro

echo.
echo ============================================================
echo 2/3 - EVE CLASSICA - INPUT (2,1) - NIVEL L(1,2)
echo ============================================================
"%PY%" "%~dp0PAM_S3_classical_side_info_support.py"
if errorlevel 1 goto :programa_erro

:plot
echo.
echo ============================================================
echo 3/3 - FIGURA COMPARATIVA
echo ============================================================
"%PY%" "%~dp0plot_compare_input_2_1_L12.py"
if errorlevel 1 goto :programa_erro

echo.
echo CONCLUIDO. Veja:
echo   resultados_S3_input_2_1_L12\figuras_comparativas
pause
exit /b 0

:ambiente_erro
echo.
echo ERRO NA PREPARACAO DO AMBIENTE.
echo Consulte: %INSTALL_LOG%
pause
exit /b 1

:programa_erro
echo.
echo ERRO DURANTE O PROGRAMA. Veja a mensagem acima.
pause
exit /b 1
