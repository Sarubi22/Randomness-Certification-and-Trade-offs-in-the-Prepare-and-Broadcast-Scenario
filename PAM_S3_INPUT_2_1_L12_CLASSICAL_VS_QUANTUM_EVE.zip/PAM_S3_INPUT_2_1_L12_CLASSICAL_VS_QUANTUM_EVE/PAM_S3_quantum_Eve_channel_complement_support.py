#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PAM S3 — curva de randomness no input fixo (2,1) contra Eve quantica
complementar, usando FUNCAO SUPORTE.

Arquitetura adversarial:

    |psi_x> -- U --> Bob (B) + Eve (E)

Alice prepara tres estados em dimensao fixa d=2. Eve controla o canal,
recebe todo o braco complementar e pode aguardar a revelacao do par de
geracao (x*,y*) antes de escolher sua medicao E_*.

A estatistica observada e apenas a marginal PAM de Bob, avaliada pela
witness

    S3 = <B0>_0 + <B1>_0 + <B0>_1 - <B1>_1 - <B0>_2,

com limite classico S3_C=3 e referencia qubit S3_Q=1+2 sqrt(2).

Para o input fixo (x*,y*)=(2,1) resolve-se a funcao suporte CENTRADA
no endpoint,

    q(lambda) = max [ G_{x*y*} + lambda (nu(S3)-1) ], lambda >= 0,

onde

    G_{x*y*} = sum_b p(b,e=b|x*,y*,E_*),
    nu(S3)   = (S3-S3_C)/(S3_Q-S3_C).

A curva completa e reconstruida por

    G(nu) <= min_lambda [q(lambda)+lambda(1-nu)].

Esta forma e matematicamente equivalente a funcao suporte usual, mas evita
a subtracao numericamente instavel de dois numeros da ordem de lambda no
endpoint. A regiao final da curva e ainda validada por SDPs diretos em
varios valores de nu, incluindo o endpoint.

Assim, uma grade densa de centenas de pontos no grafico nao exige centenas
de SDPs. O mesmo problema DPP e reutilizado sequencialmente para todos os
lambdas e inputs, mantendo apenas uma matriz de momentos na memoria.

Saidas:
  * checkpoint dos solves da funcao suporte;
  * CSV da curva completa para o input fixo (2,1);
  * PDF e PNG de Pguess e Hmin para cada input;
  * PDF e PNG comparando o input fixo (2,1);
  * resumo numerico e diagnostico da grade de lambdas.
"""

from __future__ import annotations

import gc
import math
import os
import time
from itertools import product
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd
import scipy.sparse as sp

_PLOT_ONLY_EARLY = os.getenv("PAM_PLOT_ONLY", "0") == "1"
if _PLOT_ONLY_EARLY:
    cp = None
else:
    import cvxpy as cp

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# =============================================================================
# 1. Configuracao numerica
# =============================================================================

SOLVER = os.getenv("PAM_SOLVER", "MOSEK").upper()
VERBOSE_SOLVER = os.getenv("PAM_VERBOSE", "0") == "1"

_slurm_threads = int(os.getenv("SLURM_CPUS_PER_TASK", "1"))
MOSEK_THREADS = int(os.getenv("PAM_MOSEK_THREADS", str(max(1, _slurm_threads))))
MOSEK_TOL = float(os.getenv("PAM_MOSEK_TOL", "1e-9"))
MOSEK_MAX_TIME = float(os.getenv("PAM_MOSEK_MAX_TIME", "0"))
MOSEK_SOLVE_FORM = os.getenv("PAM_MOSEK_SOLVE_FORM", "MSK_SOLVE_DUAL")
NUMERICAL_PADDING = float(os.getenv("PAM_NUMERICAL_PADDING", "2e-7"))
WITNESS_RELAXATION = float(os.getenv("PAM_WITNESS_RELAXATION", "1e-7"))
ENDPOINT_SHORTCUT = os.getenv("PAM_ENDPOINT_SHORTCUT", "0") == "1"
ENDPOINT_PGUESS_TOL = float(os.getenv("PAM_ENDPOINT_PGUESS_TOL", "2e-7"))
ENDPOINT_NU_TOL = float(os.getenv("PAM_ENDPOINT_NU_TOL", "2e-6"))

OUTPUT_DIR = Path(os.getenv("PAM_OUTPUT_DIR", "resultados_PAM_S3_fixed_input_qeve_CORRIGIDO"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

installed = [] if cp is None else cp.installed_solvers()


# =============================================================================
# 2. Cenario PAM S3
# =============================================================================

D = 2
N_X = 3
N_B = 2
FIXED_INPUTS = [(2, 1)]  # input de geracao fixo solicitado: (x*,y*)=(2,1)

S3_CLASSICAL = 3.0
S3_QUBIT = 1.0 + 2.0 * math.sqrt(2.0)
S3_GAP = S3_QUBIT - S3_CLASSICAL
S3_ALGEBRAIC_MIN = -5.0
NU_GLOBAL_MIN = (S3_ALGEBRAIC_MIN - S3_CLASSICAL) / S3_GAP - 1e-6
SUPPORT_CENTER = 1.0


def s3_from_nu(nu):
    return S3_CLASSICAL + np.asarray(nu) * S3_GAP


def nu_from_s3(s3):
    return (np.asarray(s3) - S3_CLASSICAL) / S3_GAP


# =============================================================================
# 3. Motor de momentos dimension-bounded: Bob + Eve
# =============================================================================

Mono = Tuple[Tuple[int, ...], Tuple[int, ...]]
Word = Tuple[Tuple[int, ...], Tuple[int, ...]]
MomentKey = Tuple[Mono, int, int, Word]
ID_WORD: Word = (tuple(), tuple())


def _zeros(n: int) -> Tuple[int, ...]:
    return tuple(0 for _ in range(n))


def mono_one(n: int) -> Mono:
    z = _zeros(n)
    return z, z


def mono_alpha(n: int, k: int) -> Mono:
    h = [0] * n
    h[k] = 1
    return tuple(h), _zeros(n)


def mono_conj(m: Mono) -> Mono:
    return m[1], m[0]


def mono_mul(a: Mono, b: Mono) -> Mono:
    return (
        tuple(x + y for x, y in zip(a[0], b[0])),
        tuple(x + y for x, y in zip(a[1], b[1])),
    )


def _reduce_seq(seq) -> Tuple[int, ...]:
    # Observaveis binarios hermitianos: O_s^2 = I.
    stack: List[int] = []
    for letter in seq:
        if stack and stack[-1] == letter:
            stack.pop()
        else:
            stack.append(letter)
    return tuple(stack)


def reduce_word(w: Word) -> Word:
    # A primeira sequencia pertence a Bob; a segunda, a Eve.
    # A separacao em fatores implementa [B_y,E_*]=0.
    return _reduce_seq(w[0]), _reduce_seq(w[1])


def word_mul(a: Word, b: Word) -> Word:
    return reduce_word((a[0] + b[0], a[1] + b[1]))


def word_adj(w: Word) -> Word:
    return reduce_word((tuple(reversed(w[0])), tuple(reversed(w[1]))))


def word_len(w: Word) -> int:
    return len(w[0]) + len(w[1])


def B_word(y: int) -> Word:
    return (y,), tuple()


def E_word() -> Word:
    # Um unico setting E_* por SDP fixed-input.
    return tuple(), (0,)


def BE_word(y: int) -> Word:
    return (y,), (0,)


def normalize_level(level: str) -> str:
    aliases = {
        "L11+BR": "L11+BE",
        "L11+BC": "L11+BE",
    }
    return aliases.get(level, level)


def gen_words(level: str) -> List[Word]:
    level = normalize_level(level)

    if level == "L11":
        words = {ID_WORD, E_word()}
        words.update(B_word(y) for y in range(N_B))

    elif level == "L11+BE":
        words = {ID_WORD, E_word()}
        words.update(B_word(y) for y in range(N_B))
        words.update(BE_word(y) for y in range(N_B))

    elif level == "L12":
        # Todas as words reduzidas de comprimento total <= 2.
        words = {ID_WORD}
        for b_len in range(3):
            for e_len in range(3 - b_len):
                for bs in product(range(N_B), repeat=b_len):
                    for es in product(range(1), repeat=e_len):
                        words.add(reduce_word((bs, es)))
    else:
        raise ValueError("PAM_LEVEL deve ser 'L11', 'L11+BE' ou 'L12'.")

    return sorted(words, key=lambda w: (word_len(w), w))


def gen_monos(n: int) -> List[Mono]:
    monos = [mono_one(n)]
    for k in range(n):
        a = mono_alpha(n, k)
        monos.extend([a, mono_conj(a)])
    return monos


def _star(key: MomentKey) -> MomentKey:
    mono, i, j, word = key
    return mono_conj(mono), j, i, word_adj(word)


def _canon(mono: Mono, i: int, j: int, word: Word):
    key = mono, i, j, reduce_word(word)
    star = _star(key)
    if key == star:
        return key, True, True
    canon = min(key, star)
    return canon, key == canon, False


class PAMQuantumEveRelaxation:
    """Relaxacao NV/NPA para preparacoes de dimensao fixa e Eve complementar.

    A entrada tem dimensao D=2. A isometria e absorvida nos momentos

        <i| U^dagger S^dagger T U |j>,

    onde S,T sao words de Bob e Eve. As dimensoes dos outputs B e E nao sao
    fixadas. Bob e Eve sao sistemas distintos, portanto suas words comutam.
    """

    def __init__(
        self,
        level: str = "L11+BE",
        fix_first_preparation: bool = True,
        enforce_probability_positivity: bool = True,
        name: str = "pam_s3_qeve",
    ):
        self.n_x = N_X
        self.level = normalize_level(level)
        self.n_alpha = self.n_x * D

        # Gauge: |psi_0> = |0> ate fase global.
        self._zero_idx = set(range(1, D)) if fix_first_preparation else set()
        self.monos = [m for m in gen_monos(self.n_alpha) if not self._mono_has_zero(m)]
        self.words = gen_words(self.level)
        self.rows = [
            (mono, i, word)
            for mono in self.monos
            for i in range(D)
            for word in self.words
        ]
        self.n = len(self.rows)

        entries = []
        keys = set()
        self_adjoint = set()

        for a, (mu, i, u) in enumerate(self.rows):
            for b, (nu, j, v) in enumerate(self.rows):
                scalar = mono_mul(mono_conj(mu), nu)
                word = word_mul(word_adj(u), v)
                canon, direct, is_self_adjoint = _canon(scalar, i, j, word)
                entries.append((a, b, canon, direct))
                keys.add(canon)
                if is_self_adjoint:
                    self_adjoint.add(canon)

        self.keys = sorted(keys)
        self.key_index = {key: k for k, key in enumerate(self.keys)}
        self.self_adjoint_indices = np.array(
            [self.key_index[key] for key in self_adjoint], dtype=int
        )

        self.moments = cp.Variable(len(self.keys), complex=True, name=f"{name}_moments")
        self.constraints = []

        if len(self.self_adjoint_indices):
            self.constraints.append(cp.imag(self.moments[self.self_adjoint_indices]) == 0)

        direct_rows, direct_cols, direct_data = [], [], []
        conj_rows, conj_cols, conj_data = [], [], []

        for a, b, key, direct in entries:
            flat = a * self.n + b
            k = self.key_index[key]
            if direct:
                direct_rows.append(flat)
                direct_cols.append(k)
                direct_data.append(1.0)
            else:
                conj_rows.append(flat)
                conj_cols.append(k)
                conj_data.append(1.0)

        A = sp.csr_matrix(
            (direct_data, (direct_rows, direct_cols)),
            shape=(self.n * self.n, len(self.keys)),
        )
        B = sp.csr_matrix(
            (conj_data, (conj_rows, conj_cols)),
            shape=(self.n * self.n, len(self.keys)),
        )

        vec_matrix = cp.Constant(A) @ self.moments + cp.Constant(B) @ cp.conj(self.moments)
        self.M = cp.reshape(vec_matrix, (self.n, self.n), order="C")
        self.constraints.append(self.M >> 0)

        one = mono_one(self.n_alpha)
        self.weight = cp.real(self.m(one, 0, 0, ID_WORD))

        self._add_frame_constraints()
        self._add_preparation_constraints()
        if enforce_probability_positivity:
            self._add_probability_constraints()

    def _mono_has_zero(self, mono: Mono) -> bool:
        if not self._zero_idx:
            return False
        return any(mono[0][k] or mono[1][k] for k in self._zero_idx)

    def m(self, mono: Mono, i: int, j: int, word: Word):
        if self._mono_has_zero(mono):
            return cp.Constant(0.0)

        key = mono, i, j, reduce_word(word)
        star = _star(key)
        canon = key if key == star else min(key, star)

        if canon not in self.key_index:
            raise KeyError(f"Momento ausente no nivel {self.level}: {key}")

        value = self.moments[self.key_index[canon]]
        return value if key == canon else cp.conj(value)

    def _monomial_products(self) -> List[Mono]:
        return list(dict.fromkeys(
            mono_mul(mono_conj(a), b)
            for a in self.monos
            for b in self.monos
        ))

    def _visible_words(self) -> List[Word]:
        return sorted(
            {
                word_mul(word_adj(u), v)
                for u in self.words
                for v in self.words
            },
            key=lambda w: (word_len(w), w),
        )

    def _add_frame_constraints(self):
        one = mono_one(self.n_alpha)

        # U^dagger U = I_D.
        for i in range(D):
            for j in range(D):
                rhs = self.weight if i == j else 0.0
                self.constraints.append(self.m(one, i, j, ID_WORD) == rhs)
        self.constraints.append(self.weight == 1.0)

        for mm in self._monomial_products():
            for i in range(D):
                for j in range(D):
                    try:
                        moment = self.m(mm, i, j, ID_WORD)
                    except KeyError:
                        continue
                    if i != j:
                        self.constraints.append(moment == 0.0)

            for i in range(1, D):
                try:
                    self.constraints.append(
                        self.m(mm, i, i, ID_WORD) == self.m(mm, 0, 0, ID_WORD)
                    )
                except KeyError:
                    pass

    def _add_preparation_constraints(self):
        one = mono_one(self.n_alpha)
        visible_words = self._visible_words()

        # Para cada preparacao x: sum_k |alpha_{xk}|^2 = 1, multiplicada por
        # todos os momentos visiveis disponiveis no nivel.
        for x in range(self.n_x):
            for i in range(D):
                for j in range(D):
                    for word in visible_words:
                        lhs = 0
                        available = True
                        for k in range(D):
                            alpha = mono_alpha(self.n_alpha, x * D + k)
                            abs_sq = mono_mul(mono_conj(alpha), alpha)
                            try:
                                lhs += self.m(abs_sq, i, j, word)
                            except KeyError:
                                available = False
                                break
                        if not available:
                            continue
                        try:
                            rhs = self.m(one, i, j, word)
                        except KeyError:
                            continue
                        self.constraints.append(lhs == rhs)

    def _corr(self, x: int, word: Word):
        expression = 0
        for i in range(D):
            for j in range(D):
                alpha_i = mono_alpha(self.n_alpha, x * D + i)
                alpha_j = mono_alpha(self.n_alpha, x * D + j)
                scalar = mono_mul(mono_conj(alpha_i), alpha_j)
                expression += self.m(scalar, i, j, word)
        return cp.real(expression)

    def corrB(self, x: int, y: int):
        return self._corr(x, B_word(y))

    def corrE(self, x: int):
        return self._corr(x, E_word())

    def corrBE(self, x: int, y: int):
        return self._corr(x, BE_word(y))

    def probBE(self, b: int, e: int, x: int, y: int):
        sb = 1.0 if b == 0 else -1.0
        se = 1.0 if e == 0 else -1.0
        return 0.25 * (
            self.weight
            + sb * self.corrB(x, y)
            + se * self.corrE(x)
            + sb * se * self.corrBE(x, y)
        )

    def probB(self, b: int, x: int, y: int):
        sb = 1.0 if b == 0 else -1.0
        return 0.5 * (self.weight + sb * self.corrB(x, y))

    def _add_probability_constraints(self):
        for x in range(self.n_x):
            for y in range(N_B):
                probs = [
                    self.probBE(b, e, x, y)
                    for b in (0, 1)
                    for e in (0, 1)
                ]
                self.constraints.append(cp.hstack(probs) >= 0.0)
                self.constraints.append(sum(probs) == self.weight)

    def s3_expr(self):
        return (
            self.corrB(0, 0)
            + self.corrB(0, 1)
            + self.corrB(1, 0)
            - self.corrB(1, 1)
            - self.corrB(2, 0)
        )

    def guessing_expr_fixed(self, x_star: int, y_star: int):
        if (x_star, y_star) not in FIXED_INPUTS:
            raise ValueError(f"Input fixo invalido: {(x_star, y_star)}")
        return (
            self.probBE(0, 0, x_star, y_star)
            + self.probBE(1, 1, x_star, y_star)
        )

    def bob_eve_commutation_sanity(self) -> bool:
        return word_mul(B_word(0), E_word()) == word_mul(E_word(), B_word(0))



# =============================================================================
# 4. Funcao suporte reutilizavel para os seis inputs
# =============================================================================


def solver_kwargs(solver: str, verbose: bool = False):
    solver = solver.upper()

    if solver == "MOSEK":
        params = {
            "MSK_DPAR_INTPNT_CO_TOL_PFEAS": MOSEK_TOL,
            "MSK_DPAR_INTPNT_CO_TOL_DFEAS": MOSEK_TOL,
            "MSK_DPAR_INTPNT_CO_TOL_REL_GAP": MOSEK_TOL,
            "MSK_IPAR_NUM_THREADS": MOSEK_THREADS,
            "MSK_IPAR_INTPNT_SOLVE_FORM": MOSEK_SOLVE_FORM,
        }
        if MOSEK_MAX_TIME > 0:
            params["MSK_DPAR_OPTIMIZER_MAX_TIME"] = MOSEK_MAX_TIME
        return {"solver": cp.MOSEK, "verbose": verbose, "mosek_params": params}

    if solver == "SCS":
        return {
            "solver": cp.SCS,
            "verbose": verbose,
            "eps": 1e-5,
            "max_iters": 300000,
            "use_indirect": True,
        }

    if solver == "CLARABEL":
        return {"solver": cp.CLARABEL, "verbose": verbose}

    raise ValueError(f"Solver nao configurado: {solver}")



class FixedInputS3HybridSDP:
    """Um unico modelo DPP para suporte centrado e validacao direta.

    A mesma matriz de momentos e as mesmas variaveis sao reutilizadas. Para
    a funcao suporte, nu_lower e colocado abaixo do minimo algebrico. Para
    um ponto direto, lambda=0 e nu_lower recebe o valor alvo.
    """

    def __init__(
        self,
        level: str = "L11+BE",
        gauge: bool = True,
        solver: str = SOLVER,
        verbose_solver: bool = VERBOSE_SOLVER,
    ):
        self.level = normalize_level(level)
        self.gauge = bool(gauge)
        self.solver = solver.upper()
        self.verbose_solver = bool(verbose_solver)
        self.inputs = FIXED_INPUTS.copy()

        self.rel = PAMQuantumEveRelaxation(
            level=self.level,
            fix_first_preparation=self.gauge,
            enforce_probability_positivity=True,
            name=f"S3_hybrid_{self.level.replace('+', 'p')}",
        )

        self.s3_value = self.rel.s3_expr()
        self.violation_normalized = (self.s3_value - S3_CLASSICAL) / S3_GAP
        self.guessing_values = cp.hstack([
            self.rel.guessing_expr_fixed(x, y) for x, y in self.inputs
        ])

        self.selector = cp.Parameter(len(self.inputs), nonneg=True, name="input_selector")
        self.lambda_support = cp.Parameter(nonneg=True, name="lambda_support")
        self.nu_lower = cp.Parameter(name="nu_lower")
        self.selected_guessing = cp.sum(cp.multiply(self.selector, self.guessing_values))

        constraints = list(self.rel.constraints) + [
            self.violation_normalized <= 1.0,
            self.violation_normalized >= self.nu_lower,
        ]

        # Funcao suporte centrada no endpoint. O otimizador e o mesmo de
        # G+lambda*nu, pois -lambda e uma constante, mas o valor objetivo
        # permanece O(1), evitando cancelamento catastrofico.
        self.objective_expression = (
            self.selected_guessing
            + self.lambda_support * (self.violation_normalized - SUPPORT_CENTER)
        )
        self.problem = cp.Problem(cp.Maximize(self.objective_expression), constraints)

        if not self.problem.is_dcp():
            raise RuntimeError("O problema hibrido nao e DCP.")
        if not self.problem.is_dpp():
            raise RuntimeError("O problema hibrido nao e DPP.")

    def _set_input(self, x_star: int, y_star: int) -> int:
        try:
            index = self.inputs.index((int(x_star), int(y_star)))
        except ValueError as exc:
            raise ValueError(f"Input fixo invalido: {(x_star, y_star)}") from exc
        selector = np.zeros(len(self.inputs), dtype=float)
        selector[index] = 1.0
        self.selector.value = selector
        return index

    def _solve_current(self):
        try:
            return self.problem.solve(
                **solver_kwargs(self.solver, self.verbose_solver),
                warm_start=True,
                ignore_dpp=False,
            )
        except Exception as exc:
            message = str(exc)
            if "err_space" in message or "Out of space" in message:
                raise MemoryError(
                    "MOSEK ficou sem memoria. O programa usa uma unica matriz "
                    "132x132, uma thread e a forma dual. Feche outros programas "
                    "e confirme PAM_MOSEK_SOLVE_FORM=MSK_SOLVE_DUAL."
                ) from exc
            raise

    def solve_support(self, x_star: int, y_star: int, lambda_value: float, diagnostics=False) -> dict:
        input_index = self._set_input(x_star, y_star)
        lambda_value = float(lambda_value)
        if lambda_value < 0:
            raise ValueError("lambda deve ser nao negativo.")
        self.lambda_support.value = lambda_value
        self.nu_lower.value = NU_GLOBAL_MIN

        t0 = time.time()
        value = self._solve_current()
        elapsed = time.time() - t0
        if self.problem.status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE}:
            raise RuntimeError(
                f"Suporte sem solucao utilizavel para input={(x_star,y_star)}, "
                f"lambda={lambda_value}: {self.problem.status}"
            )

        q_raw = float(np.real(value))
        guess_at = float(np.real(self.guessing_values.value[input_index]))
        s3_at = float(np.real(self.s3_value.value))
        nu_at = float(np.real(self.violation_normalized.value))

        pad_abs = float(os.getenv("PAM_SUPPORT_PADDING_ABS", "2e-6"))
        pad_rel = float(os.getenv("PAM_SUPPORT_PADDING_REL", "2e-9"))
        q_upper = q_raw + pad_abs + pad_rel * max(1.0, abs(q_raw))

        stats = self.problem.solver_stats
        result = {
            "solve_type": "support_centered",
            "witness": "S3",
            "level": self.level,
            "gauge": self.gauge,
            "input_x": int(x_star),
            "input_y": int(y_star),
            "input_label": f"({int(x_star)},{int(y_star)})",
            "eve_setting": f"E_*[{int(x_star)},{int(y_star)}]",
            "lambda": lambda_value,
            "support_center": SUPPORT_CENTER,
            "support_centered_raw": q_raw,
            "support_centered_upper": q_upper,
            "s3_at_optimizer": s3_at,
            "nu_at_optimizer": nu_at,
            "guessing_at_optimizer": guess_at,
            "status": self.problem.status,
            "time_s": elapsed,
            "solver_time_s": getattr(stats, "solve_time", None),
            "num_iters": getattr(stats, "num_iters", None),
            "matrix_size": self.rel.n,
            "n_words": len(self.rel.words),
            "n_moments": len(self.rel.keys),
            "n_constraints": len(self.problem.constraints),
            "n_eve_settings": 1,
        }
        if diagnostics:
            result.update(self.diagnostics(x_star, y_star))
        return result

    def solve_direct(self, x_star: int, y_star: int, nu_target: float, diagnostics=False) -> dict:
        input_index = self._set_input(x_star, y_star)
        nu_target = float(nu_target)
        if not 0.0 <= nu_target <= 1.0:
            raise ValueError("nu_target deve pertencer a [0,1].")

        self.lambda_support.value = 0.0
        # Relaxar levemente a constraint amplia o conjunto factivel; por isso
        # o valor obtido continua sendo um upper bound conservador no alvo.
        self.nu_lower.value = max(NU_GLOBAL_MIN, nu_target - WITNESS_RELAXATION)

        t0 = time.time()
        value = self._solve_current()
        elapsed = time.time() - t0
        if self.problem.status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE}:
            raise RuntimeError(
                f"Ponto direto sem solucao utilizavel para input={(x_star,y_star)}, "
                f"nu={nu_target}: {self.problem.status}"
            )

        guess_raw = float(np.real(value))
        guess_at = float(np.real(self.guessing_values.value[input_index]))
        s3_at = float(np.real(self.s3_value.value))
        nu_at = float(np.real(self.violation_normalized.value))

        pad_abs = float(os.getenv("PAM_DIRECT_PADDING_ABS", "3e-6"))
        pad_rel = float(os.getenv("PAM_DIRECT_PADDING_REL", "2e-9"))
        guess_upper = min(1.0, guess_raw + pad_abs + pad_rel * max(1.0, abs(guess_raw)))

        stats = self.problem.solver_stats
        result = {
            "solve_type": "direct_anchor",
            "witness": "S3",
            "level": self.level,
            "gauge": self.gauge,
            "input_x": int(x_star),
            "input_y": int(y_star),
            "input_label": f"({int(x_star)},{int(y_star)})",
            "eve_setting": f"E_*[{int(x_star)},{int(y_star)}]",
            "nu_target": nu_target,
            "nu_constraint_used": float(self.nu_lower.value),
            "guessing_raw": guess_raw,
            "guessing_upper": guess_upper,
            "s3_at_optimizer": s3_at,
            "nu_at_optimizer": nu_at,
            "guessing_at_optimizer": guess_at,
            "status": self.problem.status,
            "time_s": elapsed,
            "solver_time_s": getattr(stats, "solve_time", None),
            "num_iters": getattr(stats, "num_iters", None),
            "matrix_size": self.rel.n,
            "n_words": len(self.rel.words),
            "n_moments": len(self.rel.keys),
            "n_constraints": len(self.problem.constraints),
            "n_eve_settings": 1,
        }
        if diagnostics:
            result.update(self.diagnostics(x_star, y_star))
        return result

    def diagnostics(self, x_star: int, y_star: int) -> dict:
        min_probability = np.inf
        max_normalization_residual = 0.0
        for x in range(N_X):
            for y in range(N_B):
                probs = [
                    float(np.real(self.rel.probBE(b, e, x, y).value))
                    for b in (0, 1) for e in (0, 1)
                ]
                min_probability = min(min_probability, min(probs))
                max_normalization_residual = max(
                    max_normalization_residual, abs(sum(probs) - 1.0)
                )
        direct_guess = float(np.real(
            self.rel.probBE(0, 0, x_star, y_star).value
            + self.rel.probBE(1, 1, x_star, y_star).value
        ))
        return {
            "min_joint_probability": min_probability,
            "max_joint_normalization_residual": max_normalization_residual,
            "guessing_expression_residual": abs(
                direct_guess - float(np.real(self.selected_guessing.value))
            ),
        }


# =============================================================================
# 5. Grades, checkpoints e reconstrucao fisicamente saneada
# =============================================================================

LEVEL = normalize_level(os.getenv("PAM_LEVEL", "L11+BE"))
GAUGE = os.getenv("PAM_GAUGE", "1") == "1"
RESUME = os.getenv("PAM_RESUME", "1") == "1"
PLOT_ONLY = os.getenv("PAM_PLOT_ONLY", "0") == "1"
FAST_TEST = os.getenv("PAM_FAST_TEST", "0") == "1"

CURVE_POINTS = int(os.getenv("PAM_CURVE_POINTS", "501"))
LAMBDA_MIN = float(os.getenv("PAM_LAMBDA_MIN", "1e-4"))
LAMBDA_MAX = float(os.getenv("PAM_LAMBDA_MAX", "1e3"))
LAMBDA_COUNT = int(os.getenv("PAM_LAMBDA_COUNT", "25"))
ADAPTIVE_ROUNDS = int(os.getenv("PAM_ADAPTIVE_ROUNDS", "2"))
ADAPTIVE_MAX_NEW = int(os.getenv("PAM_ADAPTIVE_MAX_NEW", "10"))
LAMBDA_HARD_MAX = float(os.getenv("PAM_LAMBDA_HARD_MAX", "1e3"))


def level_tag(level: str) -> str:
    return level.replace("+", "p")


def support_checkpoint_path() -> Path:
    return OUTPUT_DIR / f"support_centered_checkpoint_S3_{level_tag(LEVEL)}.csv"


def direct_checkpoint_path() -> Path:
    return OUTPUT_DIR / f"direct_anchors_checkpoint_S3_{level_tag(LEVEL)}.csv"


def support_final_path() -> Path:
    return OUTPUT_DIR / f"support_centered_values_S3_{level_tag(LEVEL)}.csv"


def direct_final_path() -> Path:
    return OUTPUT_DIR / f"direct_anchor_values_S3_{level_tag(LEVEL)}.csv"


def curve_combined_path() -> Path:
    return OUTPUT_DIR / f"S3_full_curve_all_fixed_inputs_{level_tag(LEVEL)}_CORRIGIDO.csv"


def curve_input_path(x: int, y: int) -> Path:
    return OUTPUT_DIR / f"S3_full_curve_x{x}_y{y}_{level_tag(LEVEL)}_CORRIGIDO.csv"


def parse_lambda_grid() -> np.ndarray:
    raw = os.getenv("PAM_LAMBDAS", "").strip()
    if raw:
        values = np.array([float(v.strip()) for v in raw.split(",") if v.strip()])
    elif FAST_TEST:
        values = np.array([0.0, 1e-2, 1e-1, 1.0, 10.0, 100.0])
    else:
        values = np.concatenate([
            [0.0],
            np.logspace(math.log10(LAMBDA_MIN), math.log10(LAMBDA_MAX), LAMBDA_COUNT),
            [1e-3, 1e-2, 1e-1, 1.0, 3.0, 10.0, 30.0, 100.0, 300.0, 1000.0],
        ])
    values = values[(values >= 0.0) & (values <= LAMBDA_HARD_MAX)]
    return np.unique(np.round(values.astype(float), 14))


def parse_direct_grid() -> np.ndarray:
    raw = os.getenv("PAM_DIRECT_NUS", "").strip()
    if raw:
        values = np.array([float(v.strip()) for v in raw.split(",") if v.strip()])
    elif FAST_TEST:
        values = np.array([0.99, 1.0])
    else:
        values = np.array([0.95, 0.98, 0.99, 0.995, 0.998, 0.999,
                           0.9995, 0.9998, 0.9999, 1.0])
    if np.any((values < 0.0) | (values > 1.0)):
        raise ValueError("Todos os PAM_DIRECT_NUS devem pertencer a [0,1].")
    return np.unique(np.round(values.astype(float), 10))


INITIAL_LAMBDAS = parse_lambda_grid()
DIRECT_NUS = parse_direct_grid()
NU_GRID = np.linspace(0.0, 1.0, CURVE_POINTS)


def read_records(path: Path) -> list[dict]:
    if RESUME and path.exists():
        frame = pd.read_csv(path)
        if not frame.empty:
            print(f"Retomando {path}: {len(frame)} solves salvos.")
            return frame.to_dict("records")
    return []


def save_records(records: list[dict], path: Path, keys: list[str]) -> None:
    pd.DataFrame(records).sort_values(keys).to_csv(path, index=False)


def solve_missing_support(model, records, x, y, lambdas, diagnostic_flag):
    solved = {
        round(float(r["lambda"]), 14) for r in records
        if int(r.get("input_x", -1)) == x and int(r.get("input_y", -1)) == y
    }
    for lam in sorted(float(v) for v in lambdas):
        key = round(lam, 14)
        if key in solved:
            continue
        print(f"SUPORTE CENTRADO input=({x},{y}) | lambda={lam:.12g}", flush=True)
        row = model.solve_support(x, y, lam, diagnostics=diagnostic_flag[0])
        diagnostic_flag[0] = False
        records.append(row)
        solved.add(key)
        save_records(records, support_checkpoint_path(), ["input_x", "input_y", "lambda"])
        print(
            f"  status={row['status']} | q<={row['support_centered_upper']:.10f} | "
            f"G_at={row['guessing_at_optimizer']:.10f} | "
            f"S3_at={row['s3_at_optimizer']:.10f} | "
            f"nu_at={row['nu_at_optimizer']:.8f} | {row['time_s']:.1f}s",
            flush=True,
        )


def solve_missing_direct(model, records, x, y, targets, diagnostic_flag):
    solved = {
        round(float(r["nu_target"]), 10) for r in records
        if int(r.get("input_x", -1)) == x and int(r.get("input_y", -1)) == y
    }
    for target in sorted((float(v) for v in targets), reverse=True):
        key = round(target, 10)
        if key in solved:
            continue
        print(f"ANCORA DIRETA input=({x},{y}) | nu_target={target:.10f}", flush=True)
        row = model.solve_direct(x, y, target, diagnostics=diagnostic_flag[0])
        diagnostic_flag[0] = False
        records.append(row)
        solved.add(key)
        save_records(records, direct_checkpoint_path(), ["input_x", "input_y", "nu_target"])
        print(
            f"  status={row['status']} | G<={row['guessing_upper']:.10f} | "
            f"G_at={row['guessing_at_optimizer']:.10f} | "
            f"S3_at={row['s3_at_optimizer']:.10f} | "
            f"nu_at={row['nu_at_optimizer']:.8f} | {row['time_s']:.1f}s",
            flush=True,
        )


def support_adaptive_candidates(group: pd.DataFrame) -> list[float]:
    if len(group) < 2:
        return []
    lambdas = np.sort(group["lambda"].unique().astype(float))
    candidates = []
    for left, right in zip(lambdas[:-1], lambdas[1:]):
        if right <= left:
            continue
        if left == 0:
            candidate = right / 3.0
            score = 1.0
        else:
            candidate = math.sqrt(left * right)
            score = math.log10(right / left)
        if score > 0.30 and candidate <= LAMBDA_HARD_MAX:
            candidates.append((score, candidate))
    candidates.sort(reverse=True)
    return [float(v) for _, v in candidates[:ADAPTIVE_MAX_NEW]]


def endpoint_analytic_floor(x: int, y: int) -> float:
    # No maximo qubit de S3: B0 e B1 sao ortogonais. Para os quatro termos
    # CHSH-like, |<B_y>|=1/sqrt(2); (2,0) e deterministico; (2,1) e unbiased.
    if (x, y) in {(0, 0), (0, 1), (1, 0), (1, 1)}:
        return 0.5 * (1.0 + 1.0 / math.sqrt(2.0))
    if (x, y) == (2, 0):
        return 1.0
    return 0.5


def reconstruct_curve(support_frame, direct_frame, x, y, nu_grid=NU_GRID):
    sg = support_frame[
        (support_frame["input_x"] == x) & (support_frame["input_y"] == y)
    ].sort_values("lambda").drop_duplicates("lambda", keep="last")
    dg = direct_frame[
        (direct_frame["input_x"] == x) & (direct_frame["input_y"] == y)
    ].sort_values("nu_target").drop_duplicates("nu_target", keep="last")
    if sg.empty:
        raise RuntimeError(f"Sem suporte para input {(x,y)}.")

    lambdas = sg["lambda"].to_numpy(float)
    q_upper = sg["support_centered_upper"].to_numpy(float)
    lines = q_upper[:, None] + lambdas[:, None] * (SUPPORT_CENTER - nu_grid[None, :])
    active = np.argmin(lines, axis=0)
    support_bound = lines[active, np.arange(len(nu_grid))]

    direct_bound = np.full(len(nu_grid), np.inf)
    direct_active_nu = np.full(len(nu_grid), np.nan)
    if not dg.empty:
        targets = dg["nu_target"].to_numpy(float)
        bounds = dg["guessing_upper"].to_numpy(float)
        for i, nu in enumerate(nu_grid):
            eligible = np.where(targets <= nu + 1e-12)[0]
            if len(eligible):
                vals = bounds[eligible]
                jlocal = int(np.argmin(vals))
                j = eligible[jlocal]
                direct_bound[i] = bounds[j]
                direct_active_nu[i] = targets[j]

    combined_raw = np.minimum(support_bound, direct_bound)
    # Universal facts: binary guessing is at least 1/2 and at most 1.
    pguess = np.clip(combined_raw, 0.5, 1.0)

    # Exact endpoint sanity floors. Raising a purported upper bound to a known
    # achievable value preserves validity and prevents unphysical Hmin>1.
    if np.isclose(nu_grid[-1], 1.0):
        pguess[-1] = max(pguess[-1], endpoint_analytic_floor(x, y))

    # G(nu) must be non-increasing. Build a conservative majorant by only
    # raising earlier values.
    for i in range(len(pguess) - 2, -1, -1):
        pguess[i] = max(pguess[i], pguess[i + 1])

    hmin = -np.log2(np.maximum(pguess, 1e-300))
    hmin = np.clip(hmin, 0.0, 1.0)

    return pd.DataFrame({
        "witness": "S3",
        "level": LEVEL,
        "input_x": x,
        "input_y": y,
        "input_label": f"({x},{y})",
        "eve_setting": f"E_*[{x},{y}]",
        "nu": nu_grid,
        "s3": s3_from_nu(nu_grid),
        "pguess_support_centered": support_bound,
        "pguess_direct_anchor": direct_bound,
        "pguess_upper": pguess,
        "hmin_lower": hmin,
        "active_lambda": lambdas[active],
        "active_support_centered_upper": q_upper[active],
        "active_direct_nu": direct_active_nu,
        "endpoint_analytic_floor": endpoint_analytic_floor(x, y),
        "numerical_scheme": "centered_support_plus_direct_anchors",
    })


def scan_all():
    print("\n" + "=" * 104)
    print(f"PAM S3 | EVE QUANTICA | SUPORTE CENTRADO + ANCORAS DIRETAS | {LEVEL}")
    print("=" * 104)
    model = FixedInputS3HybridSDP(LEVEL, GAUGE, SOLVER, VERBOSE_SOLVER)
    print("Arquitetura: |psi_x> --U--> Bob + Eve")
    print("Bob e Eve comutam:", model.rel.bob_eve_commutation_sanity())
    print("DCP:", model.problem.is_dcp(), "| DPP:", model.problem.is_dpp())
    print("Matriz de momentos:", model.rel.n)
    print("Momentos canonicos:", len(model.rel.keys))
    print("Lambdas (hard cap = 1e3):", INITIAL_LAMBDAS)
    print("Ancoras diretas:", DIRECT_NUS)
    print("Curva final:", CURVE_POINTS, "pontos")

    support_records = read_records(support_checkpoint_path())
    direct_records = read_records(direct_checkpoint_path())
    diagnostic_flag = [len(support_records) + len(direct_records) == 0]

    for x, y in FIXED_INPUTS:
        print("\n" + "-" * 80)
        print(f"INPUT FIXO ({x},{y})")
        print("-" * 80)
        solve_missing_support(model, support_records, x, y, INITIAL_LAMBDAS, diagnostic_flag)
        for rnd in range(ADAPTIVE_ROUNDS):
            sf = pd.DataFrame(support_records)
            group = sf[(sf.input_x == x) & (sf.input_y == y)]
            candidates = support_adaptive_candidates(group)
            if not candidates:
                break
            print(f"Refinamento suporte {rnd+1}: {candidates}")
            solve_missing_support(model, support_records, x, y, candidates, diagnostic_flag)
        solve_missing_direct(model, direct_records, x, y, DIRECT_NUS, diagnostic_flag)
        gc.collect()

    sf = pd.DataFrame(support_records).sort_values(["input_x", "input_y", "lambda"])
    df = pd.DataFrame(direct_records).sort_values(["input_x", "input_y", "nu_target"])
    sf.to_csv(support_final_path(), index=False)
    df.to_csv(direct_final_path(), index=False)

    curves = [reconstruct_curve(sf, df, x, y) for x, y in FIXED_INPUTS]
    cf = pd.concat(curves, ignore_index=True)
    cf.to_csv(curve_combined_path(), index=False)
    del model
    gc.collect()
    return sf, df, cf


# =============================================================================
# 6. Graficos e diagnosticos
# =============================================================================

INPUT_MARKERS = ["o", "s", "^", "v", "D", "P"]
INPUT_LINESTYLES = ["-", "--", "-.", ":", "-", "--"]


def add_s3_top_axis(ax):
    top = ax.secondary_xaxis("top", functions=(s3_from_nu, nu_from_s3))
    top.set_xlabel(r"Witness value $S_3$")
    top.set_xticks(s3_from_nu(np.array([0, .25, .5, .75, 1.])))


def plot_all(curve_frame, quantity):
    if quantity == "Pguess":
        col, ylabel, stem = "pguess_upper", r"$P_{\rm guess}(B|E,x^*,y^*)$", "Pguess"
    else:
        col, ylabel, stem = "hmin_lower", r"$H_{\min}(B|E,x^*,y^*)$ [bits]", "Hmin"
    fig, ax = plt.subplots(figsize=(8.3, 5.5))
    for idx, ((x, y), g) in enumerate(curve_frame.groupby(["input_x", "input_y"])):
        g = g.sort_values("nu")
        ax.plot(g.nu, g[col], linewidth=1.9,
                linestyle=INPUT_LINESTYLES[idx % 6],
                marker=INPUT_MARKERS[idx % 6], markersize=3.2,
                markevery=max(1, len(g)//24), label=rf"$({int(x)},{int(y)})$")
    ax.set_xlabel(r"Normalized violation $\nu=(S_3-S_3^{\rm C})/(S_3^{\rm Q}-S_3^{\rm C})$")
    ax.set_ylabel(ylabel)
    ax.set_xlim(0, 1.001)
    ax.set_ylim(0, 1.02)
    ax.grid(alpha=.24)
    ax.legend(title=r"Fixed input $(x^*,y^*)$", ncol=2, frameon=False)
    add_s3_top_axis(ax)
    fig.tight_layout()
    path = OUTPUT_DIR / f"S3_CORRIGIDO_all_fixed_inputs_{stem}_{level_tag(LEVEL)}.pdf"
    fig.savefig(path, bbox_inches="tight")
    fig.savefig(path.with_suffix(".png"), dpi=320, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_individual(curve_frame, x, y, quantity):
    if quantity == "Pguess":
        col, ylabel, stem = "pguess_upper", r"$P_{\rm guess}(B|E,x^*,y^*)$", "Pguess"
    else:
        col, ylabel, stem = "hmin_lower", r"$H_{\min}(B|E,x^*,y^*)$ [bits]", "Hmin"
    g = curve_frame[(curve_frame.input_x == x) & (curve_frame.input_y == y)].sort_values("nu")
    fig, ax = plt.subplots(figsize=(6.8, 4.7))
    ax.plot(g.nu, g[col], linewidth=2.1)
    ax.set_xlabel(r"Normalized violation $\nu$")
    ax.set_ylabel(ylabel)
    ax.set_xlim(0, 1.001)
    ax.set_ylim(0, 1.02)
    ax.grid(alpha=.24)
    add_s3_top_axis(ax)
    fig.tight_layout()
    path = OUTPUT_DIR / f"S3_CORRIGIDO_x{x}_y{y}_{stem}_{level_tag(LEVEL)}.pdf"
    fig.savefig(path, bbox_inches="tight")
    fig.savefig(path.with_suffix(".png"), dpi=320, bbox_inches="tight")
    plt.close(fig)
    return path


def save_summary(sf, df, cf):
    rows = []
    expected = {
        (0,0): .5*(1+1/math.sqrt(2)), (0,1): .5*(1+1/math.sqrt(2)),
        (1,0): .5*(1+1/math.sqrt(2)), (1,1): .5*(1+1/math.sqrt(2)),
        (2,0): 1.0, (2,1): .5,
    }
    for x, y in FIXED_INPUTS:
        c = cf[(cf.input_x == x) & (cf.input_y == y)].sort_values("nu")
        endpoint = c.iloc[-1]
        direct_ep = df[(df.input_x == x) & (df.input_y == y) & np.isclose(df.nu_target, 1.0)]
        rows.append({
            "input_x": x, "input_y": y,
            "endpoint_pguess_upper": float(endpoint.pguess_upper),
            "endpoint_hmin_lower_bits": float(endpoint.hmin_lower),
            "endpoint_expected_ideal_value": expected[(x,y)],
            "endpoint_direct_upper": float(direct_ep.guessing_upper.iloc[-1]) if not direct_ep.empty else np.nan,
            "min_pguess_on_curve": float(c.pguess_upper.min()),
            "max_hmin_on_curve": float(c.hmin_lower.max()),
            "physical_binary_checks_pass": bool((c.pguess_upper >= .5-1e-12).all() and (c.hmin_lower <= 1+1e-12).all()),
            "n_support_solves": int(len(sf[(sf.input_x == x) & (sf.input_y == y)])),
            "n_direct_anchors": int(len(df[(df.input_x == x) & (df.input_y == y)])),
        })
    out = pd.DataFrame(rows)
    path = OUTPUT_DIR / f"S3_CORRIGIDO_summary_{level_tag(LEVEL)}.csv"
    out.to_csv(path, index=False)
    print("\nResumo fisico/numerico:")
    print(out.to_string(index=False))
    return path


def load_results():
    spath = support_final_path() if support_final_path().exists() else support_checkpoint_path()
    dpath = direct_final_path() if direct_final_path().exists() else direct_checkpoint_path()
    if not spath.exists() or not dpath.exists():
        raise RuntimeError("Faltam resultados de suporte ou ancoras diretas para replotar.")
    sf = pd.read_csv(spath)
    df = pd.read_csv(dpath)
    cf = pd.concat([reconstruct_curve(sf, df, x, y) for x, y in FIXED_INPUTS], ignore_index=True)
    return sf, df, cf


def generate_outputs(sf, df, cf):
    sf.to_csv(support_final_path(), index=False)
    df.to_csv(direct_final_path(), index=False)
    cf.to_csv(curve_combined_path(), index=False)
    for x, y in FIXED_INPUTS:
        g = cf[(cf.input_x == x) & (cf.input_y == y)]
        g.to_csv(curve_input_path(x, y), index=False)
        print("Grafico:", plot_individual(cf, x, y, "Pguess"))
        print("Grafico:", plot_individual(cf, x, y, "Hmin"))
    print("Grafico conjunto:", plot_all(cf, "Pguess"))
    print("Grafico conjunto:", plot_all(cf, "Hmin"))
    print("Resumo:", save_summary(sf, df, cf))
    print("CSV curva completa:", curve_combined_path())


def validate_configuration():
    print("CVXPY:", "nao carregado (plot-only)" if cp is None else cp.__version__)
    print("Solvers instalados:", installed)
    print("Solver:", SOLVER)
    print("Threads MOSEK:", MOSEK_THREADS)
    print("Forma MOSEK:", MOSEK_SOLVE_FORM)
    print("Output:", OUTPUT_DIR.resolve())
    print("Nivel:", LEVEL, "| Gauge:", GAUGE, "| Plot only:", PLOT_ONLY)
    if not PLOT_ONLY and SOLVER not in installed:
        raise RuntimeError(f"Solver {SOLVER} nao encontrado.")
    if LAMBDA_MAX > 1e3 or LAMBDA_HARD_MAX > 1e3:
        print("AVISO: o codigo limita lambda a 1e3 para evitar instabilidade numerica.")


def main():
    validate_configuration()
    if PLOT_ONLY:
        sf, df, cf = load_results()
    else:
        sf, df, cf = scan_all()
    generate_outputs(sf, df, cf)
    print("\nEXECUCAO CONCLUIDA COM SUPORTE CENTRADO E ENDPOINT VALIDADO.")


if __name__ == "__main__":
    main()
