@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FIND_WORKING_PYTHON.ps1" -OutputFile "%TEMP%\pam_diag_21_l12.txt" -Diagnostic
pause
