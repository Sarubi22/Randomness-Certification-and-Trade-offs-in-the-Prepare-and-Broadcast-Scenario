#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compara Eve clássica e Eve quântica para S3, input fixo (2,1), nível L(1,2)."""
from pathlib import Path
import math
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
BASE = Path(os.getenv("PAM_COMPARE_OUTPUT_DIR", ROOT / "resultados_S3_input_2_1_L12"))
QDIR = BASE / "quantum_eve_channel_complement"
CDIR = BASE / "classical_side_information"
OUT = BASE / "figuras_comparativas"
OUT.mkdir(parents=True, exist_ok=True)

qfiles = sorted(QDIR.glob("S3_full_curve_all_fixed_inputs_L12_CORRIGIDO.csv"))
cfiles = sorted(CDIR.glob("S3_classical_full_curve_all_fixed_inputs_L12pB.csv"))
if not qfiles:
    raise FileNotFoundError(f"CSV da Eve quântica não encontrado em {QDIR}")
if not cfiles:
    raise FileNotFoundError(f"CSV da Eve clássica não encontrado em {CDIR}")

q = pd.read_csv(qfiles[-1])
c = pd.read_csv(cfiles[-1])
q = q[(q["input_x"] == 2) & (q["input_y"] == 1)].copy()
c = c[(c["input_x"] == 2) & (c["input_y"] == 1)].copy()
if q.empty or c.empty:
    raise RuntimeError("Os CSVs não contêm o input fixo (2,1).")

keys = ["input_x", "input_y", "nu"]
df = q[keys + ["s3", "pguess_upper", "hmin_lower"]].merge(
    c[keys + ["pguess_classical_upper_raw", "hmin_classical_lower_raw"]],
    on=keys,
    how="inner",
).sort_values("nu")

# Relação de inclusão: ataques clássicos são subconjunto dos ataques quânticos.
# A versão 'tightened' é uma cota clássica adicional válida, mas a figura
# principal mantém as duas SDPs independentes para diagnosticar o gap de nível.
df["pguess_classical_upper_tightened"] = np.minimum(
    df["pguess_classical_upper_raw"], df["pguess_upper"]
)
df["hmin_classical_lower_tightened"] = -np.log2(
    np.maximum(df["pguess_classical_upper_tightened"], 1e-300)
)
df["independent_hmin_gap_classical_minus_quantum"] = (
    df["hmin_classical_lower_raw"] - df["hmin_lower"]
)
df["independent_pguess_gap_quantum_minus_classical"] = (
    df["pguess_upper"] - df["pguess_classical_upper_raw"]
)
df.to_csv(OUT / "S3_input_2_1_L12_classical_vs_quantum.csv", index=False)

S3C = 3.0
S3Q = 1.0 + 2.0 * math.sqrt(2.0)
GAP = S3Q - S3C

def s3_from_nu(v):
    return S3C + np.asarray(v) * GAP

def nu_from_s3(s):
    return (np.asarray(s) - S3C) / GAP

def decorate(ax, ylabel):
    ax.set_xlabel(r"Normalized violation $\nu=(S_3-S_3^{\rm C})/(S_3^{\rm Q}-S_3^{\rm C})$")
    ax.set_ylabel(ylabel)
    ax.set_xlim(0.0, 1.001)
    ax.set_ylim(0.0, 1.02)
    ax.grid(alpha=0.24)
    top = ax.secondary_xaxis("top", functions=(s3_from_nu, nu_from_s3))
    top.set_xlabel(r"Witness value $S_3$")
    top.set_xticks(s3_from_nu(np.array([0.0, 0.25, 0.5, 0.75, 1.0])))

def save_plot(kind, tightened=False):
    fig, ax = plt.subplots(figsize=(7.4, 5.2))
    if kind == "Hmin":
        qcol = "hmin_lower"
        ccol = "hmin_classical_lower_tightened" if tightened else "hmin_classical_lower_raw"
        ylabel = r"Certified $H_{\min}(B|x^*=2,y^*=1)$ [bits]"
    else:
        qcol = "pguess_upper"
        ccol = "pguess_classical_upper_tightened" if tightened else "pguess_classical_upper_raw"
        ylabel = r"Upper bound on $P_{\rm guess}(B|x^*=2,y^*=1)$"

    ax.plot(df["nu"], df[qcol], lw=2.3, ls="-", label=r"Quantum Eve: $L(1,2)$")
    ax.plot(df["nu"], df[ccol], lw=2.3, ls="--", label=r"Classical side information: $L(1,2)$")
    decorate(ax, ylabel)
    ax.legend(frameon=False, loc="best")
    ax.set_title(r"PAM $S_3$, fixed input $(x^*,y^*)=(2,1)$")
    fig.tight_layout()
    tag = "TIGHTENED_CLASSICAL" if tightened else "INDEPENDENT_SDPS"
    stem = OUT / f"S3_input_2_1_L12_classical_vs_quantum_{kind}_{tag}"
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=320, bbox_inches="tight")
    plt.close(fig)

for kind in ("Hmin", "Pguess"):
    save_plot(kind, tightened=False)
    save_plot(kind, tightened=True)

endpoint = df.iloc[-1]
summary = pd.DataFrame([{
    "input_x": 2,
    "input_y": 1,
    "level_quantum": "L12",
    "level_classical": "L12+B",
    "s3_endpoint": float(endpoint["s3"]),
    "quantum_endpoint_pguess_upper": float(endpoint["pguess_upper"]),
    "quantum_endpoint_hmin_lower": float(endpoint["hmin_lower"]),
    "classical_endpoint_pguess_upper_independent": float(endpoint["pguess_classical_upper_raw"]),
    "classical_endpoint_hmin_lower_independent": float(endpoint["hmin_classical_lower_raw"]),
    "classical_endpoint_pguess_upper_tightened": float(endpoint["pguess_classical_upper_tightened"]),
    "classical_endpoint_hmin_lower_tightened": float(endpoint["hmin_classical_lower_tightened"]),
    "max_independent_hmin_gap_classical_minus_quantum": float(df["independent_hmin_gap_classical_minus_quantum"].max()),
    "max_independent_pguess_gap_quantum_minus_classical": float(df["independent_pguess_gap_quantum_minus_classical"].max()),
}])
summary.to_csv(OUT / "S3_input_2_1_L12_summary.csv", index=False)
print("Figuras e CSV comparativos em:", OUT)
