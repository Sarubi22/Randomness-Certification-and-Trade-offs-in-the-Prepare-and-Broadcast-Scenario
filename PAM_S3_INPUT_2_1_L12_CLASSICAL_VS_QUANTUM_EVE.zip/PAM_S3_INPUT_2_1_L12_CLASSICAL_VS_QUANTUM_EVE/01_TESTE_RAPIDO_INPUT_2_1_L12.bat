@echo off
call "%~dp0RUN_INPUT_2_1_L12.cmd" FAST
