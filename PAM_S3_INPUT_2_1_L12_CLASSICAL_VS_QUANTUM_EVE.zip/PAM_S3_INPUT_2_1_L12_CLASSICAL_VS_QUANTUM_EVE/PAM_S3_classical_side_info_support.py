#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PAM S3: randomness marginal de Bob contra informacao lateral CLASSICA.

Cenario:
  * Alice envia um sistema de dimensao fixa d=2;
  * Bob tem y=0,1 e output binario b=0,1;
  * a estatistica observada e somente a witness S3;
  * Eve possui uma variavel classica Lambda, independente dos inputs,
    correlacionada com as preparacoes, canal e dispositivo de Bob.

Para um input fixo (x*,y*), os ramos de Lambda sao agrupados pelo palpite
binario g=0,1. Cada ramo e um comportamento qubit subnormalizado. O guessing e

    G_cl = p_tilde_0(b=0|x*,y*) + p_tilde_1(b=1|x*,y*).

A funcao suporte centrada no endpoint e

    q_cl(lambda) = max [G_cl + lambda (nu(S3_total)-1)],

com sum_g weight_g=1. A curva e reconstruida por

    G_cl(nu) <= min_lambda [q_cl(lambda)+lambda(1-nu)].

O programa usa dois blocos PSD pequenos (um por palpite classico), salva
checkpoints e gera a curva completa para o par fixo (x*,y*)=(2,1).
"""
from __future__ import annotations

import gc
import math
import os
import time
from itertools import product
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd
import scipy.sparse as sp

_PLOT_ONLY_EARLY = os.getenv("PAMC_PLOT_ONLY", "0") == "1"
if _PLOT_ONLY_EARLY:
    cp = None
else:
    import cvxpy as cp

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# -----------------------------------------------------------------------------
# Configuracao
# -----------------------------------------------------------------------------
SOLVER = os.getenv("PAMC_SOLVER", os.getenv("PAM_SOLVER", "MOSEK")).upper()
VERBOSE_SOLVER = os.getenv("PAMC_VERBOSE", "0") == "1"
MOSEK_THREADS = int(os.getenv("PAMC_MOSEK_THREADS", "1"))
MOSEK_TOL = float(os.getenv("PAMC_MOSEK_TOL", "1e-9"))
MOSEK_MAX_TIME = float(os.getenv("PAMC_MOSEK_MAX_TIME", "0"))
MOSEK_SOLVE_FORM = os.getenv("PAMC_MOSEK_SOLVE_FORM", "AUTO")
USE_DIRECT_ANCHORS = os.getenv("PAMC_USE_DIRECT_ANCHORS", "0") == "1"
WITNESS_RELAXATION = float(os.getenv("PAMC_WITNESS_RELAXATION", "1e-7"))
OUTPUT_DIR = Path(os.getenv(
    "PAMC_OUTPUT_DIR",
    "resultados_COMPARACAO_S3/classical_side_information",
))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
installed = [] if cp is None else cp.installed_solvers()

D = 2
N_X = 3
N_B = 2
FIXED_INPUTS = [(2, 1)]  # input de geracao fixo solicitado: (x*,y*)=(2,1)
S3_CLASSICAL = 3.0
S3_QUBIT = 1.0 + 2.0 * math.sqrt(2.0)
S3_GAP = S3_QUBIT - S3_CLASSICAL
S3_ALGEBRAIC_MIN = -5.0
SUPPORT_CENTER = 1.0
NU_GLOBAL_MIN = (S3_ALGEBRAIC_MIN - S3_CLASSICAL) / S3_GAP - 1e-6


def s3_from_nu(nu):
    return S3_CLASSICAL + np.asarray(nu) * S3_GAP


def nu_from_s3(s3):
    return (np.asarray(s3) - S3_CLASSICAL) / S3_GAP

# -----------------------------------------------------------------------------
# Momentos dimension-bounded, Bob-only, subnormalizados
# -----------------------------------------------------------------------------
Mono = Tuple[Tuple[int, ...], Tuple[int, ...]]
Word = Tuple[int, ...]
MomentKey = Tuple[Mono, int, int, Word]
ID_WORD: Word = tuple()


def _zeros(n):
    return tuple(0 for _ in range(n))


def mono_one(n):
    z = _zeros(n)
    return z, z


def mono_alpha(n, k):
    h = [0] * n
    h[k] = 1
    return tuple(h), _zeros(n)


def mono_conj(m):
    return m[1], m[0]


def mono_mul(a, b):
    return (
        tuple(x + y for x, y in zip(a[0], b[0])),
        tuple(x + y for x, y in zip(a[1], b[1])),
    )


def reduce_word(seq):
    stack: List[int] = []
    for letter in seq:
        if stack and stack[-1] == letter:
            stack.pop()
        else:
            stack.append(letter)
    return tuple(stack)


def word_mul(a, b):
    return reduce_word(a + b)


def word_adj(w):
    return reduce_word(tuple(reversed(w)))


def B_word(y):
    return (int(y),)


def word_len(w):
    return len(w)


def normalize_level(level):
    aliases = {"L11": "L11+B", "L11+BE": "L11+B", "L11+BR": "L11+B"}
    return aliases.get(level, level)


def gen_words(level):
    level = normalize_level(level)
    if level == "L11+B":
        words = {ID_WORD, B_word(0), B_word(1)}
    elif level == "L12+B":
        words = {ID_WORD}
        for length in range(3):
            for seq in product(range(N_B), repeat=length):
                words.add(reduce_word(seq))
    else:
        raise ValueError("PAMC_LEVEL deve ser L11+B ou L12+B.")
    return sorted(words, key=lambda w: (word_len(w), w))


def gen_monos(n):
    monos = [mono_one(n)]
    for k in range(n):
        a = mono_alpha(n, k)
        monos.extend([a, mono_conj(a)])
    return monos


def _star(key):
    mono, i, j, word = key
    return mono_conj(mono), j, i, word_adj(word)


def _canon(mono, i, j, word):
    key = mono, i, j, reduce_word(word)
    star = _star(key)
    if key == star:
        return key, True, True
    canon = min(key, star)
    return canon, key == canon, False


class PAMSubnormalizedBobBranch:
    """Um ramo subnormalizado associado a um palpite classico fixo."""
    def __init__(self, level="L11+B", gauge=True, name="branch"):
        self.level = normalize_level(level)
        self.n_alpha = N_X * D
        self._zero_idx = set(range(1, D)) if gauge else set()
        self.monos = [m for m in gen_monos(self.n_alpha) if not self._mono_has_zero(m)]
        self.words = gen_words(self.level)
        self.rows = [(mono, i, word) for mono in self.monos for i in range(D) for word in self.words]
        self.n = len(self.rows)

        entries, keys, self_adjoint = [], set(), set()
        for a, (mu, i, u) in enumerate(self.rows):
            for b, (nu, j, v) in enumerate(self.rows):
                scalar = mono_mul(mono_conj(mu), nu)
                word = word_mul(word_adj(u), v)
                canon, direct, is_self = _canon(scalar, i, j, word)
                entries.append((a, b, canon, direct))
                keys.add(canon)
                if is_self:
                    self_adjoint.add(canon)
        self.keys = sorted(keys)
        self.key_index = {k: idx for idx, k in enumerate(self.keys)}
        self.moments = cp.Variable(len(self.keys), complex=True, name=f"{name}_moments")
        self.constraints = []
        self_indices = [self.key_index[k] for k in self_adjoint]
        if self_indices:
            self.constraints.append(cp.imag(self.moments[np.array(self_indices, dtype=int)]) == 0)

        dr, dc, dd, cr, cc, cd = [], [], [], [], [], []
        for a, b, key, direct in entries:
            flat = a * self.n + b
            idx = self.key_index[key]
            if direct:
                dr.append(flat); dc.append(idx); dd.append(1.0)
            else:
                cr.append(flat); cc.append(idx); cd.append(1.0)
        A = sp.csr_matrix((dd, (dr, dc)), shape=(self.n*self.n, len(self.keys)))
        C = sp.csr_matrix((cd, (cr, cc)), shape=(self.n*self.n, len(self.keys)))
        vec = cp.Constant(A) @ self.moments + cp.Constant(C) @ cp.conj(self.moments)
        self.M = cp.reshape(vec, (self.n, self.n), order="C")
        self.constraints.append(self.M >> 0)

        one = mono_one(self.n_alpha)
        self.weight = cp.real(self.m(one, 0, 0, ID_WORD))
        self._add_frame_constraints()
        self._add_preparation_constraints()
        self._add_probability_constraints()

    def _mono_has_zero(self, mono):
        return any(mono[0][k] or mono[1][k] for k in self._zero_idx)

    def m(self, mono, i, j, word):
        if self._mono_has_zero(mono):
            return cp.Constant(0.0)
        key = mono, i, j, reduce_word(word)
        star = _star(key)
        canon = key if key == star else min(key, star)
        if canon not in self.key_index:
            raise KeyError(f"Momento ausente: {key}")
        val = self.moments[self.key_index[canon]]
        return val if key == canon else cp.conj(val)

    def _monomial_products(self):
        return list(dict.fromkeys(mono_mul(mono_conj(a), b) for a in self.monos for b in self.monos))

    def _visible_words(self):
        return sorted({word_mul(word_adj(u), v) for u in self.words for v in self.words}, key=lambda w:(len(w),w))

    def _add_frame_constraints(self):
        one = mono_one(self.n_alpha)
        for i in range(D):
            for j in range(D):
                self.constraints.append(self.m(one, i, j, ID_WORD) == (self.weight if i == j else 0.0))
        self.constraints += [self.weight >= 0.0, self.weight <= 1.0]
        for mm in self._monomial_products():
            for i in range(D):
                for j in range(D):
                    try:
                        moment = self.m(mm, i, j, ID_WORD)
                    except KeyError:
                        continue
                    if i != j:
                        self.constraints.append(moment == 0.0)
            for i in range(1, D):
                try:
                    self.constraints.append(self.m(mm, i, i, ID_WORD) == self.m(mm, 0, 0, ID_WORD))
                except KeyError:
                    pass

    def _add_preparation_constraints(self):
        one = mono_one(self.n_alpha)
        for x in range(N_X):
            for i in range(D):
                for j in range(D):
                    for word in self._visible_words():
                        lhs = 0
                        ok = True
                        for k in range(D):
                            a = mono_alpha(self.n_alpha, x*D+k)
                            abs_sq = mono_mul(mono_conj(a), a)
                            try:
                                lhs += self.m(abs_sq, i, j, word)
                            except KeyError:
                                ok = False; break
                        if not ok:
                            continue
                        try:
                            rhs = self.m(one, i, j, word)
                        except KeyError:
                            continue
                        self.constraints.append(lhs == rhs)

    def _corr(self, x, word):
        expr = 0
        for i in range(D):
            for j in range(D):
                ai = mono_alpha(self.n_alpha, x*D+i)
                aj = mono_alpha(self.n_alpha, x*D+j)
                scalar = mono_mul(mono_conj(ai), aj)
                expr += self.m(scalar, i, j, word)
        return cp.real(expr)

    def corrB(self, x, y):
        return self._corr(x, B_word(y))

    def probB(self, b, x, y):
        sign = 1.0 if b == 0 else -1.0
        return 0.5 * (self.weight + sign*self.corrB(x,y))

    def _add_probability_constraints(self):
        for x in range(N_X):
            for y in range(N_B):
                probs = [self.probB(b,x,y) for b in (0,1)]
                self.constraints.append(cp.hstack(probs) >= 0.0)
                self.constraints.append(sum(probs) == self.weight)

    def s3_expr(self):
        return self.corrB(0,0)+self.corrB(0,1)+self.corrB(1,0)-self.corrB(1,1)-self.corrB(2,0)


def solver_kwargs(solver, verbose=False, solve_form=None, tol=None):
    """Parametros do solver.

    Para MOSEK, solve_form=AUTO omite MSK_IPAR_INTPNT_SOLVE_FORM e deixa o
    solver escolher automaticamente a formulacao primal/dual. Isso e mais
    robusto para os dois blocos PSD subnormalizados do modelo classico.
    """
    solver = solver.upper()
    tol = max(float(MOSEK_TOL if tol is None else tol), 1e-10)
    if solver == "MOSEK":
        params = {
            "MSK_DPAR_INTPNT_CO_TOL_PFEAS": tol,
            "MSK_DPAR_INTPNT_CO_TOL_DFEAS": tol,
            "MSK_DPAR_INTPNT_CO_TOL_REL_GAP": tol,
            "MSK_IPAR_NUM_THREADS": MOSEK_THREADS,
        }
        form = (MOSEK_SOLVE_FORM if solve_form is None else solve_form).upper()
        if form not in {"", "AUTO", "FREE", "MSK_SOLVE_FREE"}:
            params["MSK_IPAR_INTPNT_SOLVE_FORM"] = form
        if MOSEK_MAX_TIME > 0:
            params["MSK_DPAR_OPTIMIZER_MAX_TIME"] = MOSEK_MAX_TIME
        return {"solver": cp.MOSEK, "verbose": verbose, "mosek_params": params}
    if solver == "SCS":
        return {"solver": cp.SCS, "verbose": verbose, "eps":1e-5, "max_iters":300000, "use_indirect":True}
    if solver == "CLARABEL":
        return {"solver": cp.CLARABEL, "verbose": verbose}
    raise ValueError(f"Solver nao configurado: {solver}")


class ClassicalSideInfoS3SDP:
    def __init__(self, level="L11+B", gauge=True):
        self.level = normalize_level(level)
        self.inputs = FIXED_INPUTS.copy()
        self.branches = [
            PAMSubnormalizedBobBranch(self.level, gauge, "guess0"),
            PAMSubnormalizedBobBranch(self.level, gauge, "guess1"),
        ]
        self.s3_parts = [r.s3_expr() for r in self.branches]
        self.s3_total = sum(self.s3_parts)
        self.nu_total = (self.s3_total - S3_CLASSICAL) / S3_GAP
        self.guessing_values = cp.hstack([
            self.branches[0].probB(0,x,y) + self.branches[1].probB(1,x,y)
            for x,y in self.inputs
        ])
        self.selector = cp.Parameter(len(self.inputs), nonneg=True)
        self.lambda_support = cp.Parameter(nonneg=True)
        self.nu_lower = cp.Parameter()
        selected = cp.sum(cp.multiply(self.selector, self.guessing_values))
        constraints = []
        for r in self.branches:
            constraints += list(r.constraints)
        constraints += [
            self.branches[0].weight + self.branches[1].weight == 1.0,
            self.nu_total <= 1.0,
            self.nu_total >= self.nu_lower,
        ]
        # Cada ramo subnormalizado obedece ao bound qubit homogeneizado.
        for r, s3 in zip(self.branches, self.s3_parts):
            constraints += [
                s3 <= S3_QUBIT * r.weight,
                s3 >= S3_ALGEBRAIC_MIN * r.weight,
            ]
        self.objective_expr = selected + self.lambda_support*(self.nu_total-SUPPORT_CENTER)
        self.problem = cp.Problem(cp.Maximize(self.objective_expr), constraints)
        if not self.problem.is_dcp() or not self.problem.is_dpp():
            raise RuntimeError("Problema classico nao e DCP/DPP.")

    def _set_input(self,x,y):
        idx = self.inputs.index((int(x),int(y)))
        vec = np.zeros(len(self.inputs)); vec[idx]=1.0
        self.selector.value=vec
        return idx

    def _solve(self, label="solve"):
        """Resolve com retries numericamente robustos.

        O erro observado vinha do solve direto no endpoint com a forma dual
        forcada e tolerancia 1e-9. Para o modelo classico de dois blocos, MOSEK
        pode preferir a forma primal. Tentamos AUTO primeiro, depois primal e
        dual, sem transformar uma falha de ancora em perda de todo o scan.
        """
        if SOLVER != "MOSEK":
            return self.problem.solve(
                **solver_kwargs(SOLVER, VERBOSE_SOLVER),
                warm_start=True,
                ignore_dpp=False,
            )

        requested = MOSEK_SOLVE_FORM
        forms = []
        for f in [requested, "AUTO", "MSK_SOLVE_PRIMAL", "MSK_SOLVE_DUAL"]:
            if f.upper() not in [x.upper() for x in forms]:
                forms.append(f)
        tolerances = [max(MOSEK_TOL, 1e-8), max(MOSEK_TOL, 1e-7)]
        errors = []
        for tol in tolerances:
            for form in forms:
                for warm, ignore in [(True, False), (False, True)]:
                    try:
                        value = self.problem.solve(
                            **solver_kwargs("MOSEK", VERBOSE_SOLVER, solve_form=form, tol=tol),
                            warm_start=warm,
                            ignore_dpp=ignore,
                        )
                        if self.problem.status in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE} and value is not None and np.isfinite(np.real(value)):
                            return value
                        errors.append(f"form={form}, tol={tol:g}, status={self.problem.status}")
                    except Exception as exc:
                        errors.append(f"form={form}, tol={tol:g}: {type(exc).__name__}: {exc}")
        tail = "\n".join(errors[-6:])
        raise RuntimeError(f"MOSEK falhou em {label} apos retries:\n{tail}")

    def solve_support(self,x,y,lam):
        idx=self._set_input(x,y); self.lambda_support.value=float(lam); self.nu_lower.value=NU_GLOBAL_MIN
        t=time.time(); val=self._solve(f"suporte input={(x,y)} lambda={lam}"); elapsed=time.time()-t
        if self.problem.status not in {cp.OPTIMAL,cp.OPTIMAL_INACCURATE}:
            raise RuntimeError(f"Suporte classico falhou: input={(x,y)}, lambda={lam}, status={self.problem.status}")
        q=float(np.real(val)); pad=2e-6+2e-9*max(1,abs(q))
        return {
            "solve_type":"support_centered_classical","input_x":x,"input_y":y,"input_label":f"({x},{y})",
            "lambda":float(lam),"support_centered_upper":q+pad,"support_centered_raw":q,
            "guessing_at_optimizer":float(np.real(self.guessing_values.value[idx])),
            "s3_at_optimizer":float(np.real(self.s3_total.value)),"nu_at_optimizer":float(np.real(self.nu_total.value)),
            "weight_guess0":float(np.real(self.branches[0].weight.value)),"weight_guess1":float(np.real(self.branches[1].weight.value)),
            "status":self.problem.status,"time_s":elapsed,"matrix_size_each":self.branches[0].n,
            "n_moments_each":len(self.branches[0].keys),"n_constraints":len(self.problem.constraints),"level":self.level,
        }

    def solve_direct(self,x,y,target):
        idx=self._set_input(x,y); self.lambda_support.value=0.0
        # Relaxacoes crescentes ampliam o conjunto factivel e preservam o
        # carater de upper bound para o target original.
        relaxations=[]
        for r in [WITNESS_RELAXATION, 1e-6, 3e-6, 1e-5, 3e-5, 1e-4]:
            if r not in relaxations: relaxations.append(r)
        last_error=None
        for relaxation in relaxations:
            self.nu_lower.value=float(target)-relaxation
            t=time.time()
            try:
                val=self._solve(f"ancora input={(x,y)} nu={target} relax={relaxation}")
            except Exception as exc:
                last_error=exc
                continue
            elapsed=time.time()-t
            if self.problem.status not in {cp.OPTIMAL,cp.OPTIMAL_INACCURATE}:
                last_error=RuntimeError(f"status={self.problem.status}")
                continue
            g=float(np.real(val)); upper=min(1.0,g+5e-6+2e-9*max(1,abs(g)))
            return {
                "solve_type":"direct_anchor_classical","input_x":x,"input_y":y,"input_label":f"({x},{y})",
                "nu_target":float(target),"nu_constraint_used":float(self.nu_lower.value),
                "guessing_upper":upper,"guessing_raw":g,
                "guessing_at_optimizer":float(np.real(self.guessing_values.value[idx])),
                "s3_at_optimizer":float(np.real(self.s3_total.value)),"nu_at_optimizer":float(np.real(self.nu_total.value)),
                "weight_guess0":float(np.real(self.branches[0].weight.value)),"weight_guess1":float(np.real(self.branches[1].weight.value)),
                "status":self.problem.status,"time_s":elapsed,"matrix_size_each":self.branches[0].n,
                "n_moments_each":len(self.branches[0].keys),"n_constraints":len(self.problem.constraints),"level":self.level,
            }
        raise RuntimeError(f"Ancora classica falhou para input={(x,y)}, nu={target}: {last_error}")

# -----------------------------------------------------------------------------
# Scan e reconstrucao
# -----------------------------------------------------------------------------
LEVEL=normalize_level(os.getenv("PAMC_LEVEL","L11+B"))
RESUME=os.getenv("PAMC_RESUME","1")=="1"
PLOT_ONLY=os.getenv("PAMC_PLOT_ONLY","0")=="1"
FAST_TEST=os.getenv("PAMC_FAST_TEST","0")=="1"
CURVE_POINTS=int(os.getenv("PAMC_CURVE_POINTS","501"))
LAMBDA_MAX=float(os.getenv("PAMC_LAMBDA_MAX","1e3"))
LAMBDA_COUNT=int(os.getenv("PAMC_LAMBDA_COUNT","25"))


def level_tag(s): return s.replace("+","p")

def path_support(): return OUTPUT_DIR/f"support_classical_S3_{level_tag(LEVEL)}.csv"

def path_direct(): return OUTPUT_DIR/f"direct_classical_S3_{level_tag(LEVEL)}.csv"

def path_curve(): return OUTPUT_DIR/f"S3_classical_full_curve_all_fixed_inputs_{level_tag(LEVEL)}.csv"


def lambda_grid():
    raw=os.getenv("PAMC_LAMBDAS","").strip()
    if raw: vals=np.array([float(v) for v in raw.split(",") if v.strip()])
    elif FAST_TEST: vals=np.array([0,1e-2,1e-1,1,10,100])
    else: vals=np.concatenate([[0],np.logspace(-4,math.log10(LAMBDA_MAX),LAMBDA_COUNT),[1e-3,1e-2,1e-1,1,3,10,30,100,300,1000]])
    return np.unique(np.round(vals[(vals>=0)&(vals<=1000)],14))


def direct_grid():
    if not USE_DIRECT_ANCHORS:
        return np.array([], dtype=float)
    raw=os.getenv("PAMC_DIRECT_NUS","").strip()
    if raw: vals=np.array([float(v) for v in raw.split(",") if v.strip()])
    elif FAST_TEST: vals=np.array([.99,1])
    else: vals=np.array([.95,.98,.99,.995,.998,.999,.9995,.9998,.9999,1])
    return np.unique(np.round(vals,10))

LAMBDAS=lambda_grid(); DIRECT=direct_grid(); NU_GRID=np.linspace(0,1,CURVE_POINTS)


def load_records(path):
    if RESUME and path.exists(): return pd.read_csv(path).to_dict("records")
    return []


def save(records,path,keys): pd.DataFrame(records).sort_values(keys).to_csv(path,index=False)


def endpoint_floor(x,y):
    if (x,y) in {(0,0),(0,1),(1,0),(1,1)}: return .5*(1+1/math.sqrt(2))
    if (x,y)==(2,0): return 1.0
    return .5


def reconstruct(sf,df,x,y):
    sg=sf[(sf.input_x==x)&(sf.input_y==y)].sort_values("lambda").drop_duplicates("lambda",keep="last")
    if sg.empty:
        raise RuntimeError(f"Sem valores de suporte classico para input {(x,y)}.")
    if df is None or df.empty or "nu_target" not in df.columns:
        dg=pd.DataFrame(columns=["nu_target","guessing_upper"])
    else:
        dg=df[(df.input_x==x)&(df.input_y==y)].sort_values("nu_target").drop_duplicates("nu_target",keep="last")
    l=sg["lambda"].to_numpy(float); q=sg["support_centered_upper"].to_numpy(float)
    lines=q[:,None]+l[:,None]*(1-NU_GRID[None,:]); active=np.argmin(lines,axis=0); sb=lines[active,np.arange(len(NU_GRID))]
    db=np.full(len(NU_GRID),np.inf); active_d=np.full(len(NU_GRID),np.nan)
    for i,nu in enumerate(NU_GRID):
        eligible=dg[dg.nu_target<=nu+1e-12]
        if not eligible.empty:
            row=eligible.loc[eligible.guessing_upper.idxmin()]; db[i]=row.guessing_upper; active_d[i]=row.nu_target
    p=np.clip(np.minimum(sb,db),.5,1)
    p[-1]=max(p[-1],endpoint_floor(x,y))
    for i in range(len(p)-2,-1,-1): p[i]=max(p[i],p[i+1])
    h=np.clip(-np.log2(np.maximum(p,1e-300)),0,1)
    return pd.DataFrame({"input_x":x,"input_y":y,"input_label":f"({x},{y})","nu":NU_GRID,"s3":s3_from_nu(NU_GRID),
                         "pguess_classical_upper_raw":p,"hmin_classical_lower_raw":h,
                         "active_lambda":l[active],"active_direct_nu":active_d,"level":LEVEL})


def scan():
    print("\n"+"="*96); print(f"PAM S3 | CLASSICAL SIDE INFORMATION | {LEVEL}"); print("="*96)
    model=ClassicalSideInfoS3SDP(LEVEL,True)
    print("Dois ramos subnormalizados: guess 0 e guess 1")
    print("Ancoras diretas:", USE_DIRECT_ANCHORS, "(suporte centrado e o metodo principal)")
    print("Matriz de cada ramo:",model.branches[0].n,"| momentos:",len(model.branches[0].keys))
    sr=load_records(path_support()); dr=load_records(path_direct())
    for x,y in FIXED_INPUTS:
        solved={(int(r["input_x"]),int(r["input_y"]),round(float(r["lambda"]),14)) for r in sr}
        for lam in LAMBDAS:
            if (x,y,round(float(lam),14)) in solved: continue
            print(f"SUPORTE CLASSICO input=({x},{y}) lambda={lam:g}",flush=True)
            row=model.solve_support(x,y,float(lam)); sr.append(row); save(sr,path_support(),["input_x","input_y","lambda"])
            print(f"  q<={row['support_centered_upper']:.10f} G={row['guessing_at_optimizer']:.10f} nu={row['nu_at_optimizer']:.8f} {row['time_s']:.1f}s")
        solved_d={(int(r["input_x"]),int(r["input_y"]),round(float(r["nu_target"]),10)) for r in dr if "nu_target" in r}
        for target in sorted(DIRECT,reverse=True):
            if (x,y,round(float(target),10)) in solved_d: continue
            print(f"ANCORA CLASSICA input=({x},{y}) nu={target:g}",flush=True)
            try:
                row=model.solve_direct(x,y,float(target))
            except Exception as exc:
                print(f"  AVISO: ancora ignorada apos retries: {exc}",flush=True)
                continue
            dr.append(row); save(dr,path_direct(),["input_x","input_y","nu_target"])
            print(f"  G<={row['guessing_upper']:.10f} nu_at={row['nu_at_optimizer']:.8f} {row['time_s']:.1f}s")
        gc.collect()
    sf=pd.DataFrame(sr).sort_values(["input_x","input_y","lambda"])
    df=(pd.DataFrame(dr).sort_values(["input_x","input_y","nu_target"])
        if dr else pd.DataFrame(columns=["input_x","input_y","nu_target","guessing_upper"]))
    cf=pd.concat([reconstruct(sf,df,x,y) for x,y in FIXED_INPUTS],ignore_index=True); cf.to_csv(path_curve(),index=False)
    return sf,df,cf


def load_all():
    if not path_support().exists(): raise RuntimeError("Falta o checkpoint de suporte classico.")
    sf=pd.read_csv(path_support())
    df=(pd.read_csv(path_direct()) if path_direct().exists()
        else pd.DataFrame(columns=["input_x","input_y","nu_target","guessing_upper"]))
    cf=pd.concat([reconstruct(sf,df,x,y) for x,y in FIXED_INPUTS],ignore_index=True)
    return sf,df,cf


def plot(cf,kind):
    col="hmin_classical_lower_raw" if kind=="Hmin" else "pguess_classical_upper_raw"
    ylabel=r"$H_{\min}(B|\Lambda,x^*,y^*)$ [bits]" if kind=="Hmin" else r"$P_{\rm guess}(B|\Lambda,x^*,y^*)$"
    fig,ax=plt.subplots(figsize=(8.3,5.5))
    for (x,y),g in cf.groupby(["input_x","input_y"]): ax.plot(g.nu,g[col],"--",lw=2,label=f"({x},{y})")
    ax.set(xlim=(0,1.001),ylim=(0,1.02),xlabel=r"Normalized violation $\nu=(S_3-S_3^{\rm C})/(S_3^{\rm Q}-S_3^{\rm C})$",ylabel=ylabel)
    ax.grid(alpha=.24); ax.legend(title="Fixed input",ncol=2,frameon=False)
    top=ax.secondary_xaxis("top",functions=(s3_from_nu,nu_from_s3)); top.set_xlabel(r"Witness value $S_3$")
    fig.tight_layout(); p=OUTPUT_DIR/f"S3_classical_all_inputs_{kind}_{level_tag(LEVEL)}.pdf"; fig.savefig(p); fig.savefig(p.with_suffix('.png'),dpi=300); plt.close(fig)


def main():
    print("CVXPY:","plot-only" if cp is None else cp.__version__,"| solver:",SOLVER,"| installed:",installed)
    if not PLOT_ONLY and SOLVER not in installed: raise RuntimeError(f"Solver {SOLVER} nao encontrado.")
    sf,df,cf=load_all() if PLOT_ONLY else scan(); cf.to_csv(path_curve(),index=False); plot(cf,"Hmin"); plot(cf,"Pguess")
    print("CSV classico:",path_curve()); print("CLASSICAL SIDE INFORMATION CONCLUIDO.")

if __name__=="__main__": main()
