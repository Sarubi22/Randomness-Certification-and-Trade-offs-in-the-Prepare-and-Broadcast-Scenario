#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CC2 — randomness conjunta BC ao longo da distribuição física fixa

A distribuição alvo é construída a partir da Configuration 2 para W_CC^(2)
do apêndice do manuscrito:

    P_v = v P_opt + (1-v) / 4,   0 <= v <= 1.

Para cada visibilidade v e cada input de geração s=(x,y,z), o código resolve
a SDP multirramos contra Eve clássica:

    max  sum_g p_g(g|s)
    s.t. sum_g p_g = P_v,
         p_g pertence ao cone PAB QQ subnormalizado da relaxação.

A igualdade da distribuição completa é imposta de forma equivalente nos 24
correladores independentes (6 de Bob, 6 de Charlie e 12 conjuntos BC), além
de sum_g r_g=1. Cada palpite g=(b,c) possui sua própria matriz de momentos.

Este arquivo reutiliza a álgebra e as rotinas de solver de
``pab_cc2_12_inputs.py``. Mantenha os dois arquivos na mesma pasta.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
import scipy.sparse as sp

import pab_cc2_12_inputs as core

cp = core.cp
PSD = core.PSD

# =============================================================================
# 1. Configuração da rodada
# =============================================================================

MODE_TAG = "fixed_distribution_joint_BC"
OUTPUT_DIR = Path(os.getenv("PAB_OUTPUT_DIR", "resultados_CC2_distribuicao_fixa"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

RESUME = os.getenv("PAB_RESUME", "1") == "1"
SAVE_INPUT_PLOTS = os.getenv("PAB_SAVE_INPUT_PLOTS", "1") == "1"
FIX_TOL = float(os.getenv("PAB_FIXED_DISTRIBUTION_TOL", "1e-8"))
SKIP_HARD_ENDPOINT = os.getenv("PAB_SKIP_HARD_ENDPOINT", "1") == "1"

# Padding numérico do valor ótimo. A relaxação externa dá o sentido correto;
# este padding apenas protege contra erro do solver de primeira ordem.
OBJECTIVE_ABS_PADDING = float(os.getenv("PAB_OBJECTIVE_ABS_PADDING", "2e-7"))
OBJECTIVE_REL_PADDING = float(os.getenv("PAB_OBJECTIVE_REL_PADDING", "1e-9"))
RESIDUAL_MULTIPLIER = float(os.getenv("PAB_RESIDUAL_MULTIPLIER", "10.0"))

W_CLASSICAL = 6.0
W_ANALYTIC = float(8.0 + 2.0 * np.sqrt(2.0))

def parse_visibility_grid() -> np.ndarray:
    """Lê PAB_VISIBILITIES ou usa uma grade conservadora padrão."""
    text = os.getenv("PAB_VISIBILITIES", "").strip()
    if text:
        values = [float(v.strip()) for v in text.split(",") if v.strip()]
    else:
        # Cada ponto exige uma SDP multirramos. A grade padrão é deliberadamente
        # moderada e concentra alguns pontos perto do endpoint.
        vmax = 1.0 - float(os.getenv("PAB_ENDPOINT_GAP", "1e-6"))
        values = list(np.linspace(0.0, vmax, 31))
        values += [0.55, W_CLASSICAL / W_ANALYTIC, 0.975, 0.99, 0.995, 0.999, vmax]
    grid = np.unique(np.asarray(values, dtype=float))
    if np.any(grid < -1e-12) or np.any(grid > 1.0 + 1e-12):
        raise ValueError("As visibilidades devem pertencer ao intervalo [0,1].")
    grid = np.clip(grid, 0.0, 1.0)
    return np.sort(grid)


VISIBILITIES = parse_visibility_grid()


def all_inputs() -> List[Tuple[int, int, int]]:
    return [(x, y, z) for x in range(3) for y in range(2) for z in range(2)]


def parse_input_filter(text: str) -> Optional[Tuple[int, int, int]]:
    text = text.strip()
    if not text:
        return None
    parts = [int(v.strip()) for v in text.replace(";", ",").split(",")]
    if len(parts) != 3:
        raise ValueError("PAB_INPUT deve ter a forma x,y,z.")
    out = tuple(parts)
    if out not in all_inputs():
        raise ValueError(f"Input inválido: {out}")
    return out


INPUT_FILTER = parse_input_filter(os.getenv("PAB_INPUT", ""))


# =============================================================================
# 2. Configuration 2 de W_CC^(2) e distribuição ótima
# =============================================================================

I2 = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
PAULI = (X, Y, Z)


def normalized_vector(v: Sequence[float]) -> np.ndarray:
    out = np.asarray(v, dtype=float)
    norm = float(np.linalg.norm(out))
    if norm <= 0:
        raise ValueError("Vetor de Bloch nulo.")
    return out / norm


def bloch_state(v: Sequence[float]) -> np.ndarray:
    v = normalized_vector(v)
    return 0.5 * (I2 + sum(v[k] * PAULI[k] for k in range(3)))


def bloch_observable(v: Sequence[float]) -> np.ndarray:
    v = normalized_vector(v)
    return sum(v[k] * PAULI[k] for k in range(3))


def closest_isometry(matrix: np.ndarray) -> np.ndarray:
    """Isometria polar mais próxima da matriz arredondada do apêndice."""
    left, _singular, right_h = np.linalg.svd(np.asarray(matrix, dtype=complex), full_matrices=False)
    return left @ right_h


def cc2_configuration() -> dict:
    # Bloch vectors da Configuration 2, Eq. (A3).
    prep_vectors = np.array([
        (+0.346743, -0.937953, -0.003529),
        (-0.002956, +0.002670, -0.999992),
        (-0.243094, +0.661345, +0.709597),
    ], dtype=float)
    bob_vectors = np.array([
        (-0.617353, -0.151021, -0.772054),
        (+0.562743, +0.601009, -0.567546),
    ], dtype=float)
    charlie_vectors = np.array([
        (+0.628887, +0.492636, -0.601507),
        (+0.171344, +0.666810, +0.725263),
    ], dtype=float)

    # Isometria da Eq. (A4), em ordem computacional |00>,|01>,|10>,|11>.
    rounded_u = np.array([
        [0.302656 - 0.638238j,  0.039246 - 0.217752j],
        [0.024188 + 0.014229j, -0.355177 - 0.570226j],
        [-0.009192 + 0.025650j, 0.517734 + 0.428141j],
        [0.651198 + 0.274706j, -0.219738 + 0.009898j],
    ], dtype=complex)

    isometry = closest_isometry(rounded_u)
    states = [bloch_state(v) for v in prep_vectors]
    bob = [bloch_observable(v) for v in bob_vectors]
    charlie = [bloch_observable(v) for v in charlie_vectors]

    return {
        "prep_vectors_raw": prep_vectors,
        "bob_vectors_raw": bob_vectors,
        "charlie_vectors_raw": charlie_vectors,
        "isometry_rounded": rounded_u,
        "isometry": isometry,
        "states": states,
        "bob": bob,
        "charlie": charlie,
    }


def calculate_optimal_distribution() -> dict:
    cfg = cc2_configuration()
    U = cfg["isometry"]
    bob = cfg["bob"]
    charlie = cfg["charlie"]

    eb = np.zeros((3, 2), dtype=float)
    ec = np.zeros((3, 2), dtype=float)
    ebc = np.zeros((3, 2, 2), dtype=float)
    probs = np.zeros((3, 2, 2, 2, 2), dtype=float)  # x,y,z,b,c

    output_states = []
    for x, rho in enumerate(cfg["states"]):
        sigma = U @ rho @ U.conj().T
        sigma = 0.5 * (sigma + sigma.conj().T)
        output_states.append(sigma)
        for y in range(2):
            eb[x, y] = float(np.real(np.trace(sigma @ np.kron(bob[y], I2))))
        for z in range(2):
            ec[x, z] = float(np.real(np.trace(sigma @ np.kron(I2, charlie[z]))))
        for y in range(2):
            for z in range(2):
                ebc[x, y, z] = float(np.real(np.trace(sigma @ np.kron(bob[y], charlie[z]))))
                for b in range(2):
                    for c in range(2):
                        sb = 1.0 if b == 0 else -1.0
                        sc = 1.0 if c == 0 else -1.0
                        probs[x, y, z, b, c] = 0.25 * (
                            1.0 + sb * eb[x, y] + sc * ec[x, z] + sb * sc * ebc[x, y, z]
                        )

    witness = (
        2.0 * ebc[0, 0, 0]
        + 2.0 * ebc[0, 1, 1]
        + 2.0 * ebc[1, 0, 1]
        - 2.0 * ebc[1, 1, 0]
        - ebc[2, 0, 0]
        - ebc[2, 0, 1]
        + ebc[2, 1, 0]
        - ebc[2, 1, 1]
    )

    if np.min(probs) < -1e-9:
        raise RuntimeError(f"Distribuição ótima possui probabilidade negativa: {np.min(probs)}")
    if np.max(np.abs(np.sum(probs, axis=(-2, -1)) - 1.0)) > 1e-9:
        raise RuntimeError("Falha de normalização da distribuição ótima.")

    return {
        **cfg,
        "output_states": output_states,
        "EB": eb,
        "EC": ec,
        "EBC": ebc,
        "P": probs,
        "witness": float(witness),
        "isometry_error_before_polar": float(
            np.linalg.norm(cfg["isometry_rounded"].conj().T @ cfg["isometry_rounded"] - np.eye(2))
        ),
        "isometry_error_after_polar": float(
            np.linalg.norm(cfg["isometry"].conj().T @ cfg["isometry"] - np.eye(2))
        ),
    }


TARGET = calculate_optimal_distribution()
W_OPT = float(TARGET["witness"])
V_CLASSICAL = W_CLASSICAL / W_OPT


def target_probability(v: float) -> np.ndarray:
    return float(v) * TARGET["P"] + (1.0 - float(v)) * 0.25


def save_target_data() -> None:
    rows = []
    for x, y, z, b, c in product(range(3), range(2), range(2), range(2), range(2)):
        rows.append({
            "x": x,
            "y": y,
            "z": z,
            "b": b,
            "c": c,
            "p_opt": TARGET["P"][x, y, z, b, c],
        })
    pd.DataFrame(rows).to_csv(OUTPUT_DIR / "P_opt_CC2_configuration_2.csv", index=False)

    corr_rows = []
    for x in range(3):
        for y in range(2):
            corr_rows.append({"type": "B", "x": x, "y": y, "z": -1, "value": TARGET["EB"][x, y]})
        for z in range(2):
            corr_rows.append({"type": "C", "x": x, "y": -1, "z": z, "value": TARGET["EC"][x, z]})
        for y in range(2):
            for z in range(2):
                corr_rows.append({"type": "BC", "x": x, "y": y, "z": z, "value": TARGET["EBC"][x, y, z]})
    pd.DataFrame(corr_rows).to_csv(OUTPUT_DIR / "correlators_opt_CC2_configuration_2.csv", index=False)

    metadata = {
        "distribution": "P_v = v P_opt + (1-v)/4",
        "witness_opt_from_configuration": W_OPT,
        "witness_analytic": W_ANALYTIC,
        "absolute_witness_difference": abs(W_OPT - W_ANALYTIC),
        "classical_bound": W_CLASSICAL,
        "critical_visibility": V_CLASSICAL,
        "isometry_error_before_polar": TARGET["isometry_error_before_polar"],
        "isometry_error_after_polar": TARGET["isometry_error_after_polar"],
        "level": core.LEVEL,
        "q_scalar": core.Q_SCALAR,
        "fixed_distribution_tolerance": FIX_TOL,
        "visibilities": VISIBILITIES.tolist(),
    }
    with open(OUTPUT_DIR / "metadata_target.json", "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, ensure_ascii=False, indent=2)


# =============================================================================
# 3. Ramos subnormalizados da hierarquia de momentos
# =============================================================================


def build_moment_matrix_named(rows, idx, name: str):
    n = len(rows)
    data: List[complex] = []
    row_ind: List[int] = []
    col_ind: List[int] = []

    for a, (i, mu, u) in enumerate(rows):
        for b, (j, nu, vv) in enumerate(rows):
            scalar = core.mul_scalar(core.adj_scalar(mu), nu)
            if scalar is None:
                continue
            word = core.mul_word(core.adj_word(u), vv)
            h = idx.handle(scalar, i, j, word)
            if h is None:
                continue
            re_pos, im_pos, is_real, conjugated = h
            flat = a * n + b
            row_ind.append(flat)
            col_ind.append(re_pos)
            data.append(1.0 + 0.0j)
            if not is_real:
                row_ind.append(flat)
                col_ind.append(im_pos)
                data.append(-1.0j if conjugated else 1.0j)

    matrix_map = sp.coo_matrix(
        (np.asarray(data, dtype=complex), (row_ind, col_ind)),
        shape=(n * n, len(idx.pos_to_key)),
    ).tocsr()
    idx.frozen = True

    yvar = cp.Variable(len(idx.pos_to_key), name=f"moments_{name}")
    m_vec = matrix_map @ yvar
    moment = cp.reshape(m_vec, (n, n), order="C")
    moment = 0.5 * (moment + moment.H)
    return moment, yvar


def add_subnormalized_frame_constraints(constraints, idx, yvar, weight) -> None:
    one = core.zero_scalar()
    for i in range(core.D):
        for j in range(core.D):
            rhs = weight if i == j else 0.0
            constraints.append(idx.expr(yvar, one, i, j, core.ID_WORD) == rhs)


def sub_probability(branch, b: int, c: int, x: int, y: int, z: int):
    sb = 1.0 if b == 0 else -1.0
    sc = 1.0 if c == 0 else -1.0
    return 0.25 * (
        branch.weight
        + sb * branch.EB(x, y)
        + sc * branch.EC(x, z)
        + sb * sc * branch.EBC(x, y, z)
    )


class SubnormalizedBranch:
    def __init__(self, guess: Tuple[int, int], branch_index: int):
        if cp is None:
            raise RuntimeError("CVXPY não foi importado.")
        self.guess = tuple(int(v) for v in guess)
        self.branch_index = int(branch_index)
        self.label = f"g{self.guess[0]}{self.guess[1]}"

        A_q = core.generate_A(core.Q_SCALAR)
        A_qminus = core.generate_A(core.Q_SCALAR - 1)
        words = core.generate_S(core.LEVEL)

        self.idx = core.MomentIndexer()
        self.rows = core.build_rows(A_q, words)
        self.M, self.yvar = build_moment_matrix_named(self.rows, self.idx, self.label)
        self.weight = cp.Variable(nonneg=True, name=f"r_{self.label}")

        self.constraints = [PSD(self.M), self.weight >= 0.0]
        add_subnormalized_frame_constraints(self.constraints, self.idx, self.yvar, self.weight)
        core.add_preparation_constraints(self.constraints, self.idx, self.yvar, A_qminus, words)
        core.add_weighted_frame_constraints(self.constraints, self.idx, self.yvar)

        if core.ENFORCE_PROBABILITY_POSITIVITY:
            for x, y, z in product(range(3), range(2), range(2)):
                probabilities = [
                    sub_probability(self, b, c, x, y, z)
                    for b, c in product(range(2), range(2))
                ]
                self.constraints.append(cp.hstack(probabilities) >= 0.0)

    def EB(self, x: int, y: int):
        return core.E_B(self.idx, self.yvar, x, y)

    def EC(self, x: int, z: int):
        return core.E_C(self.idx, self.yvar, x, z)

    def EBC(self, x: int, y: int, z: int):
        return core.E_BC(self.idx, self.yvar, x, y, z)

    def probability(self, b: int, c: int, x: int, y: int, z: int):
        return sub_probability(self, b, c, x, y, z)


# =============================================================================
# 4. SDP multirramos com distribuição completa fixa
# =============================================================================


def add_fixed_constraint(constraints: list, expression, target) -> None:
    if FIX_TOL <= 0.0:
        constraints.append(expression == target)
    else:
        constraints.append(expression <= target + FIX_TOL)
        constraints.append(expression >= target - FIX_TOL)


class FixedDistributionTemplate:
    def __init__(self, generation_input: Tuple[int, int, int]):
        if cp is None:
            raise RuntimeError("CVXPY não foi importado neste modo.")
        self.generation_input = tuple(int(v) for v in generation_input)
        self.visibility = cp.Parameter(nonneg=True, value=0.0, name="visibility")
        guesses = [(0, 0), (0, 1), (1, 0), (1, 1)]
        self.branches = [SubnormalizedBranch(g, k) for k, g in enumerate(guesses)]

        constraints = []
        for branch in self.branches:
            constraints.extend(branch.constraints)

        constraints.append(cp.sum(cp.hstack([branch.weight for branch in self.branches])) == 1.0)

        # Fixar a distribuição inteira é equivalente a fixar estes 24
        # correladores mais a normalização total.
        for x in range(3):
            for y in range(2):
                total = cp.sum(cp.hstack([branch.EB(x, y) for branch in self.branches]))
                add_fixed_constraint(constraints, total, self.visibility * TARGET["EB"][x, y])
            for z in range(2):
                total = cp.sum(cp.hstack([branch.EC(x, z) for branch in self.branches]))
                add_fixed_constraint(constraints, total, self.visibility * TARGET["EC"][x, z])
            for y in range(2):
                for z in range(2):
                    total = cp.sum(cp.hstack([branch.EBC(x, y, z) for branch in self.branches]))
                    add_fixed_constraint(constraints, total, self.visibility * TARGET["EBC"][x, y, z])

        xg, yg, zg = self.generation_input
        objective_terms = []
        for branch in self.branches:
            b, c = branch.guess
            objective_terms.append(branch.probability(b, c, xg, yg, zg))
        self.objective_expression = cp.real(cp.sum(cp.hstack(objective_terms)))
        self.problem = cp.Problem(cp.Maximize(self.objective_expression), constraints)
        if not self.problem.is_dcp():
            raise RuntimeError("A SDP de distribuição fixa não é DCP.")

        self.matrix_size = len(self.branches[0].rows)
        self.real_variables = sum(len(branch.idx.pos_to_key) for branch in self.branches) + len(self.branches)

    def solve(self, visibility: float) -> dict:
        self.visibility.value = float(visibility)
        start = time.time()
        value, solver_used = core.solve_cvxpy_problem(self.problem)
        elapsed = time.time() - start
        status = str(self.problem.status)

        base = {
            "x": self.generation_input[0],
            "y": self.generation_input[1],
            "z": self.generation_input[2],
            "visibility": float(visibility),
            "witness": float(visibility) * W_OPT,
            "status": status,
            "solver_used": solver_used,
            "time_s": elapsed,
            "level": core.LEVEL,
            "q_scalar": core.Q_SCALAR,
            "matrix_size_each_branch": self.matrix_size,
            "n_branches": 4,
            "real_variables_total": self.real_variables,
            "n_constraints": len(self.problem.constraints),
            "fixed_tolerance": FIX_TOL,
            "peak_rss_gb": core.peak_rss_gb(),
        }

        if status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE} or value is None:
            return {
                **base,
                "p_guess_raw": np.nan,
                "p_guess_upper": np.nan,
                "hmin_sdp": np.nan,
                "hmin_plot": np.nan,
            }

        raw = float(np.real(value))
        diag = core.scs_diagnostics(self.problem.solver_stats) if solver_used == "SCS" else {
            "res_pri": np.nan,
            "res_dual": np.nan,
            "gap": np.nan,
            "pobj": np.nan,
            "dobj": np.nan,
            "iter": np.nan,
        }

        dual_upper = np.nan
        if solver_used == "SCS" and np.isfinite(diag.get("dobj", np.nan)):
            dual_upper = -float(diag["dobj"])
        candidate = raw if not np.isfinite(dual_upper) else max(raw, dual_upper)
        residual_scale = max(
            abs(float(diag.get("res_pri", 0.0))) if np.isfinite(diag.get("res_pri", np.nan)) else 0.0,
            abs(float(diag.get("res_dual", 0.0))) if np.isfinite(diag.get("res_dual", np.nan)) else 0.0,
            abs(float(diag.get("gap", 0.0))) if np.isfinite(diag.get("gap", np.nan)) else 0.0,
        )
        margin = (
            OBJECTIVE_ABS_PADDING
            + OBJECTIVE_REL_PADDING * max(1.0, abs(candidate))
            + RESIDUAL_MULTIPLIER * residual_scale
        )
        upper = min(1.0, max(0.25, candidate + margin))
        hmin_sdp = max(0.0, -math.log2(upper))
        # Coluna mantida por compatibilidade, mas sempre igual ao resultado SDP.
        hmin_plot = hmin_sdp

        branch_weights = {
            f"weight_{branch.label}": float(branch.weight.value) if branch.weight.value is not None else np.nan
            for branch in self.branches
        }

        return {
            **base,
            "p_guess_raw": raw,
            "p_guess_dual_upper": dual_upper,
            "objective_margin": margin,
            "p_guess_upper": upper,
            "hmin_sdp": hmin_sdp,
            "hmin_plot": hmin_plot,
            "analytic_endpoint_inserted": False,
            **branch_weights,
            **diag,
        }




def special_point_result(inp: Tuple[int, int, int], visibility: float, kind: str) -> dict:
    """Resultados exatos/omitidos que evitam SDPs degeneradas na fronteira."""
    x, y, z = inp
    base = {
        "x": x, "y": y, "z": z,
        "visibility": float(visibility),
        "witness": float(visibility) * W_OPT,
        "time_s": 0.0,
        "level": core.LEVEL,
        "q_scalar": core.Q_SCALAR,
        "matrix_size_each_branch": np.nan,
        "n_branches": 4,
        "real_variables_total": np.nan,
        "n_constraints": np.nan,
        "fixed_tolerance": FIX_TOL,
        "peak_rss_gb": core.peak_rss_gb(),
        "p_guess_dual_upper": np.nan,
        "objective_margin": 0.0,
        "res_pri": np.nan, "res_dual": np.nan, "gap": np.nan,
        "pobj": np.nan, "dobj": np.nan, "iter": np.nan,
        "weight_00": np.nan, "weight_01": np.nan,
        "weight_10": np.nan, "weight_11": np.nan,
    }
    if kind == "white_noise":
        return {
            **base,
            "status": "analytic_white_noise",
            "solver_used": "ANALYTIC",
            "p_guess_raw": 1.0,
            "p_guess_upper": 1.0,
            "hmin_sdp": 0.0,
            "hmin_plot": 0.0,
            "analytic_endpoint_inserted": False,
        }
    if kind == "skipped_hard_endpoint":
        return {
            **base,
            "status": "skipped_hard_endpoint",
            "solver_used": "SKIPPED",
            "p_guess_raw": np.nan,
            "p_guess_upper": np.nan,
            "hmin_sdp": np.nan,
            "hmin_plot": np.nan,
            "analytic_endpoint_inserted": False,
        }
    raise ValueError(kind)


def solver_error_result(inp: Tuple[int, int, int], visibility: float, exc: Exception) -> dict:
    x, y, z = inp
    return {
        "x": x, "y": y, "z": z,
        "visibility": float(visibility),
        "witness": float(visibility) * W_OPT,
        "status": "solver_error",
        "solver_used": "ERROR",
        "solver_error": str(exc),
        "time_s": 0.0,
        "level": core.LEVEL,
        "q_scalar": core.Q_SCALAR,
        "matrix_size_each_branch": np.nan,
        "n_branches": 4,
        "real_variables_total": np.nan,
        "n_constraints": np.nan,
        "fixed_tolerance": FIX_TOL,
        "peak_rss_gb": core.peak_rss_gb(),
        "p_guess_raw": np.nan,
        "p_guess_dual_upper": np.nan,
        "objective_margin": np.nan,
        "p_guess_upper": np.nan,
        "hmin_sdp": np.nan,
        "hmin_plot": np.nan,
        "analytic_endpoint_inserted": False,
    }

# =============================================================================
# 5. Checkpoints, execução e gráficos
# =============================================================================


def level_tag() -> str:
    return core.LEVEL.replace("+", "p") + f"_q{core.Q_SCALAR}"


def input_tag(inp: Tuple[int, int, int]) -> str:
    return "_".join(str(v) for v in inp)


def curve_path(inp: Tuple[int, int, int]) -> Path:
    return OUTPUT_DIR / f"curve_fixed_distribution_input_{input_tag(inp)}_{level_tag()}.csv"


def safe_save(frame: pd.DataFrame, path: Path) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp, index=False)
    temp.replace(path)


def completed_visibility_set(path: Path) -> set:
    if not RESUME or not path.exists():
        return set()
    try:
        frame = pd.read_csv(path)
        return {round(float(v), 12) for v in frame["visibility"].dropna().tolist()}
    except Exception:
        return set()


def run_input(inp: Tuple[int, int, int]) -> None:
    path = curve_path(inp)
    old = pd.read_csv(path) if RESUME and path.exists() else pd.DataFrame()
    done = completed_visibility_set(path)
    missing = [v for v in VISIBILITIES if round(float(v), 12) not in done]

    print("=" * 88, flush=True)
    print(f"INPUT s={inp} | pontos totais={len(VISIBILITIES)} | faltantes={len(missing)}", flush=True)
    print("=" * 88, flush=True)

    if not missing:
        return

    template = FixedDistributionTemplate(inp)
    records = [] if old.empty else old.to_dict("records")

    for count, visibility in enumerate(missing, start=1):
        print(f"[{count:03d}/{len(missing):03d}] s={inp}  v={visibility:.12g}", flush=True)
        v = float(visibility)
        if abs(v) <= 5e-13:
            result = special_point_result(inp, v, "white_noise")
        elif SKIP_HARD_ENDPOINT and abs(v - 1.0) <= 5e-13:
            # O endpoint exato é omitido para todas as órbitas.
            result = special_point_result(inp, v, "skipped_hard_endpoint")
        else:
            try:
                result = template.solve(v)
            except KeyboardInterrupt:
                raise
            except Exception as exc:
                print(f"  AVISO: ponto falhou e sera pulado: {exc}", flush=True)
                result = solver_error_result(inp, v, exc)
        records.append(result)
        frame = pd.DataFrame(records).sort_values("visibility").drop_duplicates("visibility", keep="last")
        safe_save(frame, path)
        print(
            f"  status={result['status']} solver={result['solver_used']} "
            f"G_up={result.get('p_guess_upper', np.nan):.10g} "
            f"Hmin={result.get('hmin_plot', np.nan):.10g} "
            f"tempo={result['time_s']:.1f}s RAM={result['peak_rss_gb']:.2f}GB",
            flush=True,
        )


def load_all_curves() -> pd.DataFrame:
    frames = []
    for inp in all_inputs():
        path = curve_path(inp)
        if path.exists():
            frame = pd.read_csv(path)
            frame["input"] = f"({inp[0]},{inp[1]},{inp[2]})"
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)




def _comparison_style_legend():
    return [
        Line2D([0], [0], color="black", linestyle="-", linewidth=1.6, label="Witness only"),
        Line2D([0], [0], color="black", linestyle="--", linewidth=1.6, label="Fixed distribution"),
    ]


def _candidate_witness_csv_paths() -> List[Path]:
    env = os.getenv("PAB_WITNESS_CURVES_CSV", "").strip()
    candidates: List[Path] = []
    if env:
        candidates.append(Path(env))

    base = OUTPUT_DIR.resolve().parent
    level = level_tag()
    filename = f"all_curves_joint_BC_{level}.csv.gz"
    direct = [
        base / "PAB_CC2_12_INPUTS_FINAL" / "resultados_COMPLETO_CC2_12_inputs" / filename,
        base / "PAB_CC2_12_INPUTS_FINAL" / "resultados_TRIAGEM_CC2_12_inputs" / filename,
        base.parent / "PAB_CC2_12_INPUTS_FINAL" / "resultados_COMPLETO_CC2_12_inputs" / filename,
        base.parent / "PAB_CC2_12_INPUTS_FINAL" / "resultados_TRIAGEM_CC2_12_inputs" / filename,
        OUTPUT_DIR / filename,
        OUTPUT_DIR.parent / filename,
    ]
    candidates.extend(direct)

    seen = set()
    uniq = []
    for p in candidates:
        key = str(p).lower()
        if key not in seen:
            uniq.append(p)
            seen.add(key)

    for root in [base, base.parent]:
        try:
            if root.exists():
                for found in root.rglob(filename):
                    key = str(found).lower()
                    if key not in seen:
                        uniq.append(found)
                        seen.add(key)
        except Exception:
            pass
    return uniq


def load_witness_curves() -> pd.DataFrame:
    for path in _candidate_witness_csv_paths():
        try:
            if not path.exists():
                continue
            frame = pd.read_csv(path)
            if not {"w_lower", "h_min_lower_monotone"}.issubset(frame.columns):
                continue
            if {"x_star", "y_star", "z_star"}.issubset(frame.columns):
                frame = frame.rename(columns={"x_star": "x", "y_star": "y", "z_star": "z"})
            elif "input_tag" in frame.columns:
                xyz = frame["input_tag"].astype(str).str.split("_", expand=True)
                if xyz.shape[1] != 3:
                    continue
                frame["x"] = xyz[0].astype(int)
                frame["y"] = xyz[1].astype(int)
                frame["z"] = xyz[2].astype(int)
            else:
                continue
            frame = frame.copy()
            frame["visibility"] = frame["w_lower"].astype(float) / W_OPT
            frame["hmin_witness"] = frame["h_min_lower_monotone"].astype(float)
            frame["witness_csv_source"] = str(path)
            return frame
        except Exception:
            continue
    return pd.DataFrame()


def plot_input_comparison(inp: Tuple[int, int, int], dist_frame: pd.DataFrame, wit_frame: pd.DataFrame) -> None:
    dist_frame = dist_frame.sort_values("visibility")
    wit_sub = wit_frame[(wit_frame["x"] == inp[0]) & (wit_frame["y"] == inp[1]) & (wit_frame["z"] == inp[2])].copy()
    if wit_sub.empty:
        return
    wit_sub = wit_sub.sort_values("visibility")

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.plot(wit_sub["visibility"], wit_sub["hmin_witness"], linewidth=1.7, linestyle="-", label="Witness only")
    ax.plot(dist_frame["visibility"], dist_frame["hmin_plot"], linewidth=1.7, linestyle="--", marker="o", markersize=2.8, label="Fixed distribution")
    ax.axvline(V_CLASSICAL, linestyle=":", linewidth=1.0, label=rf"$v_{{CC}}={V_CLASSICAL:.4f}$")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 2.04)
    ax.set_xlabel(r"Channel visibility $v$")
    ax.set_ylabel(r"$H_{\min}(BC|\Lambda,x,y,z)$ [bits]")
    ax.set_title(rf"Comparison, input $({inp[0]},{inp[1]},{inp[2]})$")
    ax.grid(alpha=0.25)
    ax.legend(loc="best")
    top = ax.secondary_xaxis("top", functions=(lambda v: v * W_OPT, lambda w: w / W_OPT))
    top.set_xlabel(r"$W_{CC}^{(2)}[P_v]=vW_{\mathrm{opt}}$")
    fig.tight_layout()
    stem = OUTPUT_DIR / f"curve_compare_input_{input_tag(inp)}_{level_tag()}"
    fig.savefig(stem.with_suffix(".png"), dpi=220)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)


def plot_input(inp: Tuple[int, int, int], frame: pd.DataFrame) -> None:
    frame = frame.sort_values("visibility")
    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.plot(frame["visibility"], frame["hmin_plot"], marker="o", markersize=3.0, linewidth=1.4)
    ax.axvline(V_CLASSICAL, linestyle="--", linewidth=1.0, label=rf"$v_{{CC}}={V_CLASSICAL:.4f}$")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 2.04)
    ax.set_xlabel(r"Channel visibility $v$")
    ax.set_ylabel(r"$H_{\min}(BC|\Lambda,x,y,z)$ [bits]")
    ax.set_title(rf"Fixed full distribution, input $({inp[0]},{inp[1]},{inp[2]})$")
    ax.grid(alpha=0.25)
    ax.legend(loc="best")

    top = ax.secondary_xaxis(
        "top",
        functions=(lambda v: v * W_OPT, lambda w: w / W_OPT),
    )
    top.set_xlabel(r"$W_{CC}^{(2)}[P_v]=vW_{\mathrm{opt}}$")
    fig.tight_layout()
    stem = OUTPUT_DIR / f"curve_fixed_distribution_input_{input_tag(inp)}_{level_tag()}"
    fig.savefig(stem.with_suffix(".png"), dpi=220)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)


def plot_all(curves: pd.DataFrame) -> None:
    if curves.empty:
        print("Nenhum CSV encontrado para plotar.", flush=True)
        return

    witness = load_witness_curves()
    has_witness = not witness.empty

    # Gráfico original: apenas a distribuição fixa.
    fig, ax = plt.subplots(figsize=(9.0, 6.0))
    for inp in all_inputs():
        sub = curves[(curves["x"] == inp[0]) & (curves["y"] == inp[1]) & (curves["z"] == inp[2])]
        if sub.empty:
            continue
        sub = sub.sort_values("visibility")
        ax.plot(sub["visibility"], sub["hmin_plot"], marker="o", markersize=2.2, linewidth=1.15, linestyle="--", label=f"{inp}")
        if SAVE_INPUT_PLOTS:
            plot_input(inp, sub)
            if has_witness:
                plot_input_comparison(inp, sub, witness)

    ax.axvline(V_CLASSICAL, linestyle=":", linewidth=1.0, label=rf"$v_{{CC}}={V_CLASSICAL:.4f}$")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 2.04)
    ax.set_xlabel(r"Channel visibility $v$")
    ax.set_ylabel(r"$H_{\min}(BC|\Lambda,x,y,z)$ [bits]")
    ax.set_title(r"CC2 randomness from the fixed full distribution $P_v$")
    ax.grid(alpha=0.25)
    ax.legend(ncol=3, fontsize=8, loc="best")
    top = ax.secondary_xaxis("top", functions=(lambda v: v * W_OPT, lambda w: w / W_OPT))
    top.set_xlabel(r"$W_{CC}^{(2)}[P_v]=vW_{\mathrm{opt}}$")
    fig.tight_layout()
    stem = OUTPUT_DIR / f"all_inputs_fixed_distribution_{level_tag()}"
    fig.savefig(stem.with_suffix(".png"), dpi=240)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)

    if has_witness:
        fig, ax = plt.subplots(figsize=(9.2, 6.2))
        colors = plt.rcParams["axes.prop_cycle"].by_key().get("color", [])
        if not colors:
            colors = [None] * max(1, len(all_inputs()))
        for k, inp in enumerate(all_inputs()):
            color = colors[k % len(colors)]
            dist_sub = curves[(curves["x"] == inp[0]) & (curves["y"] == inp[1]) & (curves["z"] == inp[2])].copy()
            wit_sub = witness[(witness["x"] == inp[0]) & (witness["y"] == inp[1]) & (witness["z"] == inp[2])].copy()
            if not wit_sub.empty:
                wit_sub = wit_sub.sort_values("visibility")
                ax.plot(wit_sub["visibility"], wit_sub["hmin_witness"], linewidth=1.4, linestyle="-", color=color, label=f"{inp}")
            if not dist_sub.empty:
                dist_sub = dist_sub.sort_values("visibility")
                ax.plot(dist_sub["visibility"], dist_sub["hmin_plot"], linewidth=1.35, linestyle="--", color=color)

        ax.axvline(V_CLASSICAL, linestyle=":", linewidth=1.0, color="black", alpha=0.8)
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, 2.04)
        ax.set_xlabel(r"Channel visibility $v$")
        ax.set_ylabel(r"$H_{\min}(BC|\Lambda,x,y,z)$ [bits]")
        ax.set_title(r"CC2: witness-only vs fixed full distribution")
        ax.grid(alpha=0.25)
        top = ax.secondary_xaxis("top", functions=(lambda v: v * W_OPT, lambda w: w / W_OPT))
        top.set_xlabel(r"$W_{CC}^{(2)}[P_v]=vW_{\mathrm{opt}}$")
        handles_inputs, labels_inputs = ax.get_legend_handles_labels()
        legend_inputs = ax.legend(handles_inputs, labels_inputs, ncol=3, fontsize=8, loc="upper left", title="input $(x,y,z)$")
        ax.add_artist(legend_inputs)
        ax.legend(handles=_comparison_style_legend() + [Line2D([0],[0], color="black", linestyle=":", linewidth=1.0, label=rf"$v_{{CC}}={V_CLASSICAL:.4f}$")], loc="lower right", fontsize=8, frameon=True)
        fig.tight_layout()
        stem = OUTPUT_DIR / f"all_inputs_compare_fixed_vs_witness_{level_tag()}"
        fig.savefig(stem.with_suffix(".png"), dpi=260)
        fig.savefig(stem.with_suffix(".pdf"))
        plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(15.0, 4.6), sharex=True, sharey=True)
    for x, ax in enumerate(axes):
        for y, z in product(range(2), range(2)):
            inp = (x, y, z)
            dist_sub = curves[(curves["x"] == x) & (curves["y"] == y) & (curves["z"] == z)]
            if not dist_sub.empty:
                dist_sub = dist_sub.sort_values("visibility")
                ax.plot(dist_sub["visibility"], dist_sub["hmin_plot"], marker="o", markersize=2.0, linewidth=1.2, linestyle="--", label=f"({x},{y},{z}) dist")
            if has_witness:
                wit_sub = witness[(witness["x"] == x) & (witness["y"] == y) & (witness["z"] == z)]
                if not wit_sub.empty:
                    wit_sub = wit_sub.sort_values("visibility")
                    ax.plot(wit_sub["visibility"], wit_sub["hmin_witness"], linewidth=1.2, linestyle="-", label=f"({x},{y},{z}) wit")
        ax.axvline(V_CLASSICAL, linestyle=":", linewidth=0.9)
        ax.set_title(rf"$x={x}$")
        ax.set_xlabel(r"Visibility $v$")
        ax.grid(alpha=0.25)
    axes[0].set_ylabel(r"$H_{\min}(BC|\Lambda)$ [bits]")
    axes[0].set_ylim(0.0, 2.04)
    fig.suptitle(r"Witness (solid) vs fixed distribution (dashed)")
    fig.tight_layout()
    stem = OUTPUT_DIR / f"all_inputs_3panels_compare_fixed_vs_witness_{level_tag()}"
    fig.savefig(stem.with_suffix(".png"), dpi=240)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)

    curves.sort_values(["x", "y", "z", "visibility"]).to_csv(
        OUTPUT_DIR / f"all_curves_fixed_distribution_{level_tag()}.csv.gz",
        index=False,
        compression="gzip",
    )


def generate_outputs() -> None:
    save_target_data()
    curves = load_all_curves()
    plot_all(curves)

    if not curves.empty:
        endpoint = curves[np.isclose(curves["visibility"], 1.0)].copy()
        endpoint = endpoint.sort_values("hmin_plot", ascending=False)
        endpoint.to_csv(OUTPUT_DIR / f"endpoint_ranking_{level_tag()}.csv", index=False)


def parse_args():
    parser = argparse.ArgumentParser(description="CC2 randomness com distribuição completa fixa.")
    parser.add_argument("--plot-only", action="store_true", help="Apenas recria os agregados e gráficos.")
    parser.add_argument("--target-only", action="store_true", help="Apenas calcula e salva P_opt, sem SDPs.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    save_target_data()

    print("=" * 88)
    print("CC2 — DISTRIBUIÇÃO COMPLETA FIXA")
    print("P_v = v P_opt + (1-v)/4")
    print(f"W_opt da Configuration 2 = {W_OPT:.12f}")
    print(f"8+2sqrt(2)               = {W_ANALYTIC:.12f}")
    print(f"v_CC = 6/W_opt           = {V_CLASSICAL:.12f}")
    print(f"Nível                     = {core.LEVEL}, q={core.Q_SCALAR}")
    print(f"Pontos de visibilidade    = {len(VISIBILITIES)}")
    print(f"Saída                      = {OUTPUT_DIR.resolve()}")
    print("=" * 88, flush=True)

    if args.target_only:
        return
    if args.plot_only:
        generate_outputs()
        return

    selected = [INPUT_FILTER] if INPUT_FILTER is not None else all_inputs()
    for inp in selected:
        run_input(inp)
    generate_outputs()


if __name__ == "__main__":
    main()
