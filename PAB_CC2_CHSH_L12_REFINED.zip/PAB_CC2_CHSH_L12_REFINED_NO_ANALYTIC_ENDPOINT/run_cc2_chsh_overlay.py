#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def run(cmd):
    print('\n'+'='*88, flush=True)
    print('EXECUTANDO:', ' '.join(map(str,cmd)), flush=True)
    print('='*88, flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode', choices=['cc2','chsh','plot','all'])
    args=parser.parse_args()
    py=sys.executable
    if args.mode in {'cc2','all'}:
        run([py, ROOT/'run_cc2_input100.py','all'])
    if args.mode in {'chsh','all'}:
        run([py, ROOT/'plot_overlay_cc2_chsh_tsirelson.py','--mode','chsh'])
    if args.mode in {'plot','all'}:
        run([py, ROOT/'plot_overlay_cc2_chsh_tsirelson.py','--mode','plot'])
if __name__=='__main__':
    main()
