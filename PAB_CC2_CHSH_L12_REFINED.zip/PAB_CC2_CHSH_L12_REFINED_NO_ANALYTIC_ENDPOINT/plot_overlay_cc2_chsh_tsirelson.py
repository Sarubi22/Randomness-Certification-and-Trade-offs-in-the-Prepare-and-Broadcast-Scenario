#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import math
from itertools import product
from pathlib import Path
import os
from typing import Dict, List, Optional, Sequence, Tuple
import argparse

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

try:
    import cvxpy as cp
except Exception as exc:
    raise ImportError("Instale cvxpy primeiro no ambiente do pacote.") from exc

ROOT = Path(__file__).resolve().parent
CC2_CSV = ROOT / 'resultados_COMPARATIVO_INPUT_100_L12' / 'CC2_input_1_0_0_duas_curvas_refinadas_L12_no_endpoint.csv'
OUTDIR = ROOT / 'resultados_OVERLAY_CC2_CHSH'
OUTDIR.mkdir(parents=True, exist_ok=True)

WORD_LEVEL = '2'   # '1+BC' or '2'
SOLVER = None      # automatic
VERBOSE_SOLVER = False
GEN_INPUT = (0, 0)
FULL_BEHAVIOR_TOL = 1e-9
CHSH_TOL = 1e-9
CHSH_ENDPOINT_GAP = float(os.getenv('PAB_CHSH_ENDPOINT_GAP', '1e-6'))

V_CL_CHSH = 1.0 / math.sqrt(2.0)
V_CHSH_MAX = 1.0 - CHSH_ENDPOINT_GAP
V_GRID = np.unique(np.concatenate([
    np.linspace(V_CL_CHSH, 0.85, 31, endpoint=False),
    np.linspace(0.85, 0.95, 29, endpoint=False),
    np.linspace(0.95, 0.99, 25, endpoint=False),
    np.linspace(0.99, 0.999, 22, endpoint=False),
    np.linspace(0.999, V_CHSH_MAX, 21, endpoint=True),
    np.array([V_CL_CHSH, V_CHSH_MAX]),
]))
V_GRID = np.unique(np.round(V_GRID[(V_GRID >= V_CL_CHSH-1e-12) & (V_GRID < 1.0-1e-14)], 12))

W_CC2_CL = 6.0
W_CC2_OPT = 8.0 + 2.0 * math.sqrt(2.0)
V_CC2_CL = W_CC2_CL / W_CC2_OPT
S_CHSH_CL = 2.0
S_CHSH_OPT = 2.0 * math.sqrt(2.0)
V_CHSH_CL = S_CHSH_CL / S_CHSH_OPT
H_CHSH_TSIRELSON = -math.log((2.0 + math.sqrt(2.0)) / 8.0, 2.0)


def sanitize_behavior(p: np.ndarray, tol: float = 1e-12) -> np.ndarray:
    p = np.array(p, dtype=float, copy=True)
    p[np.abs(p) < tol] = 0.0
    if np.min(p) < -1e-8:
        raise ValueError(f'Negative probability: min={np.min(p)}')
    p = np.maximum(p, 0.0)
    for y in range(2):
        for z in range(2):
            total = float(np.sum(p[y, z]))
            if total <= 0:
                raise ValueError(f'Invalid normalization at y={y}, z={z}: {total}')
            p[y, z] /= total
    return p


def tsirelson_behavior() -> np.ndarray:
    E = np.array([[1.0 / math.sqrt(2.0), 1.0 / math.sqrt(2.0)],
                  [1.0 / math.sqrt(2.0), -1.0 / math.sqrt(2.0)]], dtype=float)
    p = np.zeros((2, 2, 2, 2), dtype=float)
    for y in range(2):
        for z in range(2):
            for b in range(2):
                for c in range(2):
                    parity = +1.0 if b == c else -1.0
                    p[y, z, b, c] = 0.25 * (1.0 + parity * E[y, z])
    return sanitize_behavior(p)


def white_noise_behavior() -> np.ndarray:
    return np.ones((2, 2, 2, 2), dtype=float) / 4.0


def mix_with_white_noise(p_opt: np.ndarray, visibility: float) -> np.ndarray:
    visibility = float(np.clip(visibility, 0.0, 1.0))
    return sanitize_behavior(visibility * p_opt + (1.0 - visibility) * white_noise_behavior())


def correlators_from_behavior(p: np.ndarray) -> np.ndarray:
    p = sanitize_behavior(p)
    E = np.zeros((2, 2), dtype=float)
    for y in range(2):
        for z in range(2):
            E[y, z] = sum((+1.0 if b == c else -1.0) * p[y, z, b, c] for b in range(2) for c in range(2))
    return E


def chsh_value(p: np.ndarray) -> float:
    E = correlators_from_behavior(p)
    return float(E[0, 0] + E[0, 1] + E[1, 0] - E[1, 1])


def hmin_from_pguess(G: float) -> float:
    G = float(G)
    if G <= 0:
        return float('inf')
    return float(-math.log(G, 2.0))


PARTY_B = ('B0', 'B1')
PARTY_C = ('C0', 'C1')
SYMBOLS = PARTY_B + PARTY_C


def reduce_involutive_sequence(seq: Sequence[str]) -> Tuple[str, ...]:
    out: List[str] = []
    for s in seq:
        if out and out[-1] == s:
            out.pop()
        else:
            out.append(s)
    return tuple(out)


def canonical_from_symbols(seq: Sequence[str]) -> Tuple[Tuple[str, ...], Tuple[str, ...]]:
    bseq = [s for s in seq if s in PARTY_B]
    cseq = [s for s in seq if s in PARTY_C]
    return reduce_involutive_sequence(bseq), reduce_involutive_sequence(cseq)


def adjoint_word(w):
    bseq, cseq = w
    return tuple(reversed(bseq)), tuple(reversed(cseq))


def multiply_words(w1, w2):
    b1, c1 = w1
    b2, c2 = w2
    return reduce_involutive_sequence(b1 + b2), reduce_involutive_sequence(c1 + c2)


def word_to_string(w) -> str:
    bseq, cseq = w
    return 'I' if len(bseq) == 0 and len(cseq) == 0 else ''.join(bseq + cseq)


def build_word_list(level: str):
    words = {canonical_from_symbols(())}
    if level == '1+BC':
        raw = [(), ('B0',), ('B1',), ('C0',), ('C1',), ('B0', 'C0'), ('B0', 'C1'), ('B1', 'C0'), ('B1', 'C1')]
        for seq in raw:
            words.add(canonical_from_symbols(seq))
    elif level == '2':
        for L in range(1, 3):
            for seq in product(SYMBOLS, repeat=L):
                words.add(canonical_from_symbols(seq))
    else:
        raise ValueError("WORD_LEVEL must be '1+BC' or '2'.")
    return sorted(words, key=lambda w: (len(w[0]) + len(w[1]), word_to_string(w)))


WORDS = build_word_list(WORD_LEVEL)
WORD_INDEX = {w: i for i, w in enumerate(WORDS)}


def word_B(y: int):
    return canonical_from_symbols((f'B{y}',))


def word_C(z: int):
    return canonical_from_symbols((f'C{z}',))


def word_BC(y: int, z: int):
    return canonical_from_symbols((f'B{y}', f'C{z}'))


def add_npa_equalities(Gamma, r):
    constraints = []
    n = len(WORDS)
    constraints.append(Gamma >> 0)
    constraints.append(cp.real(Gamma[0, 0]) == r)
    constraints.append(cp.imag(Gamma[0, 0]) == 0)
    constraints.append(r >= 0)
    reps = {}
    for i in range(n):
        for j in range(n):
            key = multiply_words(adjoint_word(WORDS[i]), WORDS[j])
            if key not in reps:
                reps[key] = (i, j)
            else:
                i0, j0 = reps[key]
                constraints.append(Gamma[i, j] == Gamma[i0, j0])
    for y in range(2):
        constraints.append(cp.imag(Gamma[0, WORD_INDEX[word_B(y)]]) == 0)
    for z in range(2):
        constraints.append(cp.imag(Gamma[0, WORD_INDEX[word_C(z)]]) == 0)
    for y in range(2):
        for z in range(2):
            constraints.append(cp.imag(Gamma[0, WORD_INDEX[word_BC(y, z)]]) == 0)
    return constraints


def branch_moment(Gamma, w):
    return cp.real(Gamma[0, WORD_INDEX[w]])


def branch_prob(Gamma, r, b: int, c: int, y: int, z: int):
    sb = +1.0 if b == 0 else -1.0
    sc = +1.0 if c == 0 else -1.0
    return 0.25 * (
        r
        + sb * branch_moment(Gamma, word_B(y))
        + sc * branch_moment(Gamma, word_C(z))
        + sb * sc * branch_moment(Gamma, word_BC(y, z))
    )


def branch_chsh(Gamma):
    return (
        branch_moment(Gamma, word_BC(0, 0))
        + branch_moment(Gamma, word_BC(0, 1))
        + branch_moment(Gamma, word_BC(1, 0))
        - branch_moment(Gamma, word_BC(1, 1))
    )


def choose_solver(preferred: Optional[str] = None) -> str:
    installed = set(cp.installed_solvers())
    if preferred is not None:
        if preferred not in installed:
            raise ValueError(f'Solver {preferred} not installed. Installed: {sorted(installed)}')
        return preferred
    for s in ['MOSEK', 'CLARABEL', 'CVXOPT', 'SCS']:
        if s in installed:
            return s
    raise RuntimeError(f'No SDP solver found. Installed: {sorted(installed)}')


def solve_chsh_joint_guessing(*, mode: str, gen_input: Tuple[int, int], target_S: Optional[float] = None, target_behavior: Optional[np.ndarray] = None, solver: Optional[str] = None, verbose: bool = False) -> Dict[str, object]:
    if mode not in {'chsh_only', 'full_distribution'}:
        raise ValueError("mode must be 'chsh_only' or 'full_distribution'.")
    if mode == 'chsh_only' and target_S is None:
        raise ValueError('target_S is required for chsh_only.')
    if mode == 'full_distribution' and target_behavior is None:
        raise ValueError('target_behavior is required for full_distribution.')
    if target_behavior is not None:
        target_behavior = sanitize_behavior(target_behavior)
        target_S_eff = chsh_value(target_behavior)
    else:
        target_S_eff = float(target_S)

    guesses = [(0, 0), (0, 1), (1, 0), (1, 1)]
    n = len(WORDS)
    Gammas = {}
    weights = {}
    constraints = []
    for g in guesses:
        Gammas[g] = cp.Variable((n, n), hermitian=True, name=f'Gamma_{g[0]}{g[1]}')
        weights[g] = cp.Variable(nonneg=True, name=f'r_{g[0]}{g[1]}')
        constraints += add_npa_equalities(Gammas[g], weights[g])
        for y in range(2):
            for z in range(2):
                for b in range(2):
                    for c in range(2):
                        constraints.append(branch_prob(Gammas[g], weights[g], b, c, y, z) >= -1e-10)

    constraints.append(sum(weights[g] for g in guesses) == 1.0)

    if mode == 'chsh_only':
        total_S = sum(branch_chsh(Gammas[g]) for g in guesses)
        constraints.append(total_S >= float(target_S) - CHSH_TOL)
    else:
        for y in range(2):
            for z in range(2):
                for b in range(2):
                    for c in range(2):
                        expr = sum(branch_prob(Gammas[g], weights[g], b, c, y, z) for g in guesses)
                        target = float(target_behavior[y, z, b, c])
                        constraints.append(expr <= target + FULL_BEHAVIOR_TOL)
                        constraints.append(expr >= target - FULL_BEHAVIOR_TOL)

    y_star, z_star = gen_input
    objective = cp.Maximize(sum(branch_prob(Gammas[g], weights[g], g[0], g[1], y_star, z_star) for g in guesses))
    problem = cp.Problem(objective, constraints)
    chosen_solver = choose_solver(solver)
    kwargs = {'solver': chosen_solver, 'verbose': verbose}
    if chosen_solver == 'SCS':
        kwargs.update({'eps': 2e-7, 'max_iters': 300000})
    if chosen_solver == 'CLARABEL':
        kwargs.update({'tol_gap_abs': 1e-9, 'tol_feas': 1e-9, 'tol_gap_rel': 1e-9})
    value = problem.solve(**kwargs)
    G_raw = float(np.real(value)) if value is not None else float('nan')
    G = min(1.0, max(0.0, G_raw))
    return {
        'mode': mode,
        'status': problem.status,
        'solver': chosen_solver,
        'word_level': WORD_LEVEL,
        'generation_input_yz': list(gen_input),
        'S': float(target_S_eff),
        'v': float(target_S_eff / S_CHSH_OPT),
        'pguess_upper_raw': G_raw,
        'pguess_upper_clipped': G,
        'Hmin': hmin_from_pguess(G),
    }


def load_cc2_curves() -> pd.DataFrame:
    if not CC2_CSV.exists():
        raise FileNotFoundError(f'Arquivo CC2 nao encontrado\n{CC2_CSV}\nRode antes 00_RODAR_TUDO_INPUT_100.bat ou 03_PLOTAR_DUAS_CURVAS_INPUT_100.bat.')
    df = pd.read_csv(CC2_CSV)
    required = {'method', 'v', 'W', 'Hmin'}
    if not required.issubset(df.columns):
        raise RuntimeError(f'CC2 CSV sem colunas esperadas: {required - set(df.columns)}')
    out = pd.DataFrame({
        'facet': 'CC2',
        'method': df['method'].astype(str).replace({
            'witness_fixed': 'CC2 fixed witness value',
            'fixed_full_distribution': 'CC2 fixed full distribution',
        }),
        'v': pd.to_numeric(df['v'], errors='coerce'),
        'B': pd.to_numeric(df['W'], errors='coerce'),
        'Hmin': pd.to_numeric(df['Hmin'], errors='coerce'),
    }).dropna()
    out['normalized_violation'] = (out['B'] - W_CC2_CL) / (W_CC2_OPT - W_CC2_CL)
    out = out[(out['normalized_violation'] >= -1e-9) & (out['normalized_violation'] < 1.0 - 1e-12)]
    return out.sort_values(['method', 'normalized_violation']).reset_index(drop=True)


def scan_chsh_curves(checkpoint_path: Path) -> pd.DataFrame:
    """Resolve e salva cada ponto imediatamente; retoma após interrupções."""
    pT = tsirelson_behavior()
    if checkpoint_path.exists():
        existing = pd.read_csv(checkpoint_path)
    else:
        existing = pd.DataFrame()
    done = set()
    if not existing.empty and {'mode','v'}.issubset(existing.columns):
        for _, row in existing.iterrows():
            if str(row.get('status','')).lower() not in {'solver_error','error'}:
                done.add((str(row['mode']), round(float(row['v']), 12)))
    rows = [] if existing.empty else existing.to_dict('records')

    for v in V_GRID:
        v = float(v)
        S_target = S_CHSH_OPT * v
        p_v = mix_with_white_noise(pT, v)
        for mode in ['chsh_only', 'full_distribution']:
            key = (mode, round(v, 12))
            if key in done:
                continue
            if mode == 'chsh_only':
                row = solve_chsh_joint_guessing(
                    mode='chsh_only', gen_input=GEN_INPUT,
                    target_S=S_target, solver=SOLVER, verbose=VERBOSE_SOLVER)
            else:
                row = solve_chsh_joint_guessing(
                    mode='full_distribution', gen_input=GEN_INPUT,
                    target_behavior=p_v, solver=SOLVER, verbose=VERBOSE_SOLVER)
            row['v'] = v
            row['normalized_violation'] = (float(row['S']) - S_CHSH_CL) / (S_CHSH_OPT - S_CHSH_CL)
            print(f"CHSH {mode:17s} v={v:.9f} S={S_target:.9f} status={row['status']} Hmin={row['Hmin']:.9f}", flush=True)
            rows.append(row)
            frame = pd.DataFrame(rows).sort_values(['mode','v']).drop_duplicates(['mode','v'], keep='last')
            frame.to_csv(checkpoint_path, index=False)
            done.add(key)

    df = pd.DataFrame(rows)
    df['facet'] = 'CHSH'
    df['B'] = df['S']
    df['normalized_violation'] = (df['S'] - S_CHSH_CL) / (S_CHSH_OPT - S_CHSH_CL)
    df['method'] = df['mode'].replace({
        'chsh_only': 'CHSH, fixed witness',
        'full_distribution': 'CHSH, fixed distribution',
    })
    df = df[(df['normalized_violation'] >= -1e-9) & (df['normalized_violation'] < 1.0 - 1e-12)]
    df = df.sort_values(['method','normalized_violation']).reset_index(drop=True)
    df.to_csv(checkpoint_path, index=False)
    return df


def nu_to_v_cc2(nu):
    return V_CC2_CL + np.asarray(nu) * (1.0 - V_CC2_CL)


def v_cc2_to_nu(v):
    return (np.asarray(v) - V_CC2_CL) / (1.0 - V_CC2_CL)


def nu_to_v_chsh(nu):
    return V_CHSH_CL + np.asarray(nu) * (1.0 - V_CHSH_CL)


def plot_overlay(combined: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(9.4, 6.25))
    style = {
        'CC2, fixed witness': {'linestyle': '-', 'linewidth': 2.25},
        'CC2, fixed distribution': {'linestyle': '--', 'linewidth': 2.25, 'marker': 'o', 'markersize': 2.5},
        'CHSH, fixed witness': {'linestyle': '-.', 'linewidth': 2.25},
        'CHSH, fixed distribution': {'linestyle': ':', 'linewidth': 2.8, 'marker': 's', 'markersize': 2.4},
    }
    order = ['CC2, fixed witness','CC2, fixed distribution','CHSH, fixed witness','CHSH, fixed distribution']
    curve_handles = []
    handle_by_method = {}
    for method in order:
        frame = combined[combined['method'] == method].copy().sort_values('normalized_violation')
        if frame.empty:
            continue
        kwargs = dict(style[method])
        if 'marker' in kwargs:
            kwargs['markevery'] = max(1, len(frame)//28)
        line, = ax.plot(frame['normalized_violation'], frame['Hmin'], label=method, **kwargs)
        curve_handles.append(line)
        handle_by_method[method] = line

    threshold = ax.axvline(0.0, linestyle=':', linewidth=1.1, label='Classical threshold')
    # Referências somente na legenda: nenhum ponto de endpoint é inserido nas curvas.
    cc2_color = handle_by_method.get('CC2, fixed witness').get_color() if 'CC2, fixed witness' in handle_by_method else 'C0'
    chsh_color = handle_by_method.get('CHSH, fixed witness').get_color() if 'CHSH, fixed witness' in handle_by_method else 'C2'
    cc2_endpoint_ref = Line2D([], [], marker='o', linestyle='None', markersize=6, color=cc2_color,
                             label=r'CC2 endpoint: $H_{\min}=2$')
    chsh_endpoint_ref = Line2D([], [], marker='o', linestyle='None', markersize=6, color=chsh_color,
                              label=rf'CHSH endpoint: $H_{{\min}}={H_CHSH_TSIRELSON:.3f}$')

    ax.set_xlim(0.0, 1.005)
    ax.set_ylim(0.0, 2.05)
    ax.set_xlabel(r'Normalized violation $\nu=(B-B_{\rm cl})/(B_{\rm opt}-B_{\rm cl})$')
    ax.set_ylabel(r'$H_{\min}(BC|\Lambda)$ [bits]')
    ax.grid(alpha=0.24)
    fig.suptitle('Joint randomness from CC2 and CHSH violations', y=1.105)
    ax.legend(handles=curve_handles + [cc2_endpoint_ref, chsh_endpoint_ref, threshold],
              loc='upper left', frameon=False, fontsize=8.8)

    top_cc2 = ax.secondary_xaxis('top', functions=(nu_to_v_cc2, v_cc2_to_nu))
    top_cc2.set_xlabel(r'CC2 visibility $v_{\rm CC2}$')
    top_cc2.set_xticks([V_CC2_CL, 0.65, 0.75, 0.85, 0.95, 1.00])
    top_cc2.tick_params(axis='x', labelsize=8)

    top_chsh = ax.twiny()
    top_chsh.set_xlim(nu_to_v_chsh(0.0), nu_to_v_chsh(1.0))
    top_chsh.spines['top'].set_position(('outward', 38))
    top_chsh.set_xlabel(r'CHSH visibility $v_{\rm CHSH}$', labelpad=8)
    top_chsh.set_xticks([V_CHSH_CL, 0.78, 0.85, 0.92, 1.00])
    top_chsh.tick_params(axis='x', labelsize=8)

    fig.tight_layout()
    stem = OUTDIR / 'CC2_CHSH_L12_NPA2_refined_no_analytic_endpoint'
    fig.savefig(stem.with_suffix('.pdf'), bbox_inches='tight')
    fig.savefig(stem.with_suffix('.png'), dpi=320, bbox_inches='tight')
    plt.close(fig)
    combined.to_csv(OUTDIR / 'combined_CC2_CHSH_L12_NPA2_refined_no_endpoint.csv', index=False)
    print(stem.with_suffix('.pdf'))
    print(stem.with_suffix('.png'))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['chsh','plot','all'], default='all')
    args = parser.parse_args()
    print('=' * 88)
    print('CC2 L(1,2) + CHSH NPA level 2 — refinado, sem endpoint analítico')
    print(f'CHSH WORD_LEVEL={WORD_LEVEL}; words={len(WORDS)}; v_max={V_GRID[-1]:.12f}')
    print(f'Solvers instalados: {cp.installed_solvers()}')

    chsh_path = OUTDIR / 'chsh_curves_NPA2_refined_no_endpoint.csv'
    if args.mode in {'chsh','all'}:
        scan_chsh_curves(chsh_path)
    if args.mode in {'plot','all'}:
        cc2 = load_cc2_curves()
        cc2['method'] = cc2['method'].replace({
            'CC2 fixed witness value':'CC2, fixed witness',
            'CC2 fixed full distribution':'CC2, fixed distribution',
        })
        if not chsh_path.exists():
            raise FileNotFoundError(f'Curvas CHSH não encontradas: {chsh_path}')
        chsh = pd.read_csv(chsh_path)
        combined = pd.concat([
            cc2[['facet','method','B','normalized_violation','Hmin']],
            chsh[['facet','method','B','normalized_violation','Hmin','status']],
        ], ignore_index=True, sort=False)
        combined = combined[(combined['normalized_violation'] >= -1e-9) & (combined['normalized_violation'] < 1.0-1e-12)]
        plot_overlay(combined)
        summary = (combined.sort_values('normalized_violation').groupby(['facet','method'], as_index=False).last())
        summary.to_csv(OUTDIR / 'closest_computed_points_to_endpoint.csv', index=False)
        print(summary[['facet','method','normalized_violation','B','Hmin']].to_string(index=False))


if __name__ == '__main__':
    main()
