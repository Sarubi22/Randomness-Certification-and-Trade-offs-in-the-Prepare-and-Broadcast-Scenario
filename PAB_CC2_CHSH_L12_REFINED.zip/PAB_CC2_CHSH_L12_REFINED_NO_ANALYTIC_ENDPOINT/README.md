# PAB CC2 + CHSH — L(1,2), curvas refinadas, sem endpoint analítico

## Execução

Dê duplo clique em:

```text
00_RODAR_TUDO_L12_REFINADO_SEM_ENDPOINT.bat
```

O pacote calcula e retoma automaticamente:

1. CC2, input fixo `(1,0,0)`, função suporte no nível PAB `L12_q1`;
2. CC2, distribuição completa fixa, quatro ramos de Eve clássica, `L12_q1`;
3. CHSH, valor fixo, NPA com palavras até comprimento 2;
4. CHSH, distribuição completa fixa, no mesmo nível NPA;
5. gráfico final no estilo do PDF anexado, com título, quatro curvas, violação normalizada e dois eixos de visibilidade.

## Endpoint

Nenhum valor de endpoint é inserido nas curvas e nenhum ponto exato em
`v=1` é resolvido por padrão. As grades terminam em `v=1-10^{-6}`.

As entradas

- `CC2 endpoint: Hmin = 2`;
- `CHSH endpoint: Hmin = 1.228`;

aparecem **somente como referências na legenda**, sem pontos desenhados e sem
alterar os CSVs ou as curvas SDP.

`Classical threshold` também aparece na legenda.

## Níveis

- CC2: hierarquia PAB `L(1,2)`, identificada nos arquivos como `L12_q1`.
- CHSH: NPA de segundo nível, palavras de comprimento até 2.

## Refinamento

- CC2 witness-only: envoltória de função suporte com refinamento adaptativo em
  `tau`; a curva gráfica é reconstruída em milhares de pontos.
- CC2 fixed distribution: grade não uniforme de aproximadamente 128 SDPs,
  concentrada perto de `v=1`.
- CHSH: aproximadamente 128 pontos para cada uma das duas curvas, com
  checkpoint após cada SDP.

Para mudar a distância ao endpoint, defina antes da execução:

```bat
set PAB_ENDPOINT_GAP=1e-6
set PAB_CHSH_ENDPOINT_GAP=1e-6
```

O uso de MOSEK é obrigatório para CC2 nesta configuração; a licença deve estar
funcional no computador.
