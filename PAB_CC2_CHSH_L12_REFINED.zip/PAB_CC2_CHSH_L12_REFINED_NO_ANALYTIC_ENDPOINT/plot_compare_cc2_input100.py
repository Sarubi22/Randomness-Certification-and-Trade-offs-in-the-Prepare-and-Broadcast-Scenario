#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
LEVEL_TAG = "L12_q1"
W_CLASSICAL = 6.0
W_OPT = 8.0 + 2.0 * math.sqrt(2.0)
V_CC = W_CLASSICAL / W_OPT

WITNESS_CSV = ROOT / "resultados_WITNESS_REFINADA_INPUT_100_L12" / f"curve_joint_BC_CC2_input_1_0_0_{LEVEL_TAG}.csv"
DIST_CSV = ROOT / "resultados_DISTRIBUICAO_REFINADA_INPUT_100_L12" / f"curve_fixed_distribution_input_1_0_0_{LEVEL_TAG}.csv"
OUT = ROOT / "resultados_COMPARATIVO_INPUT_100_L12"
OUT.mkdir(parents=True, exist_ok=True)


def load_witness() -> pd.DataFrame:
    if not WITNESS_CSV.exists():
        raise FileNotFoundError(f"Curva CC2 witness não encontrada: {WITNESS_CSV}")
    df = pd.read_csv(WITNESS_CSV)
    out = pd.DataFrame({
        "W": pd.to_numeric(df["w_lower"], errors="coerce"),
        "Hmin": pd.to_numeric(df["h_min_lower_monotone"], errors="coerce"),
    }).dropna()
    out = out[(out["W"] >= W_CLASSICAL - 1e-10) & (out["W"] < W_OPT - 1e-12)]
    return out.sort_values("W").drop_duplicates("W", keep="last").reset_index(drop=True)


def load_distribution() -> pd.DataFrame:
    if not DIST_CSV.exists():
        raise FileNotFoundError(f"Curva CC2 distribuição não encontrada: {DIST_CSV}")
    df = pd.read_csv(DIST_CSV)
    # Usa exclusivamente o valor SDP, nunca hmin_plot com override analítico.
    ycol = "hmin_sdp"
    out = pd.DataFrame({
        "v": pd.to_numeric(df["visibility"], errors="coerce"),
        "Hmin": pd.to_numeric(df[ycol], errors="coerce"),
        "status": df.get("status", ""),
    }).dropna(subset=["v", "Hmin"])
    out["W"] = out["v"] * W_OPT
    out = out[(out["W"] >= W_CLASSICAL - 1e-10) & (out["W"] < W_OPT - 1e-12)]
    return out.sort_values("W").drop_duplicates("W", keep="last").reset_index(drop=True)


def main() -> None:
    wit = load_witness()
    dist = load_distribution()
    wit_long = wit.assign(method="witness_fixed", v=wit["W"] / W_OPT)
    dist_long = dist[["W", "v", "Hmin"]].assign(method="fixed_full_distribution")
    combined = pd.concat([
        wit_long[["method", "v", "W", "Hmin"]],
        dist_long[["method", "v", "W", "Hmin"]],
    ], ignore_index=True)
    combined.to_csv(OUT / "CC2_input_1_0_0_duas_curvas_refinadas_L12_no_endpoint.csv", index=False)

    interp = np.interp(dist["W"], wit["W"], wit["Hmin"])
    check = dist[["v", "W", "Hmin"]].rename(columns={"Hmin":"Hmin_distribution"})
    check["Hmin_witness_interpolated"] = interp
    check["difference_distribution_minus_witness"] = check["Hmin_distribution"] - interp
    check.to_csv(OUT / "CC2_input_1_0_0_comparacao_ponto_a_ponto_L12.csv", index=False)

    fig, ax = plt.subplots(figsize=(9.2, 6.0))
    ax.plot(wit["W"], wit["Hmin"], linewidth=2.1, label="Fixed witness value")
    ax.plot(dist["W"], dist["Hmin"], linestyle="--", linewidth=2.1,
            marker="o", markersize=2.5, markevery=max(1, len(dist)//28),
            label="Fixed full distribution")
    ax.axvline(W_CLASSICAL, linestyle=":", linewidth=1.1, label="Classical threshold")
    ax.set_xlim(W_CLASSICAL, W_OPT + 0.015)
    ax.set_ylim(0.0, 2.05)
    ax.set_xlabel(r"Witness value $W_{\mathrm{CC}}^{(2)}$")
    ax.set_ylabel(r"$H_{\min}(BC|\Lambda,1,0,0)$ [bits]")
    ax.grid(alpha=0.24)
    ax.legend(loc="upper left", frameon=False)
    top = ax.secondary_xaxis("top", functions=(lambda w: w/W_OPT, lambda v: v*W_OPT))
    top.set_xlabel(r"Channel visibility $v=W/W_{\mathrm{opt}}$")
    fig.tight_layout()
    stem = OUT / "CC2_input_1_0_0_witness_vs_fixed_distribution_L12_q1_no_endpoint"
    fig.savefig(stem.with_suffix(".png"), dpi=320)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)
    print(stem.with_suffix('.pdf'))
    print(f"witness: {len(wit)} pontos; distribuição: {len(dist)} SDPs; endpoint exato excluído.")


if __name__ == "__main__":
    main()
