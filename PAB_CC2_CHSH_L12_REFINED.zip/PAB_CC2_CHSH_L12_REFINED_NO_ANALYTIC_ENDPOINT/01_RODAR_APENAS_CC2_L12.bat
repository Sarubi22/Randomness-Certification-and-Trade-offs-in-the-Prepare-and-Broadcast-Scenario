@echo off
call "%~dp0RUN_L12_REFINED_NO_ENDPOINT.cmd" cc2
