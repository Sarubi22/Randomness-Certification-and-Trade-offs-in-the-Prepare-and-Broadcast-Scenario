#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Executa as duas curvas CC2 refinadas no nível L(1,2), sem endpoint analítico."""
from __future__ import annotations

import argparse
import math
import os
import subprocess
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
INPUT = (1, 0, 0)
W_OPT = 8.0 + 2.0 * math.sqrt(2.0)
V_CC = 6.0 / W_OPT
ENDPOINT_GAP = float(os.getenv("PAB_ENDPOINT_GAP", "1e-6"))
V_MAX = 1.0 - ENDPOINT_GAP

OUT_WITNESS = ROOT / "resultados_WITNESS_REFINADA_INPUT_100_L12"
OUT_DIST = ROOT / "resultados_DISTRIBUICAO_REFINADA_INPUT_100_L12"


def run(command: list[str], env: dict[str, str]) -> None:
    print("\n" + "=" * 88, flush=True)
    print("EXECUTANDO:", " ".join(command), flush=True)
    print("=" * 88, flush=True)
    subprocess.run(command, cwd=ROOT, env=env, check=True)


def distribution_grid() -> np.ndarray:
    """Grade refinada e não uniforme, sem incluir v=1 exatamente."""
    if not (0.0 < ENDPOINT_GAP < 1.0 - V_CC):
        raise ValueError("PAB_ENDPOINT_GAP deve ser positivo e pequeno.")
    pieces = [
        np.linspace(V_CC, 0.85, 31, endpoint=False),
        np.linspace(0.85, 0.95, 29, endpoint=False),
        np.linspace(0.95, 0.99, 25, endpoint=False),
        np.linspace(0.99, 0.999, 22, endpoint=False),
        np.linspace(0.999, V_MAX, 21, endpoint=True),
        np.array([V_CC, V_MAX]),
    ]
    grid = np.unique(np.round(np.concatenate(pieces), 12))
    return grid[(grid >= V_CC - 1e-12) & (grid < 1.0 - 1e-14)]


def common_env(output: Path) -> dict[str, str]:
    env = os.environ.copy()
    env.update({
        "PAB_INPUT": "1,0,0",
        "PAB_OUTPUT_DIR": str(output),
        "PAB_LEVEL": "L12",
        "PAB_Q_SCALAR": "1",
        "PAB_SOLVER": "MOSEK",
        "PAB_ALLOW_SCS_FALLBACK": "0",
        "PAB_RESUME": "1",
        "PAB_SAVE_INPUT_PLOTS": "1",
        "PAB_ENFORCE_PROB_POS": "1",
        "PAB_VERBOSE": "0",
        "PAB_MOSEK_EPS": "1e-9",
        "PAB_RESIDUAL_MULTIPLIER": "10",
        "PAB_INCLUDE_EXACT_ENDPOINT": "0",
        "PAB_SKIP_HARD_ENDPOINT": "1",
        "PAB_ENDPOINT_GAP": f"{ENDPOINT_GAP:.12g}",
    })
    return env


def run_witness() -> None:
    OUT_WITNESS.mkdir(parents=True, exist_ok=True)
    env = common_env(OUT_WITNESS)
    env.update({
        "PAB_FACET": "CC2",
        "PAB_RUN_PHYSICAL_LOWER": "0",
        "PAB_SUPPORT_ABS_PADDING": "1e-8",
        "PAB_SUPPORT_REL_PADDING": "1e-10",
        "PAB_TAU_FOCUS": "1",
        "PAB_TAU_FOCUS_MIN": "0.0",
        "PAB_TAU_FOCUS_MAX": "4.0",
        "PAB_TAU_FOCUS_STEP": "0.04",
        "PAB_TAU_REFINE_ROUNDS": "10",
        "PAB_TAU_REFINE_ABS_TOL": "4e-5",
        "PAB_TAU_REFINE_REL_TOL": "2e-5",
        "PAB_TAU_BOUND_IMPROVEMENT_TOL": "5e-9",
        "PAB_TAU_MAX_NEW_PER_ROUND": "256",
        "PAB_TAU_MAX": "2000",
        "PAB_W_PLOT_POINTS_GLOBAL": "7001",
        "PAB_W_PLOT_POINTS_ENDPOINT": "5000",
        "PAB_ENDPOINT_REL_GAP_MIN": f"{ENDPOINT_GAP:.12g}",
        "PAB_ENDPOINT_REL_GAP_MAX": "1e-2",
    })
    run([sys.executable, str(ROOT / "pab_cc2_12_inputs.py")], env)


def run_distribution() -> None:
    OUT_DIST.mkdir(parents=True, exist_ok=True)
    grid = distribution_grid()
    env = common_env(OUT_DIST)
    env.update({
        "PAB_FIXED_DISTRIBUTION_TOL": "1e-9",
        "PAB_OBJECTIVE_ABS_PADDING": "2e-7",
        "PAB_OBJECTIVE_REL_PADDING": "1e-9",
        "PAB_VISIBILITIES": ",".join(f"{v:.12f}" for v in grid),
    })
    print(f"Grade CC2 de distribuição fixa: {len(grid)} pontos.", flush=True)
    print(f"v inicial={V_CC:.12f}; v final={grid[-1]:.12f}; v=1 excluído.", flush=True)
    run([sys.executable, str(ROOT / "pab_cc2_fixed_distribution.py")], env)


def run_plot() -> None:
    run([sys.executable, str(ROOT / "plot_compare_cc2_input100.py")], os.environ.copy())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["witness", "distribution", "plot", "all"])
    args = parser.parse_args()
    if args.mode in {"witness", "all"}:
        run_witness()
    if args.mode in {"distribution", "all"}:
        run_distribution()
    if args.mode in {"plot", "all"}:
        run_plot()


if __name__ == "__main__":
    main()
