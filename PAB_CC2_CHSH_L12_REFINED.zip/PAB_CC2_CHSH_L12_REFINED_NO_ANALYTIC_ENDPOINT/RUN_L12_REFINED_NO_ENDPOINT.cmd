@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "MODE=%~1"
if /I not "%MODE%"=="cc2" if /I not "%MODE%"=="chsh" if /I not "%MODE%"=="plot" if /I not "%MODE%"=="all" set "MODE=all"

set "PYBASE="
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYBASE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYBASE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYBASE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYBASE if exist "%USERPROFILE%\anaconda3\python.exe" set "PYBASE=%USERPROFILE%\anaconda3\python.exe"
if not defined PYBASE if exist "%USERPROFILE%\miniconda3\python.exe" set "PYBASE=%USERPROFILE%\miniconda3\python.exe"
if not defined PYBASE for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYBASE set "PYBASE=%%P"
if not defined PYBASE (echo ERRO: Python nao encontrado.& pause & exit /b 1)

set "VENV=%CD%\.pab_l12_refined_env"
set "PY=%VENV%\Scripts\python.exe"
if not exist "%PY%" "%PYBASE%" -m venv "%VENV%"
if errorlevel 1 goto :erro
if not exist "%VENV%\.dependencias_ok" (
  "%PY%" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel
  if errorlevel 1 goto :erro
  "%PY%" -m pip install --disable-pip-version-check --prefer-binary -r "%CD%\requirements.txt"
  if errorlevel 1 goto :erro
  echo ok>"%VENV%\.dependencias_ok"
)
"%PY%" -c "import cvxpy as cp; print('CVXPY:',cp.__version__); print('Solvers:',cp.installed_solvers())"
if errorlevel 1 goto :erro
"%PY%" "%CD%\run_cc2_chsh_overlay.py" "%MODE%"
if errorlevel 1 goto :erro
echo.
echo CONCLUIDO. Resultados finais em resultados_OVERLAY_CC2_CHSH
pause
exit /b 0
:erro
echo ERRO. Checkpoints ja calculados foram preservados.
pause
exit /b 1
